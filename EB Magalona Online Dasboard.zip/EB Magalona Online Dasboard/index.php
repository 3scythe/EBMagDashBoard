<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="Page/CSS/login.css" type="text/css">
  	<script type="text/javascript" src="Page/Script/jquery-3.6.0.js"></script>
  	<script type="text/javascript" src="Page/Script/animation.js"></script>
  	<script>
  		$(document).ready(function(){
		  	$("#switch1").click(function(){
		  		$(".loginform").css("display", "inherit");
		    	$(".loginform2").css("display", "none");
		    	$("#switch1").css("background-color", "#ffffb3");
		    	$("#switch2").css("background-color", "white");
		 	});
		 	$("#switch2").click(function(){
		    	$(".loginform").css("display", "none");
		    	$(".loginform2").css("display", "inherit");
		    	$("#switch1").css("background-color", "white");
		    	$("#switch2").css("background-color", "#ffe6ff");
		 	});
		});
  	</script>
</head>
<body>

<div class="holder">
	<button id="switch1"> Admin </button>
	<button id="switch2"> Principal </button>

	<br>

	<form class="loginform" action="Page/PHP/AdminLogin.php" method="post">
		<ul>
			<img src="Page/Images/icon.jpg" class=icon>				
			<li><input type="text" name="UserID" placeholder="Username...."></li>
			<li><input type="Password" name="UserPass" placeholder="Password...."></li>
		</ul>
		<br>
		<button class="logbutton" type="submit" name="adlogin">Login</button>
	</form>

	<form class="loginform2" action="Page/PHP/SchoolLogin.php" method="post">
		<ul>
			<img src="Page/Images/icon.jpg" class=icon>				
			<li><input type="text" name="UserID2" placeholder="Username...."></li>
			<li><input type="Password" name="UserPass2" placeholder="Password...."></li>
			<li>
				<select name="lvl" style="width: 15%;height: 30px; float: left;">
    				<option value="Elementary">Elementary</option>
    				<option value="High School">High School</option>
    				<option value="Private">Private</option>
  				</select>
  			</li>
		</ul>
		<br>
		<button class="logbutton" type="submit" name="adlogin2">Login</button>
	</form>

</div>
</body>
</html>