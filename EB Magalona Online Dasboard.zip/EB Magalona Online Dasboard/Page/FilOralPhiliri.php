<?php 
include "Header.php";

session_start();

$grossmin = $_SESSION['timeMin1'];
$grossmax = $_SESSION['timeMax1'];

$grossmin2 = $_SESSION['timeMin2'];
$grossmax2 = $_SESSION['timeMax2'];

$grossmin3 = $_SESSION['timeMin3'];
$grossmax3 = $_SESSION['timeMax3'];

$grossmin4 = $_SESSION['timeMin4'];
$grossmax4 = $_SESSION['timeMax4'];

$grossmin5 = $_SESSION['timeMin5'];
$grossmax5 = $_SESSION['timeMax5'];

if($_SESSION['display'] == "none"){
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page1"){
	$chosenTime = $_SESSION['theTime'];
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
	
}
elseif($_SESSION['display'] == "Page2"){
	$chosenTime2 = $_SESSION['theTime2'];
	$chosenTime = $grossmax;
	$chosenTime3 = $grossmax3;
	
}
elseif($_SESSION['display'] == "Page3"){
	$chosenTime3 = $_SESSION['theTime3'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page4"){
	$chosenTime4 = $_SESSION['theTime4'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page5"){
	$chosenTime5 = $_SESSION['theTime5'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
}

$tabName = "philirioral";
$subj = "Filipino";


$PI = "Phil-Iri Filipino Oral";
$PI2 = "Phil-Iri ";
$PI3 = "Filipino Oral";

include "PHP/tables4.php";
include "PHP/graph4.php";

?>

<script type="text/javascript">
	
	window.onload = function() {
 	
		CanvasJS.addColorSet("dataColors",
		[//colorSet Array
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#0086b3",
	        "#40ff00",
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90"                
	    ]);
		
		CanvasJS.addColorSet("dataColors2",
		[//colorSet Array
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#ffff00",
	        "#0086b3",
	        "#40ff00",
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d"              
	    ]);

	    CanvasJS.addColorSet("dataColors3",
		[//colorSet Array
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#0086b3",
	        "#40ff00"                
	    ]);

	     CanvasJS.addColorSet("dataColors4",
		[//colorSet Array
			"#cc0099",
	        "#3CB371",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#90EE90",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#8a8a5c",
	        "#669999",
	        "#00b3b3",
	        "#804000",
	        "#0086b3",
	        "#40ff00"                
	    ]);
//grande3
		var chartA1 = new CanvasJS.Chart("chartContainer1A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade3)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA1s = new CanvasJS.Chart("chartContainer1As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA1a = new CanvasJS.Chart("chartContainer1Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Male Pre Result (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA1b = new CanvasJS.Chart("chartContainer1Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Phil-Iri Filipino Oral Female Pre Result (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA12 = new CanvasJS.Chart("chartContainer1A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade3)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA12s = new CanvasJS.Chart("chartContainer1A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA12a = new CanvasJS.Chart("chartContainer1A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartA12b = new CanvasJS.Chart("chartContainer1A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//grande4
		var chartB1 = new CanvasJS.Chart("chartContainer1B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade4)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB1s = new CanvasJS.Chart("chartContainer1Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB1a = new CanvasJS.Chart("chartContainer1Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Male Pre Result (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB1b = new CanvasJS.Chart("chartContainer1Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Phil-Iri Filipino Oral Female Pre Result (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB12 = new CanvasJS.Chart("chartContainer1B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade4)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB12s = new CanvasJS.Chart("chartContainer1B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB12a = new CanvasJS.Chart("chartContainer1B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartB12b = new CanvasJS.Chart("chartContainer1B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//grande5
		var chartC1 = new CanvasJS.Chart("chartContainer1C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade5)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC1s = new CanvasJS.Chart("chartContainer1Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC1a = new CanvasJS.Chart("chartContainer1Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Male Pre Result (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC1b = new CanvasJS.Chart("chartContainer1Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Phil-Iri Filipino Oral Female Pre Result (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC12 = new CanvasJS.Chart("chartContainer1C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade5)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC12s = new CanvasJS.Chart("chartContainer1C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC12a = new CanvasJS.Chart("chartContainer1C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartC12b = new CanvasJS.Chart("chartContainer1C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//grande6
		var chartD1 = new CanvasJS.Chart("chartContainer1D", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade6)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1D, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD1s = new CanvasJS.Chart("chartContainer1Ds", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1D, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD1a = new CanvasJS.Chart("chartContainer1Da", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Male Pre Result (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Da, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD1b = new CanvasJS.Chart("chartContainer1Db", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Phil-Iri Filipino Oral Female Pre Result (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Db, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD12 = new CanvasJS.Chart("chartContainer1D2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade6)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1D2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD12s = new CanvasJS.Chart("chartContainer1D2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1D2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD12a = new CanvasJS.Chart("chartContainer1D2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1D2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartD12b = new CanvasJS.Chart("chartContainer1D2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1D2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//grande7
		var chartE1 = new CanvasJS.Chart("chartContainer1E", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade7)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1E, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE1s = new CanvasJS.Chart("chartContainer1Es", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Phil-Iri Filipino Oral Pre Result (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1E, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE1a = new CanvasJS.Chart("chartContainer1Ea", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Male Pre Result (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ea, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE1b = new CanvasJS.Chart("chartContainer1Eb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Phil-Iri Filipino Oral Female Pre Result (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Eb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE12 = new CanvasJS.Chart("chartContainer1E2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade7)"
		  },
		  height: 440,
		  width: 610,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1E2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE12s = new CanvasJS.Chart("chartContainer1E2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1E2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE12a = new CanvasJS.Chart("chartContainer1E2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1E2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartE12b = new CanvasJS.Chart("chartContainer1E2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Phil-Iri Filipino Oral Post Result (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1E2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//Render
		chartA1.render();
		chartA1s.render();
		chartA1a.render();
		chartA1b.render();
		chartA12.render();
		chartA12a.render();
		chartA12b.render();
		chartA12s.render();

		chartB1.render();
		chartB1s.render();
		chartB1a.render();
		chartB1b.render();
		chartB12.render();
		chartB12a.render();
		chartB12b.render();
		chartB12s.render();

		chartC1.render();
		chartC1s.render();
		chartC1a.render();
		chartC1b.render();
		chartC12.render();
		chartC12a.render();
		chartC12b.render();
		chartC12s.render();

		chartD1.render();
		chartD1s.render();
		chartD1a.render();
		chartD1b.render();
		chartD12.render();
		chartD12a.render();
		chartD12b.render();
		chartD12s.render();

		chartE1.render();
		chartE1s.render();
		chartE1a.render();
		chartE1b.render();
		chartE12.render();
		chartE12a.render();
		chartE12b.render();
		chartE12s.render();

	}
</script>

<div class="contents">
	
	<div class="GroupButCont" style="height: 170%;">
		<div class="butHolder">
			<button id="ElemButton" class="tablinks <?php if ($_SESSION['display'] == "Page1") {echo "active";}?>" onclick="change(event, 'Grade3')" style="height: 19.2%;">
				<i class="fas fa-user-tie fa-1x"></i>
				<span class="tooltiptext">Grade 3</span>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page2") {echo "active";}?>" onclick="change(event, 'Grade4')" style="height: 19.2%;">
				<i class="fas fa-user-friends fa-1x"></i>
				<span class="tooltiptext">Grade 4</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page3") {echo "active";}?>" onclick="change(event, 'Grade5')" style="height: 19.2%;">
				<i class="fas fa-users fa-1x"></i>
				<span class="tooltiptext">Grade 5</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page4") {echo "active";}?>" onclick="change(event, 'Grade6')" style="height: 19.2%;">
				<i class="fas fa-user-edit"></i>
				<span class="tooltiptext">Grade 6</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page5") {echo "active";}?>" onclick="change(event, 'Grade7')" style="height: 19.2%;">
				<i class="fas fa-user-graduate"></i>
				<span class="tooltiptext">Grade 7</span>
			</button>
		</div>
	</div>
	
	<div id="Grade3" class="leftTab" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?> >
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page1") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin != "none") {
						for ($i=$grossmin; $i <= $grossmax; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="FOgrd3">Go</button>
		</form>

		<div class="graphCont2">
			<div class="leftGraph">
				<div id="graphZoom11a" class="GraphBorder1">
					<div id="chartContainer1A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom11b" class="GraphBorder2">
					<div id="chartContainer1A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory Filipino Oral (Grade 3) </h3>
		   	</center>
		   	<button type="button" id="exportBut1" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table border='1' width='100%' id="myTableg1">
	              <tr>
	                <td colspan="2">School</td>
	                <td colspan="6">Enrolment</td><td colspan="6">PUPIL TESTED</td><td colspan="6">FRUSTRATION</td>
	                <td colspan="6">INSTRUCTIONAL</td><td colspan="6">INDEPENDENT</td><td colspan="6">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan="2"> </td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	              </tr>
	              <tr>
	                <td colspan="2"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>
	              	<?php
	              	if (mysqli_num_rows($tbresult)>0) {
		              	for ($tbl=0; $tbl < $tblnm['ttldata']; $tbl++){ 
				            $tblrow = mysqli_fetch_array($tbresult);
				            $tblrow2 = mysqli_fetch_array($tblpre);
				            $tblrow3 = mysqli_fetch_array($tblpost);
				            echo "<td colspan=\"2\">".$tblrow['School']."</td>
				                  <td>".$tblrow2['ermale']."</td>
				                  <td>".$tblrow2['erfemale']."</td>
				                  <td>".$tblrow2['ermale']+$tblrow2['erfemale']."</td>
				                  <td>".$tblrow3['ermale']."</td>
				                  <td>".$tblrow3['erfemale']."</td>
				                  <td>".$tblrow3['ermale']+$tblrow3['erfemale']."</td>

				                  <td>".$tblrow2['ptmale']."</td>
				                  <td>".$tblrow2['ptfemale']."</td>
				                  <td>".$tblrow2['ptmale']+$tblrow2['ptfemale']."</td>
				                  <td>".$tblrow3['ptmale']."</td>
				                  <td>".$tblrow3['ptfemale']."</td>
				                  <td>".$tblrow3['ptmale']+$tblrow3['ptfemale']."</td>

				                  <td>".$tblrow2['ftmale']."</td>
				                  <td>".$tblrow2['ftfemale']."</td>
				                  <td>".$tblrow2['ftmale']+$tblrow2['ftfemale']."</td>
				                  <td>".$tblrow3['ftmale']."</td>
				                  <td>".$tblrow3['ftfemale']."</td>
				                  <td>".$tblrow3['ftmale']+$tblrow3['ftfemale']."</td>

				                  <td>".$tblrow2['itmale']."</td>
				                  <td>".$tblrow2['itfemale']."</td>
				                  <td>".$tblrow2['itmale']+$tblrow2['itfemale']."</td>
				                  <td>".$tblrow3['itmale']."</td>
				                  <td>".$tblrow3['itfemale']."</td>
				                  <td>".$tblrow3['itmale']+$tblrow3['itfemale']."</td>

				                  <td>".$tblrow2['idmale']."</td>
				                  <td>".$tblrow2['idfemale']."</td>
				                  <td>".$tblrow2['idmale']+$tblrow2['idfemale']."</td>
				                  <td>".$tblrow3['idmale']."</td>
				                  <td>".$tblrow3['idfemale']."</td>
				                  <td>".$tblrow3['idmale']+$tblrow3['idfemale']."</td>

				                  <td>".$tblrow2['nrmale']."</td>
				                  <td>".$tblrow2['nrfemale']."</td>
				                  <td>".$tblrow2['nrmale']+$tblrow2['nrfemale']."</td>
				                  <td>".$tblrow3['nrmale']."</td>
				                  <td>".$tblrow3['nrfemale']."</td>
				                  <td>".$tblrow3['nrmale']+$tblrow3['nrfemale']."</td>";
				          echo "</tr>";
			      		}
			      	}
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade4" class="leftTab" <?php if ($_SESSION['display'] == "Page2") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page2") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin2 != "none") {
						for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime2."-".($chosenTime2+1)."</option>";
					for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="FOgrd4">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom12a" class="GraphBorder1">
					<div id="chartContainer1B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom12b" class="GraphBorder2">
					<div id="chartContainer1B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
		   <center>
		      <h3>Philippine Independent Reading Inventory Filipino Oral (Grade 4) </h3>
		   	</center>
		   	<button type="button" id="exportBut2" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table border='1' width='100%' id="myTableg2">
	              <tr>
	                <td colspan="2">School</td>
	                <td colspan="6">Enrolment</td><td colspan="6">PUPIL TESTED</td><td colspan="6">FRUSTRATION</td>
	                <td colspan="6">INSTRUCTIONAL</td><td colspan="6">INDEPENDENT</td><td colspan="6">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan="2"> </td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	              </tr>
	              <tr>
	                <td colspan="2"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>
	              	<?php
	              	if (mysqli_num_rows($tbresult2)>0) {
		              	for ($tbl2=0; $tbl2 < $tblnm2['ttldata']; $tbl2++){ 
				            $tblrow2 = mysqli_fetch_array($tbresult2);
				            $tblrow22 = mysqli_fetch_array($tblpre2);
				            $tblrow32 = mysqli_fetch_array($tblpost2);
				            echo "<td colspan=\"2\">".$tblrow2['School']."</td>
				                  <td>".$tblrow22['ermale']."</td>
				                  <td>".$tblrow22['erfemale']."</td>
				                  <td>".$tblrow22['ermale']+$tblrow22['erfemale']."</td>
				                  <td>".$tblrow32['ermale']."</td>
				                  <td>".$tblrow32['erfemale']."</td>
				                  <td>".$tblrow32['ermale']+$tblrow32['erfemale']."</td>

				                  <td>".$tblrow22['ptmale']."</td>
				                  <td>".$tblrow22['ptfemale']."</td>
				                  <td>".$tblrow22['ptmale']+$tblrow22['ptfemale']."</td>
				                  <td>".$tblrow32['ptmale']."</td>
				                  <td>".$tblrow32['ptfemale']."</td>
				                  <td>".$tblrow32['ptmale']+$tblrow32['ptfemale']."</td>

				                  <td>".$tblrow22['ftmale']."</td>
				                  <td>".$tblrow22['ftfemale']."</td>
				                  <td>".$tblrow22['ftmale']+$tblrow22['ftfemale']."</td>
				                  <td>".$tblrow32['ftmale']."</td>
				                  <td>".$tblrow32['ftfemale']."</td>
				                  <td>".$tblrow32['ftmale']+$tblrow32['ftfemale']."</td>

				                  <td>".$tblrow22['itmale']."</td>
				                  <td>".$tblrow22['itfemale']."</td>
				                  <td>".$tblrow22['itmale']+$tblrow22['itfemale']."</td>
				                  <td>".$tblrow32['itmale']."</td>
				                  <td>".$tblrow32['itfemale']."</td>
				                  <td>".$tblrow32['itmale']+$tblrow32['itfemale']."</td>

				                  <td>".$tblrow22['idmale']."</td>
				                  <td>".$tblrow22['idfemale']."</td>
				                  <td>".$tblrow22['idmale']+$tblrow22['idfemale']."</td>
				                  <td>".$tblrow32['idmale']."</td>
				                  <td>".$tblrow32['idfemale']."</td>
				                  <td>".$tblrow32['idmale']+$tblrow32['idfemale']."</td>

				                  <td>".$tblrow22['nrmale']."</td>
				                  <td>".$tblrow22['nrfemale']."</td>
				                  <td>".$tblrow22['nrmale']+$tblrow22['nrfemale']."</td>
				                  <td>".$tblrow32['nrmale']."</td>
				                  <td>".$tblrow32['nrfemale']."</td>
				                  <td>".$tblrow32['nrmale']+$tblrow32['nrfemale']."</td>";
				          echo "</tr>";
			      		}
			      	}
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade5" class="leftTab" <?php if ($_SESSION['display'] == "Page3") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page3") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin3 != "none") {
						for ($i=$grossmin3; $i <= $grossmax3; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime3."-".($chosenTime3+1)."</option>";
					for ($i=$grossmin3; $i <= $grossmax3; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="FOgrd5">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom13a" class="GraphBorder1">
					<div id="chartContainer1C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom13b" class="GraphBorder2">
					<div id="chartContainer1C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory Filipino Oral (Grade 5) </h3>
		   	</center>
		   	<button type="button" id="exportBut3" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table border='1' width='100%' id="myTableg3">
	              <tr>
	                <td colspan="2">School</td>
	                <td colspan="6">Enrolment</td><td colspan="6">PUPIL TESTED</td><td colspan="6">FRUSTRATION</td>
	                <td colspan="6">INSTRUCTIONAL</td><td colspan="6">INDEPENDENT</td><td colspan="6">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan="2"> </td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	              </tr>
	              <tr>
	                <td colspan="2"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>
	              	<?php
	              	if (mysqli_num_rows($tbresult3)>0) {
		              	for ($tbl3=0; $tbl3 < $tblnm3['ttldata']; $tbl3++){ 
				            $tblrow3 = mysqli_fetch_array($tbresult3);
				            $tblrow23 = mysqli_fetch_array($tblpre3);
				            $tblrow33 = mysqli_fetch_array($tblpost3);
				            echo "<td colspan=\"2\">".$tblrow3['School']."</td>
				                  <td>".$tblrow23['ermale']."</td>
				                  <td>".$tblrow23['erfemale']."</td>
				                  <td>".$tblrow23['ermale']+$tblrow23['erfemale']."</td>
				                  <td>".$tblrow33['ermale']."</td>
				                  <td>".$tblrow33['erfemale']."</td>
				                  <td>".$tblrow33['ermale']+$tblrow33['erfemale']."</td>

				                  <td>".$tblrow23['ptmale']."</td>
				                  <td>".$tblrow23['ptfemale']."</td>
				                  <td>".$tblrow23['ptmale']+$tblrow23['ptfemale']."</td>
				                  <td>".$tblrow33['ptmale']."</td>
				                  <td>".$tblrow33['ptfemale']."</td>
				                  <td>".$tblrow33['ptmale']+$tblrow33['ptfemale']."</td>

				                  <td>".$tblrow23['ftmale']."</td>
				                  <td>".$tblrow23['ftfemale']."</td>
				                  <td>".$tblrow23['ftmale']+$tblrow23['ftfemale']."</td>
				                  <td>".$tblrow33['ftmale']."</td>
				                  <td>".$tblrow33['ftfemale']."</td>
				                  <td>".$tblrow33['ftmale']+$tblrow33['ftfemale']."</td>

				                  <td>".$tblrow23['itmale']."</td>
				                  <td>".$tblrow23['itfemale']."</td>
				                  <td>".$tblrow23['itmale']+$tblrow23['itfemale']."</td>
				                  <td>".$tblrow33['itmale']."</td>
				                  <td>".$tblrow33['itfemale']."</td>
				                  <td>".$tblrow33['itmale']+$tblrow33['itfemale']."</td>

				                  <td>".$tblrow23['idmale']."</td>
				                  <td>".$tblrow23['idfemale']."</td>
				                  <td>".$tblrow23['idmale']+$tblrow23['idfemale']."</td>
				                  <td>".$tblrow33['idmale']."</td>
				                  <td>".$tblrow33['idfemale']."</td>
				                  <td>".$tblrow33['idmale']+$tblrow33['idfemale']."</td>

				                  <td>".$tblrow23['nrmale']."</td>
				                  <td>".$tblrow23['nrfemale']."</td>
				                  <td>".$tblrow23['nrmale']+$tblrow23['nrfemale']."</td>
				                  <td>".$tblrow33['nrmale']."</td>
				                  <td>".$tblrow33['nrfemale']."</td>
				                  <td>".$tblrow33['nrmale']+$tblrow33['nrfemale']."</td>";
				          echo "</tr>";
			      		}
			      	}
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade6" class="leftTab" <?php if ($_SESSION['display'] == "Page4") {echo "style=\"display:block;\" ";}?> >
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page4") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin4 != "none") {
						for ($i=$grossmin4; $i <= $grossmax4; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime4."-".($chosenTime4+1)."</option>";
					for ($i=$grossmin4; $i <= $grossmax4; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="FOgrd6">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom14a" class="GraphBorder1">
					<div id="chartContainer1D" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom14b" class="GraphBorder2">
					<div id="chartContainer1D2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory Filipino Oral (Grade6) </h3>
		   	</center>
		   	<button type="button" id="exportBut4" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table border='1' width='100%' id="myTableg4">
	              <tr>
	                <td colspan="2">School</td>
	                <td colspan="6">Enrolment</td><td colspan="6">PUPIL TESTED</td><td colspan="6">FRUSTRATION</td>
	                <td colspan="6">INSTRUCTIONAL</td><td colspan="6">INDEPENDENT</td><td colspan="6">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan="2"> </td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	              </tr>
	              <tr>
	                <td colspan="2"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>
	              	<?php
	              	if (mysqli_num_rows($tbresult4)>0) {
		              	for ($tbl3=0; $tbl3 < $tblnm4['ttldata']; $tbl3++){ 
				            $tblrow4 = mysqli_fetch_array($tbresult4);
				            $tblrow24 = mysqli_fetch_array($tblpre4);
				            $tblrow34 = mysqli_fetch_array($tblpost4);
				            echo "<td colspan=\"2\">".$tblrow4['School']."</td>
				                  <td>".$tblrow24['ermale']."</td>
				                  <td>".$tblrow24['erfemale']."</td>
				                  <td>".$tblrow24['ermale']+$tblrow24['erfemale']."</td>
				                  <td>".$tblrow34['ermale']."</td>
				                  <td>".$tblrow34['erfemale']."</td>
				                  <td>".$tblrow34['ermale']+$tblrow34['erfemale']."</td>

				                  <td>".$tblrow24['ptmale']."</td>
				                  <td>".$tblrow24['ptfemale']."</td>
				                  <td>".$tblrow24['ptmale']+$tblrow24['ptfemale']."</td>
				                  <td>".$tblrow34['ptmale']."</td>
				                  <td>".$tblrow34['ptfemale']."</td>
				                  <td>".$tblrow34['ptmale']+$tblrow34['ptfemale']."</td>

				                  <td>".$tblrow24['ftmale']."</td>
				                  <td>".$tblrow24['ftfemale']."</td>
				                  <td>".$tblrow24['ftmale']+$tblrow24['ftfemale']."</td>
				                  <td>".$tblrow34['ftmale']."</td>
				                  <td>".$tblrow34['ftfemale']."</td>
				                  <td>".$tblrow34['ftmale']+$tblrow34['ftfemale']."</td>

				                  <td>".$tblrow24['itmale']."</td>
				                  <td>".$tblrow24['itfemale']."</td>
				                  <td>".$tblrow24['itmale']+$tblrow24['itfemale']."</td>
				                  <td>".$tblrow34['itmale']."</td>
				                  <td>".$tblrow34['itfemale']."</td>
				                  <td>".$tblrow34['itmale']+$tblrow34['itfemale']."</td>

				                  <td>".$tblrow24['idmale']."</td>
				                  <td>".$tblrow24['idfemale']."</td>
				                  <td>".$tblrow24['idmale']+$tblrow24['idfemale']."</td>
				                  <td>".$tblrow34['idmale']."</td>
				                  <td>".$tblrow34['idfemale']."</td>
				                  <td>".$tblrow34['idmale']+$tblrow34['idfemale']."</td>

				                  <td>".$tblrow24['nrmale']."</td>
				                  <td>".$tblrow24['nrfemale']."</td>
				                  <td>".$tblrow24['nrmale']+$tblrow24['nrfemale']."</td>
				                  <td>".$tblrow34['nrmale']."</td>
				                  <td>".$tblrow34['nrfemale']."</td>
				                  <td>".$tblrow34['nrmale']+$tblrow34['nrfemale']."</td>";
				          echo "</tr>";
			      		}
			      	}
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade7" class="leftTab" <?php if ($_SESSION['display'] == "Page5") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page5") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin5 != "none") {
						for ($i=$grossmin5; $i <= $grossmax5; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime5."-".($chosenTime5+1)."</option>";
					for ($i=$grossmin5; $i <= $grossmax5; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="FOgrd7">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom15a" class="GraphBorder1">
					<div id="chartContainer1E" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom15b" class="GraphBorder2">
					<div id="chartContainer1E2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory Filipino Oral (Grade 7) </h3>
		   	</center>
		   	<button type="button" id="exportBut5" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table border='1' width='100%' id="myTableg5">
	              <tr>
	                <td colspan="2">School</td>
	                <td colspan="6">Enrolment</td><td colspan="6">PUPIL TESTED</td><td colspan="6">FRUSTRATION</td>
	                <td colspan="6">INSTRUCTIONAL</td><td colspan="6">INDEPENDENT</td><td colspan="6">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan="2"> </td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                <td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	              </tr>
	              <tr>
	                <td colspan="2"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>
	              	<?php
	              	if (mysqli_num_rows($tbresult5)>0) {
		              	for ($tbl3=0; $tbl3 < $tblnm5['ttldata']; $tbl3++){ 
				            $tblrow5 = mysqli_fetch_array($tbresult5);
				            $tblrow25 = mysqli_fetch_array($tblpre5);
				            $tblrow35 = mysqli_fetch_array($tblpost5);
				            echo "<td colspan=\"2\">".$tblrow4['School']."</td>
				                  <td>".$tblrow25['ermale']."</td>
				                  <td>".$tblrow25['erfemale']."</td>
				                  <td>".$tblrow25['ermale']+$tblrow25['erfemale']."</td>
				                  <td>".$tblrow35['ermale']."</td>
				                  <td>".$tblrow35['erfemale']."</td>
				                  <td>".$tblrow35['ermale']+$tblrow35['erfemale']."</td>

				                  <td>".$tblrow25['ptmale']."</td>
				                  <td>".$tblrow25['ptfemale']."</td>
				                  <td>".$tblrow25['ptmale']+$tblrow25['ptfemale']."</td>
				                  <td>".$tblrow35['ptmale']."</td>
				                  <td>".$tblrow35['ptfemale']."</td>
				                  <td>".$tblrow35['ptmale']+$tblrow35['ptfemale']."</td>

				                  <td>".$tblrow25['ftmale']."</td>
				                  <td>".$tblrow25['ftfemale']."</td>
				                  <td>".$tblrow25['ftmale']+$tblrow25['ftfemale']."</td>
				                  <td>".$tblrow35['ftmale']."</td>
				                  <td>".$tblrow35['ftfemale']."</td>
				                  <td>".$tblrow35['ftmale']+$tblrow35['ftfemale']."</td>

				                  <td>".$tblrow25['itmale']."</td>
				                  <td>".$tblrow25['itfemale']."</td>
				                  <td>".$tblrow25['itmale']+$tblrow25['itfemale']."</td>
				                  <td>".$tblrow35['itmale']."</td>
				                  <td>".$tblrow35['itfemale']."</td>
				                  <td>".$tblrow35['itmale']+$tblrow35['itfemale']."</td>

				                  <td>".$tblrow25['idmale']."</td>
				                  <td>".$tblrow25['idfemale']."</td>
				                  <td>".$tblrow25['idmale']+$tblrow25['idfemale']."</td>
				                  <td>".$tblrow35['idmale']."</td>
				                  <td>".$tblrow35['idfemale']."</td>
				                  <td>".$tblrow35['idmale']+$tblrow35['idfemale']."</td>

				                  <td>".$tblrow25['nrmale']."</td>
				                  <td>".$tblrow25['nrfemale']."</td>
				                  <td>".$tblrow25['nrmale']+$tblrow25['nrfemale']."</td>
				                  <td>".$tblrow35['nrmale']."</td>
				                  <td>".$tblrow35['nrfemale']."</td>
				                  <td>".$tblrow35['nrmale']+$tblrow35['nrfemale']."</td>";
				          echo "</tr>";
			      		}
			      	}
	              	?>
	            </table>
        	</div>
		</div>
	</div>

</div>

<div id="GrapModal1a" class="graphModal1">
	<span class="graphClose1a">&times;</span>
	<div id="chartContainer1As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal1b" class="graphModal1">
	<span class="graphClose1b">&times;</span>
	<div id="chartContainer1A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal2a" class="graphModal1">
	<span class="graphClose2a">&times;</span>
	<div id="chartContainer1Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal2b" class="graphModal1">
	<span class="graphClose2b">&times;</span>
	<div id="chartContainer1B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal3a" class="graphModal1">
	<span class="graphClose3a">&times;</span>
	<div id="chartContainer1Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal3b" class="graphModal1">
	<span class="graphClose3b">&times;</span>
	<div id="chartContainer1C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal4a" class="graphModal1">
	<span class="graphClose4a">&times;</span>
	<div id="chartContainer1Ds" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Da" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Db" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal4b" class="graphModal1">
	<span class="graphClose4b">&times;</span>
	<div id="chartContainer1D2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1D2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1D2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal5a" class="graphModal1">
	<span class="graphClose5a">&times;</span>
	<div id="chartContainer1Es" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ea" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Eb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal5b" class="graphModal1">
	<span class="graphClose5b">&times;</span>
	<div id="chartContainer1E2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1E2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1E2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<script>

	var modal1a = document.getElementById("GrapModal1a");
	var modal1b = document.getElementById("GrapModal1b");
	var modal2a = document.getElementById("GrapModal2a");
	var modal2b = document.getElementById("GrapModal2b");
	var modal3a = document.getElementById("GrapModal3a");
	var modal3b = document.getElementById("GrapModal3b");
	var modal4a = document.getElementById("GrapModal4a");
	var modal4b = document.getElementById("GrapModal4b");
	var modal5a = document.getElementById("GrapModal5a");
	var modal5b = document.getElementById("GrapModal5b");

	var btn1a = document.getElementById("graphZoom11a");	
	var btn1b = document.getElementById("graphZoom11b");
	var btn2a = document.getElementById("graphZoom12a");	
	var btn2b = document.getElementById("graphZoom12b");
	var btn3a = document.getElementById("graphZoom13a");	
	var btn3b = document.getElementById("graphZoom13b");
	var btn4a = document.getElementById("graphZoom14a");	
	var btn4b = document.getElementById("graphZoom14b");
	var btn5a = document.getElementById("graphZoom15a");	
	var btn5b = document.getElementById("graphZoom15b");

	var span1a = document.getElementsByClassName("graphClose1a")[0];
	var span1b = document.getElementsByClassName("graphClose1b")[0];
	var span2a = document.getElementsByClassName("graphClose2a")[0];
	var span2b = document.getElementsByClassName("graphClose2b")[0];
	var span3a = document.getElementsByClassName("graphClose3a")[0];
	var span3b = document.getElementsByClassName("graphClose3b")[0];
	var span4a = document.getElementsByClassName("graphClose4a")[0];
	var span4b = document.getElementsByClassName("graphClose4b")[0];
	var span5a = document.getElementsByClassName("graphClose5a")[0];
	var span5b = document.getElementsByClassName("graphClose5b")[0];

	btn1a.onclick = function() {
	  modal1a.style.display = "block";
	}
	btn1b.onclick = function() {
	  modal1b.style.display = "block";
	}
	btn2a.onclick = function() {
	  modal2a.style.display = "block";
	}
	btn2b.onclick = function() {
	  modal2b.style.display = "block";
	}
	btn3a.onclick = function() {
	  modal3a.style.display = "block";
	}
	btn3b.onclick = function() {
	  modal3b.style.display = "block";
	}
	btn4a.onclick = function() {
	  modal4a.style.display = "block";
	}
	btn4b.onclick = function() {
	  modal4b.style.display = "block";
	}
	btn5a.onclick = function() {
	  modal5a.style.display = "block";
	}
	btn5b.onclick = function() {
	  modal5b.style.display = "block";
	}

	span1a.onclick = function() {
	  modal1a.style.display = "none";
	}
	span1b.onclick = function() {
	  modal1b.style.display = "none";
	}
	span2a.onclick = function() {
	  modal2a.style.display = "none";
	}
	span2b.onclick = function() {
	  modal2b.style.display = "none";
	}
	span3a.onclick = function() {
	  modal3a.style.display = "none";
	}
	span3b.onclick = function() {
	  modal3b.style.display = "none";
	}
	span4a.onclick = function() {
	  modal4a.style.display = "none";
	}
	span4b.onclick = function() {
	  modal4b.style.display = "none";
	}
	span5a.onclick = function() {
	  modal5a.style.display = "none";
	}
	span5b.onclick = function() {
	  modal5b.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal1a) {
	    modal1a.style.display = "none";
	  }
	  if(event.target == modal1b){
	  	modal1b.style.display = "none";
	  }
	  if (event.target == modal2a) {
	    modal2a.style.display = "none";
	  }
	  if(event.target == modal2b){
	  	modal2b.style.display = "none";
	  }
	  if (event.target == modal3a) {
	    modal3a.style.display = "none";
	  }
	  if(event.target == modal3b){
	  	modal3b.style.display = "none";
	  }
	  if (event.target == modal4a) {
	    modal4a.style.display = "none";
	  }
	  if(event.target == modal4b){
	  	modal4b.style.display = "none";
	  }
	  if (event.target == modal5a) {
	    modal5a.style.display = "none";
	  }
	  if(event.target == modal5b){
	  	modal5b.style.display = "none";
	  }
	}

	function html_table_to_excel1(type){
	    var data = document.getElementById('myTableg1');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 3).' + type);
		}

	    const export_button1 = document.getElementById('exportBut1');

	    export_button1.addEventListener('click', () =>  {
	    	html_table_to_excel1('xlsx');
	});

	function html_table_to_excel2(type){
	    var data = document.getElementById('myTableg2');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 4).' + type);
		}

	    const export_button2 = document.getElementById('exportBut2');

	    export_button2.addEventListener('click', () =>  {
	    	html_table_to_excel2('xlsx');
	});

	function html_table_to_excel3(type){
	    var data = document.getElementById('myTableg3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 5).' + type);
		}

	    const export_button3 = document.getElementById('exportBut3');

	    export_button3.addEventListener('click', () =>  {
	    	html_table_to_excel3('xlsx');
	});

	function html_table_to_excel4(type){
	    var data = document.getElementById('myTableg4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 6).' + type);
		}

	    const export_button4 = document.getElementById('exportBut4');

	    export_button4.addEventListener('click', () =>  {
	    	html_table_to_excel3('xlsx');
	});

	function html_table_to_excel5(type){
	    var data = document.getElementById('myTableg5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 7).' + type);
		}

	    const export_button5 = document.getElementById('exportBut5');

	    export_button5.addEventListener('click', () =>  {
	    	html_table_to_excel5('xlsx');
	});

</script>

<script type="text/javascript" src="Script/animation.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>