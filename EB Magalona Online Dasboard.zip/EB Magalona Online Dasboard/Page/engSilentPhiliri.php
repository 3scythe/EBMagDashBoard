<?php 
include "Header.php";

session_start();

$grossmin = $_SESSION['timeMin1'];
$grossmax = $_SESSION['timeMax1'];

$grossmin2 = $_SESSION['timeMin2'];
$grossmax2 = $_SESSION['timeMax2'];

$grossmin3 = $_SESSION['timeMin3'];
$grossmax3 = $_SESSION['timeMax3'];

$grossmin4 = $_SESSION['timeMin4'];
$grossmax4 = $_SESSION['timeMax4'];

$grossmin5 = $_SESSION['timeMin5'];
$grossmax5 = $_SESSION['timeMax5'];

if($_SESSION['display'] == "none"){
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page1"){
	$chosenTime = $_SESSION['theTime'];
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
	
}
elseif($_SESSION['display'] == "Page2"){
	$chosenTime2 = $_SESSION['theTime2'];
	$chosenTime = $grossmax;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
	
}
elseif($_SESSION['display'] == "Page3"){
	$chosenTime3 = $_SESSION['theTime3'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime4 = $grossmax4;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page4"){
	$chosenTime4 = $_SESSION['theTime4'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime5 = $grossmax5;
}
elseif($_SESSION['display'] == "Page5"){
	$chosenTime5 = $_SESSION['theTime5'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	$chosenTime4 = $grossmax4;
}

$tabName = "philirisilent";
$subj = "English";


$PI = "Phil-Iri English Silent";
$PI2 = "Phil-Iri";
$PI3 = "English Silent";

include "PHP/tables5.php";
include "PHP/graph5.php";

?>

<script type="text/javascript">
	
	window.onload = function() {
 	
		CanvasJS.addColorSet("dataColors",
		[//colorSet Array
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#0086b3",
	        "#40ff00",
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90"                
	    ]);
		
		CanvasJS.addColorSet("dataColors2",
		[//colorSet Array
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#ffff00",
	        "#0086b3",
	        "#40ff00",
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d"              
	    ]);

	    CanvasJS.addColorSet("dataColors3",
		[//colorSet Array
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#90EE90",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#cc0099",
	        "#0086b3",
	        "#40ff00"                
	    ]);

	     CanvasJS.addColorSet("dataColors4",
		[//colorSet Array
			"#cc0099",
	        "#3CB371",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#90EE90",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#cca300",
	        "#0000b3",
	        "#b30047",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#8a8a5c",
	        "#669999",
	        "#00b3b3",
	        "#804000",
	        "#0086b3",
	        "#40ff00"                
	    ]);

	    CanvasJS.addColorSet("dataColors5",
		[//colorSet Array
	        "#cca300",
	        "#cc0099",
	        "#8a8a5c",
	        "#e62e00",
	        "#008080",
	        "#6666ff",
	        "#669999",
	        "#3CB371",
	        "#ff0000",
	        "#0000ff",
	        "#00b300",
	        "#cccc00",
	        "#6600ff",
	        "#993399",
	        "#003399",
	        "#00994d",
	        "#ffff00",
	        "#2E8B57",
	        "#00ff00",
	        "#0000b3",
	        "#b30047",
	        "#00b3b3",
	        "#804000",
	        "#0086b3",
	        "#40ff00",
	        "#90EE90"                
	    ]);

//grande3
		var chart1A = new CanvasJS.Chart("chartContainer1A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1As = new CanvasJS.Chart("chartContainer1As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Aa = new CanvasJS.Chart("chartContainer1Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Ab = new CanvasJS.Chart("chartContainer1Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1B = new CanvasJS.Chart("chartContainer1B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Bs = new CanvasJS.Chart("chartContainer1Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Ba = new CanvasJS.Chart("chartContainer1Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Bb = new CanvasJS.Chart("chartContainer1Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1C = new CanvasJS.Chart("chartContainer1C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Cs = new CanvasJS.Chart("chartContainer1Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Ca = new CanvasJS.Chart("chartContainer1Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1Cb = new CanvasJS.Chart("chartContainer1Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//post
		var chart1A2 = new CanvasJS.Chart("chartContainer1A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1A2s = new CanvasJS.Chart("chartContainer1A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1A2a = new CanvasJS.Chart("chartContainer1A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1A2b = new CanvasJS.Chart("chartContainer1A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1B2 = new CanvasJS.Chart("chartContainer1B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors5",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1B2s = new CanvasJS.Chart("chartContainer1B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1B2a = new CanvasJS.Chart("chartContainer1B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1B2b = new CanvasJS.Chart("chartContainer1B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1C2 = new CanvasJS.Chart("chartContainer1C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1C2s = new CanvasJS.Chart("chartContainer1C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1C2a = new CanvasJS.Chart("chartContainer1C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart1C2b = new CanvasJS.Chart("chartContainer1C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints1C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//grande4
		var chart2A = new CanvasJS.Chart("chartContainer2A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2As = new CanvasJS.Chart("chartContainer2As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Aa = new CanvasJS.Chart("chartContainer2Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Ab = new CanvasJS.Chart("chartContainer2Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2B = new CanvasJS.Chart("chartContainer2B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Bs = new CanvasJS.Chart("chartContainer2Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Ba = new CanvasJS.Chart("chartContainer2Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Bb = new CanvasJS.Chart("chartContainer2Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2C = new CanvasJS.Chart("chartContainer2C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Cs = new CanvasJS.Chart("chartContainer2Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Ca = new CanvasJS.Chart("chartContainer2Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2Cb = new CanvasJS.Chart("chartContainer2Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//post
		var chart2A2 = new CanvasJS.Chart("chartContainer2A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2A2s = new CanvasJS.Chart("chartContainer2A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2A2a = new CanvasJS.Chart("chartContainer2A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2A2b = new CanvasJS.Chart("chartContainer2A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2B2 = new CanvasJS.Chart("chartContainer2B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors5",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2B2s = new CanvasJS.Chart("chartContainer2B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2B2a = new CanvasJS.Chart("chartContainer2B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2B2b = new CanvasJS.Chart("chartContainer2B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2C2 = new CanvasJS.Chart("chartContainer2C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Post Reading Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints2C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2C2s = new CanvasJS.Chart("chartContainer2C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2C2a = new CanvasJS.Chart("chartContainer2C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart2C2b = new CanvasJS.Chart("chartContainer2C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints2C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//grande5
		var chart3A = new CanvasJS.Chart("chartContainer3A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3As = new CanvasJS.Chart("chartContainer3As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Aa = new CanvasJS.Chart("chartContainer3Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Ab = new CanvasJS.Chart("chartContainer3Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3B = new CanvasJS.Chart("chartContainer3B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Bs = new CanvasJS.Chart("chartContainer3Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Ba = new CanvasJS.Chart("chartContainer3Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Bb = new CanvasJS.Chart("chartContainer3Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3C = new CanvasJS.Chart("chartContainer3C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Cs = new CanvasJS.Chart("chartContainer3Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Ca = new CanvasJS.Chart("chartContainer3Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3Cb = new CanvasJS.Chart("chartContainer3Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//post
		var chart3A2 = new CanvasJS.Chart("chartContainer3A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3A2s = new CanvasJS.Chart("chartContainer3A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3A2a = new CanvasJS.Chart("chartContainer3A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3A2b = new CanvasJS.Chart("chartContainer3A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3B2 = new CanvasJS.Chart("chartContainer3B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors5",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3B2s = new CanvasJS.Chart("chartContainer3B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3B2a = new CanvasJS.Chart("chartContainer3B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3B2b = new CanvasJS.Chart("chartContainer3B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3C2 = new CanvasJS.Chart("chartContainer3C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Post Reading Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3C2s = new CanvasJS.Chart("chartContainer3C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3C2a = new CanvasJS.Chart("chartContainer3C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart3C2b = new CanvasJS.Chart("chartContainer3C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints3C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//grande6
		var chart4A = new CanvasJS.Chart("chartContainer4A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4As = new CanvasJS.Chart("chartContainer4As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Aa = new CanvasJS.Chart("chartContainer4Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Ab = new CanvasJS.Chart("chartContainer4Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4B = new CanvasJS.Chart("chartContainer4B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Bs = new CanvasJS.Chart("chartContainer4Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Ba = new CanvasJS.Chart("chartContainer4Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Bb = new CanvasJS.Chart("chartContainer4Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4C = new CanvasJS.Chart("chartContainer4C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Cs = new CanvasJS.Chart("chartContainer4Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Ca = new CanvasJS.Chart("chartContainer4Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4Cb = new CanvasJS.Chart("chartContainer4Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//post
		var chart4A2 = new CanvasJS.Chart("chartContainer4A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4A2s = new CanvasJS.Chart("chartContainer4A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4A2a = new CanvasJS.Chart("chartContainer4A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4A2b = new CanvasJS.Chart("chartContainer4A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4B2 = new CanvasJS.Chart("chartContainer4B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors5",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4B2s = new CanvasJS.Chart("chartContainer4B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4B2a = new CanvasJS.Chart("chartContainer4B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4B2b = new CanvasJS.Chart("chartContainer4B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4C2 = new CanvasJS.Chart("chartContainer4C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Post Reading Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4C2s = new CanvasJS.Chart("chartContainer4C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4C2a = new CanvasJS.Chart("chartContainer4C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart4C2b = new CanvasJS.Chart("chartContainer4C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints4C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//grande7
		var chart5A = new CanvasJS.Chart("chartContainer5A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade7)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5As = new CanvasJS.Chart("chartContainer5As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Aa = new CanvasJS.Chart("chartContainer5Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Ab = new CanvasJS.Chart("chartContainer5Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5B = new CanvasJS.Chart("chartContainer5B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Bs = new CanvasJS.Chart("chartContainer5Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Ba = new CanvasJS.Chart("chartContainer5Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Bb = new CanvasJS.Chart("chartContainer5Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5C = new CanvasJS.Chart("chartContainer5C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade7)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Cs = new CanvasJS.Chart("chartContainer5Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Ca = new CanvasJS.Chart("chartContainer5Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5Cb = new CanvasJS.Chart("chartContainer5Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//post
		var chart5A2 = new CanvasJS.Chart("chartContainer5A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Post Speed Level Rate (Grade7)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5A2s = new CanvasJS.Chart("chartContainer5A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5A2a = new CanvasJS.Chart("chartContainer5A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5A2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5A2b = new CanvasJS.Chart("chartContainer5A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5A2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5B2 = new CanvasJS.Chart("chartContainer5B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors5",
		  title: {
		    text: "Post Comprehension Level Rate (Grade7)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5B2s = new CanvasJS.Chart("chartContainer5B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5B2a = new CanvasJS.Chart("chartContainer5B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5B2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5B2b = new CanvasJS.Chart("chartContainer5B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5B2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5C2 = new CanvasJS.Chart("chartContainer5C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  title: {
		    text: "Post Reading Level Rate (Grade7)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPoints5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5C2s = new CanvasJS.Chart("chartContainer5C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade7)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5C2a = new CanvasJS.Chart("chartContainer5C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5C2a, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chart5C2b = new CanvasJS.Chart("chartContainer5C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade7)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPoints5C2b, JSON_NUMERIC_CHECK); ?>
		  }]
		});

//Render
		chart1A.render();
		chart1As.render();
		chart1Aa.render();
		chart1Ab.render();
		chart1B.render();
		chart1Bs.render();
		chart1Ba.render();
		chart1Bb.render();
		chart1C.render();
		chart1Cs.render();
		chart1Ca.render();
		chart1Cb.render();
		chart1A2.render();
		chart1A2s.render();
		chart1A2a.render();
		chart1A2b.render();
		chart1B2.render();
		chart1B2s.render();
		chart1B2a.render();
		chart1B2b.render();
		chart1C2.render();
		chart1C2s.render();
		chart1C2a.render();
		chart1C2b.render();

		chart2A.render();
		chart2As.render();
		chart2Aa.render();
		chart2Ab.render();
		chart2B.render();
		chart2Bs.render();
		chart2Ba.render();
		chart2Bb.render();
		chart2C.render();
		chart2Cs.render();
		chart2Ca.render();
		chart2Cb.render();
		chart2A2.render();
		chart2A2s.render();
		chart2A2a.render();
		chart2A2b.render();
		chart2B2.render();
		chart2B2s.render();
		chart2B2a.render();
		chart2B2b.render();
		chart2C2.render();
		chart2C2s.render();
		chart2C2a.render();
		chart2C2b.render();

		chart3A.render();
		chart3As.render();
		chart3Aa.render();
		chart3Ab.render();
		chart3B.render();
		chart3Bs.render();
		chart3Ba.render();
		chart3Bb.render();
		chart3C.render();
		chart3Cs.render();
		chart3Ca.render();
		chart3Cb.render();
		chart3A2.render();
		chart3A2s.render();
		chart3A2a.render();
		chart3A2b.render();
		chart3B2.render();
		chart3B2s.render();
		chart3B2a.render();
		chart3B2b.render();
		chart3C2.render();
		chart3C2s.render();
		chart3C2a.render();
		chart3C2b.render();

		chart4A.render();
		chart4As.render();
		chart4Aa.render();
		chart4Ab.render();
		chart4B.render();
		chart4Bs.render();
		chart4Ba.render();
		chart4Bb.render();
		chart4C.render();
		chart4Cs.render();
		chart4Ca.render();
		chart4Cb.render();
		chart4A2.render();
		chart4A2s.render();
		chart4A2a.render();
		chart4A2b.render();
		chart4B2.render();
		chart4B2s.render();
		chart4B2a.render();
		chart4B2b.render();
		chart4C2.render();
		chart4C2s.render();
		chart4C2a.render();
		chart4C2b.render();

		chart5A.render();
		chart5As.render();
		chart5Aa.render();
		chart5Ab.render();
		chart5B.render();
		chart5Bs.render();
		chart5Ba.render();
		chart5Bb.render();
		chart5C.render();
		chart5Cs.render();
		chart5Ca.render();
		chart5Cb.render();
		chart5A2.render();
		chart5A2s.render();
		chart5A2a.render();
		chart5A2b.render();
		chart5B2.render();
		chart5B2s.render();
		chart5B2a.render();
		chart5B2b.render();
		chart5C2.render();
		chart5C2s.render();
		chart5C2a.render();
		chart5C2b.render();
	}
</script>

<div class="contents">
	
	<div class="GroupButCont" style="height: 170%;">
		<div class="butHolder">
			<button id="ElemButton" class="tablinks <?php if ($_SESSION['display'] == "Page1") {echo "active";}?>" onclick="change(event, 'Grade3')" style="height: 19.2%;">
				<i class="fas fa-user-tie fa-1x"></i>
				<span class="tooltiptext">Grade 3</span>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page2") {echo "active";}?>" onclick="change(event, 'Grade4')" style="height: 19.2%;">
				<i class="fas fa-user-friends fa-1x"></i>
				<span class="tooltiptext">Grade 4</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page3") {echo "active";}?>" onclick="change(event, 'Grade5')" style="height: 19.2%;">
				<i class="fas fa-users fa-1x"></i>
				<span class="tooltiptext">Grade 5</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page4") {echo "active";}?>" onclick="change(event, 'Grade6')" style="height: 19.2%;">
				<i class="fas fa-user-edit"></i>
				<span class="tooltiptext">Grade 6</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page5") {echo "active";}?>" onclick="change(event, 'Grade7')" style="height: 19.2%;">
				<i class="fas fa-user-graduate"></i>
				<span class="tooltiptext">Grade 7</span>
			</button>
		</div>
	</div>
	
	<div id="Grade3" class="leftTab" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?> >
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page1") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin != "none") {
						for ($i=$grossmin; $i <= $grossmax; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="ESgrd3">Go</button>
		</form>

		<div class="graphCont2">
			<div class="leftGraph">
				<div id="graphZoom111a" style="position: absolute; width: 45%; height: 45%; top: 3%; left: 2%; background-color: white;">
					<div id="chartContainer1A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom111b" style="position: absolute; width: 50%; height: 60%; top: 21%; right: 1%; background-color: white;">
					<div id="chartContainer1B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom111c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; left: 2%; background-color: white;">
					<div id="chartContainer1C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom112a" style="position: absolute; width: 45%; height: 45%; top: 3%; right: 2%; background-color: white;">
					<div id="chartContainer1A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom112b" style="position: absolute; width: 50%; height: 60%; top: 21%; left: 1%; background-color: white;">
					<div id="chartContainer1B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom112c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; right: 2%; background-color: white;">
					<div id="chartContainer1C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory English Silent (Grade 3) </h3>
		   	</center>
		   	<button type="button" id="exportBut1" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table id="myTableg1">
	                <tr>
	                  <td colspan="2">School</td><td colspan="6">Enrollment</td><td colspan="6">Pupil Tested</td>
	                  <td colspan="18">Speed Level</td><td colspan="18">Comprehension Level</td><td colspan="18">Reading Level</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="6"> </td><td colspan="6"> </td><td colspan="6">Slow</td>
	                  <td colspan="6">Average</td><td colspan="6">Fast</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                </tr>
	                <tr>
	              	<?php
	              	if (mysqli_num_rows($stbresult)>0) {
		              	for ($tbl=0; $tbl < $stblnm['ttldata']; $tbl++){ 
				            $stblrow = mysqli_fetch_array($stbresult);
				            $stblrow2 = mysqli_fetch_array($stblpre);
				            $stblrow3 = mysqli_fetch_array($stblpost);
				            echo "<td colspan=\"2\">".$stblrow['School']."</td>
				                  <td>".$stblrow2['ermale']."</td>
				                  <td>".$stblrow2['erfemale']."</td>
				                  <td>".$stblrow2['ermale']+$stblrow2['erfemale']."</td>
				                  <td>".$stblrow3['ermale']."</td>
				                  <td>".$stblrow3['erfemale']."</td>
				                  <td>".$stblrow3['ermale']+$stblrow3['erfemale']."</td>

				                  <td>".$stblrow2['ptmale']."</td>
				                  <td>".$stblrow2['ptfemale']."</td>
				                  <td>".$stblrow2['ptmale']+$stblrow2['ptfemale']."</td>
				                  <td>".$stblrow3['ptmale']."</td>
				                  <td>".$stblrow3['ptfemale']."</td>
				                  <td>".$stblrow3['ptmale']+$stblrow3['ptfemale']."</td>

				                  <td>".$stblrow2['ssmale']."</td>
				                  <td>".$stblrow2['ssfemale']."</td>
				                  <td>".$stblrow2['ssmale']+$stblrow2['ssfemale']."</td>
				                  <td>".$stblrow3['ssmale']."</td>
				                  <td>".$stblrow3['ssfemale']."</td>
				                  <td>".$stblrow3['ssmale']+$stblrow3['ssfemale']."</td>

				                  <td>".$stblrow2['samale']."</td>
				                  <td>".$stblrow2['safemale']."</td>
				                  <td>".$stblrow2['samale']+$stblrow2['safemale']."</td>
				                  <td>".$stblrow3['samale']."</td>
				                  <td>".$stblrow3['safemale']."</td>
				                  <td>".$stblrow3['samale']+$stblrow3['safemale']."</td>

				                  <td>".$stblrow2['sfmale']."</td>
				                  <td>".$stblrow2['sffemale']."</td>
				                  <td>".$stblrow2['sfmale']+$stblrow2['sffemale']."</td>
				                  <td>".$stblrow3['sfmale']."</td>
				                  <td>".$stblrow3['sffemale']."</td>
				                  <td>".$stblrow3['sfmale']+$stblrow3['sffemale']."</td>

				                  <td>".$stblrow2['cftmale']."</td>
				                  <td>".$stblrow2['cftfemale']."</td>                    
				                  <td>".$stblrow2['cftmale']+$stblrow2['cftfemale']."</td>
				                  <td>".$stblrow3['cftmale']."</td>
				                  <td>".$stblrow3['cftfemale']."</td>
				                  <td>".$stblrow3['cftmale']+$stblrow3['cftfemale']."</td>

				                  <td>".$stblrow2['citmale']."</td>
				                  <td>".$stblrow2['citfemale']."</td>
				                  <td>".$stblrow2['citmale']+$stblrow2['citfemale']."</td>
				                  <td>".$stblrow3['citmale']."</td>
				                  <td>".$stblrow3['citfemale']."</td>
				                  <td>".$stblrow3['citmale']+$stblrow3['citfemale']."</td>

				                  <td>".$stblrow2['cidmale']."</td>
				                  <td>".$stblrow2['cidfemale']."</td>
				                  <td>".$stblrow2['cidmale']+$stblrow2['cidfemale']."</td>
				                  <td>".$stblrow3['cidmale']."</td>
				                  <td>".$stblrow3['cidfemale']."</td>
				                  <td>".$stblrow3['cidmale']+$stblrow3['cidfemale']."</td>

				                  <td>".$stblrow2['rlftmale']."</td>
				                  <td>".$stblrow2['rlftfemale']."</td>
				                  <td>".$stblrow2['rlftmale']+$stblrow2['rlftfemale']."</td>
				                  <td>".$stblrow3['rlftmale']."</td>
				                  <td>".$stblrow3['rlftfemale']."</td>
				                  <td>".$stblrow3['rlftmale']+$stblrow3['rlftfemale']."</td>

				                  <td>".$stblrow2['rlitmale']."</td>
				                  <td>".$stblrow2['rlitfemale']."</td>
				                  <td>".$stblrow2['rlitmale']+$stblrow2['rlitfemale']."</td>
				                  <td>".$stblrow3['rlitmale']."</td>
				                  <td>".$stblrow3['rlitfemale']."</td>
				                  <td>".$stblrow3['rlitmale']+$stblrow3['rlitfemale']."</td>

				                  <td>".$stblrow2['rlidmale']."</td>
				                  <td>".$stblrow2['rlidfemale']."</td>
				                  <td>".$stblrow2['rlidmale']+$stblrow2['rlidfemale']."</td>
				                  <td>".$stblrow3['rlidmale']."</td>
				                  <td>".$stblrow3['rlidfemale']."</td>
				                  <td>".$stblrow3['rlidmale']+$stblrow3['rlidfemale']."</td>";
				          echo "</tr>";
				        }
				    }
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade4" class="leftTab" <?php if ($_SESSION['display'] == "Page2") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page2") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin2 != "none") {
						for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime2."-".($chosenTime2+1)."</option>";
					for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="ESgrd4">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom121a" style="position: absolute; width: 45%; height: 45%; top: 3%; left: 2%; background-color: white;">
					<div id="chartContainer2A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom121b" style="position: absolute; width: 50%; height: 60%; top: 21%; right: 1%; background-color: white;">
					<div id="chartContainer2B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom121c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; left: 2%; background-color: white;">
					<div id="chartContainer2C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom122a" style="position: absolute; width: 45%; height: 45%; top: 3%; right: 2%; background-color: white;">
					<div id="chartContainer2A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom122b" style="position: absolute; width: 50%; height: 60%; top: 21%; left: 1%; background-color: white;">
					<div id="chartContainer2B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom122c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; right: 2%; background-color: white;">
					<div id="chartContainer2C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
		   	<center>
		      <h3>Philippine Independent Reading Inventory English Silent (Grade 4) </h3>
		   	</center>
		   	<button type="button" id="exportBut2" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table id="myTableg2">
	                <tr>
	                  <td colspan="2">School</td><td colspan="6">Enrollment</td><td colspan="6">Pupil Tested</td>
	                  <td colspan="18">Speed Level</td><td colspan="18">Comprehension Level</td><td colspan="18">Reading Level</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="6"> </td><td colspan="6"> </td><td colspan="6">Slow</td>
	                  <td colspan="6">Average</td><td colspan="6">Fast</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                </tr>
	                <tr>
	              	<?php
	              	if (mysqli_num_rows($stbresult2)>0) {
		              	for ($tbl=0; $tbl < $stblnm2['ttldata']; $tbl++){ 
				            $stblrow2 = mysqli_fetch_array($stbresult2);
				            $stblrow22 = mysqli_fetch_array($stblpre2);
				            $stblrow32 = mysqli_fetch_array($stblpost2);
				            echo "<td colspan=\"2\">".$stblrow2['School']."</td>
				                  <td>".$stblrow22['ermale']."</td>
				                  <td>".$stblrow22['erfemale']."</td>
				                  <td>".$stblrow22['ermale']+$stblrow22['erfemale']."</td>
				                  <td>".$stblrow32['ermale']."</td>
				                  <td>".$stblrow32['erfemale']."</td>
				                  <td>".$stblrow32['ermale']+$stblrow32['erfemale']."</td>

				                  <td>".$stblrow22['ptmale']."</td>
				                  <td>".$stblrow22['ptfemale']."</td>
				                  <td>".$stblrow22['ptmale']+$stblrow22['ptfemale']."</td>
				                  <td>".$stblrow32['ptmale']."</td>
				                  <td>".$stblrow32['ptfemale']."</td>
				                  <td>".$stblrow32['ptmale']+$stblrow32['ptfemale']."</td>

				                  <td>".$stblrow22['ssmale']."</td>
				                  <td>".$stblrow22['ssfemale']."</td>
				                  <td>".$stblrow22['ssmale']+$stblrow22['ssfemale']."</td>
				                  <td>".$stblrow32['ssmale']."</td>
				                  <td>".$stblrow32['ssfemale']."</td>
				                  <td>".$stblrow32['ssmale']+$stblrow32['ssfemale']."</td>

				                  <td>".$stblrow22['samale']."</td>
				                  <td>".$stblrow22['safemale']."</td>
				                  <td>".$stblrow22['samale']+$stblrow22['safemale']."</td>
				                  <td>".$stblrow32['samale']."</td>
				                  <td>".$stblrow32['safemale']."</td>
				                  <td>".$stblrow32['samale']+$stblrow32['safemale']."</td>

				                  <td>".$stblrow22['sfmale']."</td>
				                  <td>".$stblrow22['sffemale']."</td>
				                  <td>".$stblrow22['sfmale']+$stblrow22['sffemale']."</td>
				                  <td>".$stblrow32['sfmale']."</td>
				                  <td>".$stblrow32['sffemale']."</td>
				                  <td>".$stblrow32['sfmale']+$stblrow32['sffemale']."</td>

				                  <td>".$stblrow22['cftmale']."</td>
				                  <td>".$stblrow22['cftfemale']."</td>                    
				                  <td>".$stblrow22['cftmale']+$stblrow22['cftfemale']."</td>
				                  <td>".$stblrow32['cftmale']."</td>
				                  <td>".$stblrow32['cftfemale']."</td>
				                  <td>".$stblrow32['cftmale']+$stblrow32['cftfemale']."</td>

				                  <td>".$stblrow22['citmale']."</td>
				                  <td>".$stblrow22['citfemale']."</td>
				                  <td>".$stblrow22['citmale']+$stblrow22['citfemale']."</td>
				                  <td>".$stblrow32['citmale']."</td>
				                  <td>".$stblrow32['citfemale']."</td>
				                  <td>".$stblrow32['citmale']+$stblrow32['citfemale']."</td>

				                  <td>".$stblrow22['cidmale']."</td>
				                  <td>".$stblrow22['cidfemale']."</td>
				                  <td>".$stblrow22['cidmale']+$stblrow22['cidfemale']."</td>
				                  <td>".$stblrow32['cidmale']."</td>
				                  <td>".$stblrow32['cidfemale']."</td>
				                  <td>".$stblrow32['cidmale']+$stblrow32['cidfemale']."</td>

				                  <td>".$stblrow22['rlftmale']."</td>
				                  <td>".$stblrow22['rlftfemale']."</td>
				                  <td>".$stblrow22['rlftmale']+$stblrow22['rlftfemale']."</td>
				                  <td>".$stblrow32['rlftmale']."</td>
				                  <td>".$stblrow32['rlftfemale']."</td>
				                  <td>".$stblrow32['rlftmale']+$stblrow32['rlftfemale']."</td>

				                  <td>".$stblrow22['rlitmale']."</td>
				                  <td>".$stblrow22['rlitfemale']."</td>
				                  <td>".$stblrow22['rlitmale']+$stblrow22['rlitfemale']."</td>
				                  <td>".$stblrow32['rlitmale']."</td>
				                  <td>".$stblrow32['rlitfemale']."</td>
				                  <td>".$stblrow32['rlitmale']+$stblrow32['rlitfemale']."</td>

				                  <td>".$stblrow22['rlidmale']."</td>
				                  <td>".$stblrow22['rlidfemale']."</td>
				                  <td>".$stblrow22['rlidmale']+$stblrow22['rlidfemale']."</td>
				                  <td>".$stblrow32['rlidmale']."</td>
				                  <td>".$stblrow32['rlidfemale']."</td>
				                  <td>".$stblrow32['rlidmale']+$stblrow32['rlidfemale']."</td>";
				          echo "</tr>";
				        }
				    }
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade5" class="leftTab" <?php if ($_SESSION['display'] == "Page3") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page3") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin3 != "none") {
						for ($i=$grossmin3; $i <= $grossmax3; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime3."-".($chosenTime3+1)."</option>";
					for ($i=$grossmin3; $i <= $grossmax3; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="ESgrd5">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom131a" style="position: absolute; width: 45%; height: 45%; top: 3%; left: 2%; background-color: white;">
					<div id="chartContainer3A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom131b" style="position: absolute; width: 50%; height: 60%; top: 21%; right: 1%; background-color: white;">
					<div id="chartContainer3B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom131c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; left: 2%; background-color: white;">
					<div id="chartContainer3C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom132a" style="position: absolute; width: 45%; height: 45%; top: 3%; right: 2%; background-color: white;">
					<div id="chartContainer3A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom132b" style="position: absolute; width: 50%; height: 60%; top: 21%; left: 1%; background-color: white;">
					<div id="chartContainer3B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom132c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; right: 2%; background-color: white;">
					<div id="chartContainer3C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory English Silent (Grade 5) </h3>
		   	</center>
		   	<button type="button" id="exportBut3" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table id="myTableg3">
	                <tr>
	                  <td colspan="2">School</td><td colspan="6">Enrollment</td><td colspan="6">Pupil Tested</td>
	                  <td colspan="18">Speed Level</td><td colspan="18">Comprehension Level</td><td colspan="18">Reading Level</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="6"> </td><td colspan="6"> </td><td colspan="6">Slow</td>
	                  <td colspan="6">Average</td><td colspan="6">Fast</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                </tr>
	                <tr>
	              	<?php
	              	if (mysqli_num_rows($stbresult3)>0) {
		              	for ($tbl=0; $tbl < $stblnm3['ttldata']; $tbl++){ 
				            $stblrow3 = mysqli_fetch_array($stbresult3);
				            $stblrow23 = mysqli_fetch_array($stblpre3);
				            $stblrow33 = mysqli_fetch_array($stblpost3);
				            echo "<td colspan=\"2\">".$stblrow3['School']."</td>
				                  <td>".$stblrow23['ermale']."</td>
				                  <td>".$stblrow23['erfemale']."</td>
				                  <td>".$stblrow23['ermale']+$stblrow23['erfemale']."</td>
				                  <td>".$stblrow33['ermale']."</td>
				                  <td>".$stblrow33['erfemale']."</td>
				                  <td>".$stblrow33['ermale']+$stblrow33['erfemale']."</td>

				                  <td>".$stblrow23['ptmale']."</td>
				                  <td>".$stblrow23['ptfemale']."</td>
				                  <td>".$stblrow23['ptmale']+$stblrow23['ptfemale']."</td>
				                  <td>".$stblrow33['ptmale']."</td>
				                  <td>".$stblrow33['ptfemale']."</td>
				                  <td>".$stblrow33['ptmale']+$stblrow33['ptfemale']."</td>

				                  <td>".$stblrow23['ssmale']."</td>
				                  <td>".$stblrow23['ssfemale']."</td>
				                  <td>".$stblrow23['ssmale']+$stblrow23['ssfemale']."</td>
				                  <td>".$stblrow33['ssmale']."</td>
				                  <td>".$stblrow33['ssfemale']."</td>
				                  <td>".$stblrow33['ssmale']+$stblrow33['ssfemale']."</td>

				                  <td>".$stblrow23['samale']."</td>
				                  <td>".$stblrow23['safemale']."</td>
				                  <td>".$stblrow23['samale']+$stblrow23['safemale']."</td>
				                  <td>".$stblrow33['samale']."</td>
				                  <td>".$stblrow33['safemale']."</td>
				                  <td>".$stblrow33['samale']+$stblrow33['safemale']."</td>

				                  <td>".$stblrow23['sfmale']."</td>
				                  <td>".$stblrow23['sffemale']."</td>
				                  <td>".$stblrow23['sfmale']+$stblrow23['sffemale']."</td>
				                  <td>".$stblrow33['sfmale']."</td>
				                  <td>".$stblrow33['sffemale']."</td>
				                  <td>".$stblrow33['sfmale']+$stblrow33['sffemale']."</td>

				                  <td>".$stblrow23['cftmale']."</td>
				                  <td>".$stblrow23['cftfemale']."</td>                    
				                  <td>".$stblrow23['cftmale']+$stblrow23['cftfemale']."</td>
				                  <td>".$stblrow33['cftmale']."</td>
				                  <td>".$stblrow33['cftfemale']."</td>
				                  <td>".$stblrow33['cftmale']+$stblrow33['cftfemale']."</td>

				                  <td>".$stblrow23['citmale']."</td>
				                  <td>".$stblrow23['citfemale']."</td>
				                  <td>".$stblrow23['citmale']+$stblrow23['citfemale']."</td>
				                  <td>".$stblrow33['citmale']."</td>
				                  <td>".$stblrow33['citfemale']."</td>
				                  <td>".$stblrow33['citmale']+$stblrow33['citfemale']."</td>

				                  <td>".$stblrow23['cidmale']."</td>
				                  <td>".$stblrow23['cidfemale']."</td>
				                  <td>".$stblrow23['cidmale']+$stblrow23['cidfemale']."</td>
				                  <td>".$stblrow33['cidmale']."</td>
				                  <td>".$stblrow33['cidfemale']."</td>
				                  <td>".$stblrow33['cidmale']+$stblrow33['cidfemale']."</td>

				                  <td>".$stblrow23['rlftmale']."</td>
				                  <td>".$stblrow23['rlftfemale']."</td>
				                  <td>".$stblrow23['rlftmale']+$stblrow23['rlftfemale']."</td>
				                  <td>".$stblrow33['rlftmale']."</td>
				                  <td>".$stblrow33['rlftfemale']."</td>
				                  <td>".$stblrow33['rlftmale']+$stblrow33['rlftfemale']."</td>

				                  <td>".$stblrow23['rlitmale']."</td>
				                  <td>".$stblrow23['rlitfemale']."</td>
				                  <td>".$stblrow23['rlitmale']+$stblrow23['rlitfemale']."</td>
				                  <td>".$stblrow33['rlitmale']."</td>
				                  <td>".$stblrow33['rlitfemale']."</td>
				                  <td>".$stblrow33['rlitmale']+$stblrow33['rlitfemale']."</td>

				                  <td>".$stblrow23['rlidmale']."</td>
				                  <td>".$stblrow23['rlidfemale']."</td>
				                  <td>".$stblrow23['rlidmale']+$stblrow23['rlidfemale']."</td>
				                  <td>".$stblrow33['rlidmale']."</td>
				                  <td>".$stblrow33['rlidfemale']."</td>
				                  <td>".$stblrow33['rlidmale']+$stblrow33['rlidfemale']."</td>";
				          echo "</tr>";
				        }
				    }
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade6" class="leftTab" <?php if ($_SESSION['display'] == "Page4") {echo "style=\"display:block;\" ";}?> >
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page4") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin4 != "none") {
						for ($i=$grossmin4; $i <= $grossmax4; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime4."-".($chosenTime4+1)."</option>";
					for ($i=$grossmin4; $i <= $grossmax4; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="ESgrd6">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom141a" style="position: absolute; width: 45%; height: 45%; top: 3%; left: 2%; background-color: white;">
					<div id="chartContainer4A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom141b" style="position: absolute; width: 50%; height: 60%; top: 21%; right: 1%; background-color: white;">
					<div id="chartContainer4B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom141c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; left: 2%; background-color: white;">
					<div id="chartContainer4C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom142a" style="position: absolute; width: 45%; height: 45%; top: 3%; right: 2%; background-color: white;">
					<div id="chartContainer4A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom142b" style="position: absolute; width: 50%; height: 60%; top: 21%; left: 1%; background-color: white;">
					<div id="chartContainer4B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom142c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; right: 2%; background-color: white;">
					<div id="chartContainer4C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory English Silent (Grade 6) </h3>
		   	</center>
		   	<button type="button" id="exportBut4" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable">
			    <table id="myTableg4">
	                <tr>
	                  <td colspan="2">School</td><td colspan="6">Enrollment</td><td colspan="6">Pupil Tested</td>
	                  <td colspan="18">Speed Level</td><td colspan="18">Comprehension Level</td><td colspan="18">Reading Level</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="6"> </td><td colspan="6"> </td><td colspan="6">Slow</td>
	                  <td colspan="6">Average</td><td colspan="6">Fast</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                </tr>
	                <tr>
	              	<?php
	              	if (mysqli_num_rows($stbresult4)>0) {
		              	for ($tbl=0; $tbl < $stblnm4['ttldata']; $tbl++){ 
				            $stblrow4 = mysqli_fetch_array($stbresult4);
				            $stblrow24 = mysqli_fetch_array($stblpre4);
				            $stblrow34 = mysqli_fetch_array($stblpost4);
				            echo "<td colspan=\"2\">".$stblrow4['School']."</td>
				                  <td>".$stblrow24['ermale']."</td>
				                  <td>".$stblrow24['erfemale']."</td>
				                  <td>".$stblrow24['ermale']+$stblrow24['erfemale']."</td>
				                  <td>".$stblrow34['ermale']."</td>
				                  <td>".$stblrow34['erfemale']."</td>
				                  <td>".$stblrow34['ermale']+$stblrow34['erfemale']."</td>

				                  <td>".$stblrow24['ptmale']."</td>
				                  <td>".$stblrow24['ptfemale']."</td>
				                  <td>".$stblrow24['ptmale']+$stblrow24['ptfemale']."</td>
				                  <td>".$stblrow34['ptmale']."</td>
				                  <td>".$stblrow34['ptfemale']."</td>
				                  <td>".$stblrow34['ptmale']+$stblrow34['ptfemale']."</td>

				                  <td>".$stblrow24['ssmale']."</td>
				                  <td>".$stblrow24['ssfemale']."</td>
				                  <td>".$stblrow24['ssmale']+$stblrow24['ssfemale']."</td>
				                  <td>".$stblrow34['ssmale']."</td>
				                  <td>".$stblrow34['ssfemale']."</td>
				                  <td>".$stblrow34['ssmale']+$stblrow34['ssfemale']."</td>

				                  <td>".$stblrow24['samale']."</td>
				                  <td>".$stblrow24['safemale']."</td>
				                  <td>".$stblrow24['samale']+$stblrow24['safemale']."</td>
				                  <td>".$stblrow34['samale']."</td>
				                  <td>".$stblrow34['safemale']."</td>
				                  <td>".$stblrow34['samale']+$stblrow34['safemale']."</td>

				                  <td>".$stblrow24['sfmale']."</td>
				                  <td>".$stblrow24['sffemale']."</td>
				                  <td>".$stblrow24['sfmale']+$stblrow24['sffemale']."</td>
				                  <td>".$stblrow34['sfmale']."</td>
				                  <td>".$stblrow34['sffemale']."</td>
				                  <td>".$stblrow34['sfmale']+$stblrow34['sffemale']."</td>

				                  <td>".$stblrow24['cftmale']."</td>
				                  <td>".$stblrow24['cftfemale']."</td>                    
				                  <td>".$stblrow24['cftmale']+$stblrow24['cftfemale']."</td>
				                  <td>".$stblrow34['cftmale']."</td>
				                  <td>".$stblrow34['cftfemale']."</td>
				                  <td>".$stblrow34['cftmale']+$stblrow34['cftfemale']."</td>

				                  <td>".$stblrow24['citmale']."</td>
				                  <td>".$stblrow24['citfemale']."</td>
				                  <td>".$stblrow24['citmale']+$stblrow24['citfemale']."</td>
				                  <td>".$stblrow34['citmale']."</td>
				                  <td>".$stblrow34['citfemale']."</td>
				                  <td>".$stblrow34['citmale']+$stblrow34['citfemale']."</td>

				                  <td>".$stblrow24['cidmale']."</td>
				                  <td>".$stblrow24['cidfemale']."</td>
				                  <td>".$stblrow24['cidmale']+$stblrow24['cidfemale']."</td>
				                  <td>".$stblrow34['cidmale']."</td>
				                  <td>".$stblrow34['cidfemale']."</td>
				                  <td>".$stblrow34['cidmale']+$stblrow34['cidfemale']."</td>

				                  <td>".$stblrow24['rlftmale']."</td>
				                  <td>".$stblrow24['rlftfemale']."</td>
				                  <td>".$stblrow24['rlftmale']+$stblrow24['rlftfemale']."</td>
				                  <td>".$stblrow34['rlftmale']."</td>
				                  <td>".$stblrow34['rlftfemale']."</td>
				                  <td>".$stblrow34['rlftmale']+$stblrow34['rlftfemale']."</td>

				                  <td>".$stblrow24['rlitmale']."</td>
				                  <td>".$stblrow24['rlitfemale']."</td>
				                  <td>".$stblrow24['rlitmale']+$stblrow24['rlitfemale']."</td>
				                  <td>".$stblrow34['rlitmale']."</td>
				                  <td>".$stblrow34['rlitfemale']."</td>
				                  <td>".$stblrow34['rlitmale']+$stblrow34['rlitfemale']."</td>

				                  <td>".$stblrow24['rlidmale']."</td>
				                  <td>".$stblrow24['rlidfemale']."</td>
				                  <td>".$stblrow24['rlidmale']+$stblrow24['rlidfemale']."</td>
				                  <td>".$stblrow34['rlidmale']."</td>
				                  <td>".$stblrow34['rlidfemale']."</td>
				                  <td>".$stblrow34['rlidmale']+$stblrow34['rlidfemale']."</td>";
				          echo "</tr>";
				        }
				    }
	              	?>
	            </table>
        	</div>
		</div>
	</div>

	<div id="Grade7" class="leftTab" <?php if ($_SESSION['display'] == "Page5") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page5") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin5 != "none") {
						for ($i=$grossmin5; $i <= $grossmax5; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime5."-".($chosenTime5+1)."</option>";
					for ($i=$grossmin5; $i <= $grossmax5; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="ESgrd7">Go</button>
		</form>

		<div class="graphCont">
			<div class="leftGraph">
				<div id="graphZoom151a" style="position: absolute; width: 45%; height: 45%; top: 3%; left: 2%; background-color: white;">
					<div id="chartContainer5A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom151b" style="position: absolute; width: 50%; height: 60%; top: 21%; right: 1%; background-color: white;">
					<div id="chartContainer5B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom151c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; left: 2%; background-color: white;">
					<div id="chartContainer5C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>

			<div class="rightGraph">
				<div id="graphZoom152a" style="position: absolute; width: 45%; height: 45%; top: 3%; right: 2%; background-color: white;">
					<div id="chartContainer5A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom152b" style="position: absolute; width: 50%; height: 60%; top: 21%; left: 1%; background-color: white;">
					<div id="chartContainer5B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom152c" style="position: absolute; width: 45%; height: 45%; bottom: 3%; right: 2%; background-color: white;">
					<div id="chartContainer5C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3>Philippine Independent Reading Inventory English Silent (Grade 7) </h3>
		   	</center>
		   	<button type="button" id="exportBut5" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   	<br>
		   	<div class="nutritable" style="overflow-x: scroll;">
			    <table id="myTableg5">
	                <tr>
	                  <td colspan="2"> School </td><td colspan="6">Enrollment</td><td colspan="6">Pupil Tested</td>
	                  <td colspan="18">Speed Level</td><td colspan="18">Comprehension Level</td><td colspan="18">Reading Level</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="6"> </td><td colspan="6"> </td><td colspan="6">Slow</td>
	                  <td colspan="6">Average</td><td colspan="6">Fast</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td><td colspan="6">Frustration</td>
	                  <td colspan="6">instructional</td><td colspan="6">Independent</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td><td colspan="3">Pre</td>
	                  <td colspan="3">Post</td><td colspan="3">Pre</td><td colspan="3">Post</td>
	                </tr>
	                <tr>
	                  <td colspan="2"> </td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                  <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                </tr>
	                <tr>
	              	<?php
	              	if (mysqli_num_rows($stbresult5)>0) {
		              	for ($tbl=0; $tbl < $stblnm5['ttldata']; $tbl++){ 
				            $stblrow5 = mysqli_fetch_array($stbresult5);
				            $stblrow25 = mysqli_fetch_array($stblpre5);
				            $stblrow35 = mysqli_fetch_array($stblpost5);
				            echo "<td colspan=\"2\">".$stblrow5['School']."</td>
				                  <td>".$stblrow25['ermale']."</td>
				                  <td>".$stblrow25['erfemale']."</td>
				                  <td>".$stblrow25['ermale']+$stblrow25['erfemale']."</td>
				                  <td>".$stblrow35['ermale']."</td>
				                  <td>".$stblrow35['erfemale']."</td>
				                  <td>".$stblrow35['ermale']+$stblrow35['erfemale']."</td>

				                  <td>".$stblrow25['ptmale']."</td>
				                  <td>".$stblrow25['ptfemale']."</td>
				                  <td>".$stblrow25['ptmale']+$stblrow25['ptfemale']."</td>
				                  <td>".$stblrow35['ptmale']."</td>
				                  <td>".$stblrow35['ptfemale']."</td>
				                  <td>".$stblrow35['ptmale']+$stblrow35['ptfemale']."</td>

				                  <td>".$stblrow25['ssmale']."</td>
				                  <td>".$stblrow25['ssfemale']."</td>
				                  <td>".$stblrow25['ssmale']+$stblrow25['ssfemale']."</td>
				                  <td>".$stblrow35['ssmale']."</td>
				                  <td>".$stblrow35['ssfemale']."</td>
				                  <td>".$stblrow35['ssmale']+$stblrow35['ssfemale']."</td>

				                  <td>".$stblrow25['samale']."</td>
				                  <td>".$stblrow25['safemale']."</td>
				                  <td>".$stblrow25['samale']+$stblrow25['safemale']."</td>
				                  <td>".$stblrow35['samale']."</td>
				                  <td>".$stblrow35['safemale']."</td>
				                  <td>".$stblrow35['samale']+$stblrow35['safemale']."</td>

				                  <td>".$stblrow25['sfmale']."</td>
				                  <td>".$stblrow25['sffemale']."</td>
				                  <td>".$stblrow25['sfmale']+$stblrow25['sffemale']."</td>
				                  <td>".$stblrow35['sfmale']."</td>
				                  <td>".$stblrow35['sffemale']."</td>
				                  <td>".$stblrow35['sfmale']+$stblrow35['sffemale']."</td>

				                  <td>".$stblrow25['cftmale']."</td>
				                  <td>".$stblrow25['cftfemale']."</td>                    
				                  <td>".$stblrow25['cftmale']+$stblrow25['cftfemale']."</td>
				                  <td>".$stblrow35['cftmale']."</td>
				                  <td>".$stblrow35['cftfemale']."</td>
				                  <td>".$stblrow35['cftmale']+$stblrow35['cftfemale']."</td>

				                  <td>".$stblrow25['citmale']."</td>
				                  <td>".$stblrow25['citfemale']."</td>
				                  <td>".$stblrow25['citmale']+$stblrow25['citfemale']."</td>
				                  <td>".$stblrow35['citmale']."</td>
				                  <td>".$stblrow35['citfemale']."</td>
				                  <td>".$stblrow35['citmale']+$stblrow35['citfemale']."</td>

				                  <td>".$stblrow25['cidmale']."</td>
				                  <td>".$stblrow25['cidfemale']."</td>
				                  <td>".$stblrow25['cidmale']+$stblrow25['cidfemale']."</td>
				                  <td>".$stblrow35['cidmale']."</td>
				                  <td>".$stblrow35['cidfemale']."</td>
				                  <td>".$stblrow35['cidmale']+$stblrow35['cidfemale']."</td>

				                  <td>".$stblrow25['rlftmale']."</td>
				                  <td>".$stblrow25['rlftfemale']."</td>
				                  <td>".$stblrow25['rlftmale']+$stblrow25['rlftfemale']."</td>
				                  <td>".$stblrow35['rlftmale']."</td>
				                  <td>".$stblrow35['rlftfemale']."</td>
				                  <td>".$stblrow35['rlftmale']+$stblrow35['rlftfemale']."</td>

				                  <td>".$stblrow25['rlitmale']."</td>
				                  <td>".$stblrow25['rlitfemale']."</td>
				                  <td>".$stblrow25['rlitmale']+$stblrow25['rlitfemale']."</td>
				                  <td>".$stblrow35['rlitmale']."</td>
				                  <td>".$stblrow35['rlitfemale']."</td>
				                  <td>".$stblrow35['rlitmale']+$stblrow35['rlitfemale']."</td>

				                  <td>".$stblrow25['rlidmale']."</td>
				                  <td>".$stblrow25['rlidfemale']."</td>
				                  <td>".$stblrow25['rlidmale']+$stblrow25['rlidfemale']."</td>
				                  <td>".$stblrow35['rlidmale']."</td>
				                  <td>".$stblrow35['rlidfemale']."</td>
				                  <td>".$stblrow35['rlidmale']+$stblrow35['rlidfemale']."</td>";
				          echo "</tr>";
				        }
				    }
	              	?>
	            </table>
        	</div>
		</div>
	</div>

</div>


<div id="GrapModal1a" class="graphModal1">
	<span class="graphClose1a">&times;</span>
	<div id="chartContainer1As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal1b" class="graphModal1">
	<span class="graphClose1b">&times;</span>
	<div id="chartContainer1Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal1c" class="graphModal1">
	<span class="graphClose1c">&times;</span>
	<div id="chartContainer1Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal12a" class="graphModal1">
	<span class="graphClose1a2">&times;</span>
	<div id="chartContainer1A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal12b" class="graphModal1">
	<span class="graphClose1b2">&times;</span>
	<div id="chartContainer1B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal12c" class="graphModal1">
	<span class="graphClose1c2">&times;</span>
	<div id="chartContainer1C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer1C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal2a" class="graphModal1">
	<span class="graphClose2a">&times;</span>
	<div id="chartContainer2As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal2b" class="graphModal1">
	<span class="graphClose2b">&times;</span>
	<div id="chartContainer2Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal2c" class="graphModal1">
	<span class="graphClose2c">&times;</span>
	<div id="chartContainer2Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal22a" class="graphModal1">
	<span class="graphClose2a2">&times;</span>
	<div id="chartContainer2A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal22b" class="graphModal1">
	<span class="graphClose2b2">&times;</span>
	<div id="chartContainer2B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal22c" class="graphModal1">
	<span class="graphClose2c2">&times;</span>
	<div id="chartContainer2C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer2C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal3a" class="graphModal1">
	<span class="graphClose3a">&times;</span>
	<div id="chartContainer3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal3b" class="graphModal1">
	<span class="graphClose3b">&times;</span>
	<div id="chartContainer3Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal3c" class="graphModal1">
	<span class="graphClose3c">&times;</span>
	<div id="chartContainer3Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal32a" class="graphModal1">
	<span class="graphClose3a2">&times;</span>
	<div id="chartContainer3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal32b" class="graphModal1">
	<span class="graphClose3b2">&times;</span>
	<div id="chartContainer3B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal32c" class="graphModal1">
	<span class="graphClose3c2">&times;</span>
	<div id="chartContainer3C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer3C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal4a" class="graphModal1">
	<span class="graphClose4a">&times;</span>
	<div id="chartContainer4As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal4b" class="graphModal1">
	<span class="graphClose4b">&times;</span>
	<div id="chartContainer4Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal4c" class="graphModal1">
	<span class="graphClose4c">&times;</span>
	<div id="chartContainer4Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal42a" class="graphModal1">
	<span class="graphClose4a2">&times;</span>
	<div id="chartContainer4A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal42b" class="graphModal1">
	<span class="graphClose4b2">&times;</span>
	<div id="chartContainer4B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal42c" class="graphModal1">
	<span class="graphClose4c2">&times;</span>
	<div id="chartContainer4C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer4C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal5a" class="graphModal1">
	<span class="graphClose5a">&times;</span>
	<div id="chartContainer5As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal5b" class="graphModal1">
	<span class="graphClose5b">&times;</span>
	<div id="chartContainer5Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal5c" class="graphModal1">
	<span class="graphClose5c">&times;</span>
	<div id="chartContainer5Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal52a" class="graphModal1">
	<span class="graphClose5a2">&times;</span>
	<div id="chartContainer5A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal52b" class="graphModal1">
	<span class="graphClose5b2">&times;</span>
	<div id="chartContainer5B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModal52c" class="graphModal1">
	<span class="graphClose5c2">&times;</span>
	<div id="chartContainer5C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainer5C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<script>

	var modal1a = document.getElementById("GrapModal1a");
	var modal1b = document.getElementById("GrapModal1b");
	var modal1c = document.getElementById("GrapModal1c");
	var modal12a = document.getElementById("GrapModal12a");
	var modal12b = document.getElementById("GrapModal12b");
	var modal12c = document.getElementById("GrapModal12c");
	var modal2a = document.getElementById("GrapModal2a");
	var modal2b = document.getElementById("GrapModal2b");
	var modal2c = document.getElementById("GrapModal2c");
	var modal22a = document.getElementById("GrapModal22a");
	var modal22b = document.getElementById("GrapModal22b");
	var modal22c = document.getElementById("GrapModal22c");
	var modal3a = document.getElementById("GrapModal3a");
	var modal3b = document.getElementById("GrapModal3b");
	var modal3c = document.getElementById("GrapModal3c");
	var modal32a = document.getElementById("GrapModal32a");
	var modal32b = document.getElementById("GrapModal32b");
	var modal32c = document.getElementById("GrapModal32c");
	var modal4a = document.getElementById("GrapModal4a");
	var modal4b = document.getElementById("GrapModal4b");
	var modal4c = document.getElementById("GrapModal4c");
	var modal42a = document.getElementById("GrapModal42a");
	var modal42b = document.getElementById("GrapModal42b");
	var modal42c = document.getElementById("GrapModal42c");
	var modal5a = document.getElementById("GrapModal5a");
	var modal5b = document.getElementById("GrapModal5b");
	var modal5c = document.getElementById("GrapModal5c");
	var modal52a = document.getElementById("GrapModal52a");
	var modal52b = document.getElementById("GrapModal52b");
	var modal52c = document.getElementById("GrapModal52c");


	var btn1a = document.getElementById("graphZoom111a");
	var btn1b = document.getElementById("graphZoom111b");
	var btn1c = document.getElementById("graphZoom111c");
	var btn12a = document.getElementById("graphZoom112a");
	var btn12b = document.getElementById("graphZoom112b");
	var btn12c = document.getElementById("graphZoom112c");
	var btn2a = document.getElementById("graphZoom121a");
	var btn2b = document.getElementById("graphZoom121b");
	var btn2c = document.getElementById("graphZoom121c");
	var btn22a = document.getElementById("graphZoom122a");
	var btn22b = document.getElementById("graphZoom122b");
	var btn22c = document.getElementById("graphZoom122c");
	var btn3a = document.getElementById("graphZoom131a");
	var btn3b = document.getElementById("graphZoom131b");
	var btn3c = document.getElementById("graphZoom131c");
	var btn32a = document.getElementById("graphZoom132a");
	var btn32b = document.getElementById("graphZoom132b");
	var btn32c = document.getElementById("graphZoom132c");
	var btn4a = document.getElementById("graphZoom141a");
	var btn4b = document.getElementById("graphZoom141b");
	var btn4c = document.getElementById("graphZoom141c");
	var btn42a = document.getElementById("graphZoom142a");
	var btn42b = document.getElementById("graphZoom142b");
	var btn42c = document.getElementById("graphZoom142c");
	var btn5a = document.getElementById("graphZoom151a");
	var btn5b = document.getElementById("graphZoom151b");
	var btn5c = document.getElementById("graphZoom151c");
	var btn52a = document.getElementById("graphZoom152a");
	var btn52b = document.getElementById("graphZoom152b");
	var btn52c = document.getElementById("graphZoom152c");
	

	var span1a = document.getElementsByClassName("graphClose1a")[0];
	var span1b = document.getElementsByClassName("graphClose1b")[0];
	var span1c = document.getElementsByClassName("graphClose1c")[0];
	var span1a2 = document.getElementsByClassName("graphClose1a2")[0];
	var span1b2 = document.getElementsByClassName("graphClose1b2")[0];
	var span1c2 = document.getElementsByClassName("graphClose1c2")[0];
	var span2a = document.getElementsByClassName("graphClose2a")[0];
	var span2b = document.getElementsByClassName("graphClose2b")[0];
	var span2c = document.getElementsByClassName("graphClose2c")[0];
	var span2a2 = document.getElementsByClassName("graphClose2a2")[0];
	var span2b2 = document.getElementsByClassName("graphClose2b2")[0];
	var span2c2 = document.getElementsByClassName("graphClose2c2")[0];
	var span3a = document.getElementsByClassName("graphClose3a")[0];
	var span3b = document.getElementsByClassName("graphClose3b")[0];
	var span3c = document.getElementsByClassName("graphClose3c")[0];
	var span3a2 = document.getElementsByClassName("graphClose3a2")[0];
	var span3b2 = document.getElementsByClassName("graphClose3b2")[0];
	var span3c2 = document.getElementsByClassName("graphClose3c2")[0];
	var span4a = document.getElementsByClassName("graphClose4a")[0];
	var span4b = document.getElementsByClassName("graphClose4b")[0];
	var span4c = document.getElementsByClassName("graphClose4c")[0];
	var span4a2 = document.getElementsByClassName("graphClose4a2")[0];
	var span4b2 = document.getElementsByClassName("graphClose4b2")[0];
	var span4c2 = document.getElementsByClassName("graphClose4c2")[0];
	var span5a = document.getElementsByClassName("graphClose5a")[0];
	var span5b = document.getElementsByClassName("graphClose5b")[0];
	var span5c = document.getElementsByClassName("graphClose5c")[0];
	var span5a2 = document.getElementsByClassName("graphClose5a2")[0];
	var span5b2 = document.getElementsByClassName("graphClose5b2")[0];
	var span5c2 = document.getElementsByClassName("graphClose5c2")[0];


	btn1a.onclick = function() {
	  modal1a.style.display = "block";
	}
	btn1b.onclick = function() {
	  modal1b.style.display = "block";
	}
	btn1c.onclick = function() {
	  modal1c.style.display = "block";
	}
	btn12a.onclick = function() {
	  modal12a.style.display = "block";
	}
	btn12b.onclick = function() {
	  modal12b.style.display = "block";
	}
	btn12c.onclick = function() {
	  modal12c.style.display = "block";
	}
	btn2a.onclick = function() {
	  modal2a.style.display = "block";
	}
	btn2b.onclick = function() {
	  modal2b.style.display = "block";
	}
	btn2c.onclick = function() {
	  modal2c.style.display = "block";
	}
	btn22a.onclick = function() {
	  modal22a.style.display = "block";
	}
	btn22b.onclick = function() {
	  modal22b.style.display = "block";
	}
	btn22c.onclick = function() {
	  modal22c.style.display = "block";
	}
	btn3a.onclick = function() {
	  modal3a.style.display = "block";
	}
	btn3b.onclick = function() {
	  modal3b.style.display = "block";
	}
	btn3c.onclick = function() {
	  modal3c.style.display = "block";
	}
	btn32a.onclick = function() {
	  modal32a.style.display = "block";
	}
	btn32b.onclick = function() {
	  modal32b.style.display = "block";
	}
	btn32c.onclick = function() {
	  modal32c.style.display = "block";
	}
	btn4a.onclick = function() {
	  modal4a.style.display = "block";
	}
	btn4b.onclick = function() {
	  modal4b.style.display = "block";
	}
	btn4c.onclick = function() {
	  modal4c.style.display = "block";
	}
	btn42a.onclick = function() {
	  modal42a.style.display = "block";
	}
	btn42b.onclick = function() {
	  modal42b.style.display = "block";
	}
	btn42c.onclick = function() {
	  modal42c.style.display = "block";
	}
	btn5a.onclick = function() {
	  modal5a.style.display = "block";
	}
	btn5b.onclick = function() {
	  modal5b.style.display = "block";
	}
	btn5c.onclick = function() {
	  modal5c.style.display = "block";
	}
	btn52a.onclick = function() {
	  modal52a.style.display = "block";
	}
	btn52b.onclick = function() {
	  modal52b.style.display = "block";
	}
	btn52c.onclick = function() {
	  modal52c.style.display = "block";
	}


	span1a.onclick = function() {
	  modal1a.style.display = "none";
	}
	span1b.onclick = function() {
	  modal1b.style.display = "none";
	}
	span1c.onclick = function() {
	  modal1c.style.display = "none";
	}
	span1a2.onclick = function() {
	  modal12a.style.display = "none";
	}
	span1b2.onclick = function() {
	  modal12b.style.display = "none";
	}
	span1c2.onclick = function() {
	  modal12c.style.display = "none";
	}
	span2a.onclick = function() {
	  modal2a.style.display = "none";
	}
	span2b.onclick = function() {
	  modal2b.style.display = "none";
	}
	span2c.onclick = function() {
	  modal2c.style.display = "none";
	}
	span2a2.onclick = function() {
	  modal22a.style.display = "none";
	}
	span2b2.onclick = function() {
	  modal22b.style.display = "none";
	}
	span2c2.onclick = function() {
	  modal22c.style.display = "none";
	}
	span3a.onclick = function() {
	  modal3a.style.display = "none";
	}
	span3b.onclick = function() {
	  modal3b.style.display = "none";
	}
	span3c.onclick = function() {
	  modal3c.style.display = "none";
	}
	span3a2.onclick = function() {
	  modal32a.style.display = "none";
	}
	span3b2.onclick = function() {
	  modal32b.style.display = "none";
	}
	span3c2.onclick = function() {
	  modal32c.style.display = "none";
	}
	span4a.onclick = function() {
	  modal4a.style.display = "none";
	}
	span4b.onclick = function() {
	  modal4b.style.display = "none";
	}
	span4c.onclick = function() {
	  modal4c.style.display = "none";
	}
	span4a2.onclick = function() {
	  modal42a.style.display = "none";
	}
	span4b2.onclick = function() {
	  modal42b.style.display = "none";
	}
	span4c2.onclick = function() {
	  modal42c.style.display = "none";
	}
	span5a.onclick = function() {
	  modal5a.style.display = "none";
	}
	span5b.onclick = function() {
	  modal5b.style.display = "none";
	}
	span5c.onclick = function() {
	  modal5c.style.display = "none";
	}
	span5a2.onclick = function() {
	  modal52a.style.display = "none";
	}
	span5b2.onclick = function() {
	  modal52b.style.display = "none";
	}
	span5c2.onclick = function() {
	  modal52c.style.display = "none";
	}


	window.onclick = function(event) {
	  if (event.target == modal1a) {
	    modal1a.style.display = "none";
	  }
	  if(event.target == modal1b){
	  	modal1b.style.display = "none";
	  }
	  if (event.target == modal2a) {
	    modal2a.style.display = "none";
	  }
	  if(event.target == modal2b){
	  	modal2b.style.display = "none";
	  }
	  if (event.target == modal3a) {
	    modal3a.style.display = "none";
	  }
	  if(event.target == modal3b){
	  	modal3b.style.display = "none";
	  }
	  if (event.target == modal4a) {
	    modal4a.style.display = "none";
	  }
	  if(event.target == modal4b){
	  	modal4b.style.display = "none";
	  }
	  if (event.target == modal5a) {
	    modal5a.style.display = "none";
	  }
	  if(event.target == modal5b){
	  	modal5b.style.display = "none";
	  }
	}

	function html_table_to_excel1(type){
	    var data = document.getElementById('myTableg1');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 3).' + type);
		}

	    const export_button1 = document.getElementById('exportBut1');

	    export_button1.addEventListener('click', () =>  {
	    	html_table_to_excel1('xlsx');
	});

	function html_table_to_excel2(type){
	    var data = document.getElementById('myTableg2');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 4).' + type);
		}

	    const export_button2 = document.getElementById('exportBut2');

	    export_button2.addEventListener('click', () =>  {
	    	html_table_to_excel2('xlsx');
	});

	function html_table_to_excel3(type){
	    var data = document.getElementById('myTableg3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 5).' + type);
		}

	    const export_button3 = document.getElementById('exportBut3');

	    export_button3.addEventListener('click', () =>  {
	    	html_table_to_excel3('xlsx');
	});

	function html_table_to_excel4(type){
	    var data = document.getElementById('myTableg4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 6).' + type);
		}

	    const export_button4 = document.getElementById('exportBut4');

	    export_button4.addEventListener('click', () =>  {
	    	html_table_to_excel3('xlsx');
	});

	function html_table_to_excel5(type){
	    var data = document.getElementById('myTableg5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Grade 7).' + type);
		}

	    const export_button5 = document.getElementById('exportBut5');

	    export_button5.addEventListener('click', () =>  {
	    	html_table_to_excel5('xlsx');
	});

</script>

<script type="text/javascript" src="Script/animation.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>