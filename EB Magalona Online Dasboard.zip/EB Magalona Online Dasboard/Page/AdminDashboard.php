<?php 
include "Header.php";
?>

<div class="contents">
	<h1>Hello</h1>
</div>


</body>
</html>