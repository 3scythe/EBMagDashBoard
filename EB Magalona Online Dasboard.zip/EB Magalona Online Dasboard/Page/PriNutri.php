<?php 
include "Header.php";

session_start();

$grossmin = $_SESSION['timeMin1'];
$grossmax = $_SESSION['timeMax1'];

if($_SESSION['display'] == "none"){
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax;
	$chosenTime3 = $grossmax;
}
elseif($_SESSION['display'] == "Page1"){
	$chosenTime = $_SESSION['theTime'];
	$chosenTime2 = $grossmax;
	$chosenTime3 = $grossmax;
}

$tabName = "nutritionstatus";
$PI = "Nutrional Status";

$Title1 = "Overall BMI Private School Results (".$chosenTime.")";
$Title1a = "Overall Male BMI Private School Results (".$chosenTime.")";
$Title1b = "Overall Female BMI Private School Results (".$chosenTime.")";
$Title1c = "Overall No. of Male Weighted (".$chosenTime.")";
$Title1d = "Overall No. of Female Weighted (".$chosenTime.")";

$Title2 = "Overall HFA Private School Results (".$chosenTime.")";
$Title2 = "Overall HFS Private School Results (".$chosenTime.")";
$Title2a = "Overall Male HFS Private School Results (".$chosenTime.")";
$Title2b = "Overall Female HFS Private School Results (".$chosenTime.")";
$Title2c = "Overall Male Height Taken (".$chosenTime.")";
$Title2d = "Overall Female Height Taken (".$chosenTime.")";

$grouped = "Private";

include "PHP/tables3.php";
include "PHP/graph3.php";

?>

<script type="text/javascript">
	window.onload = function() {
 	
	CanvasJS.addColorSet("dataColors",
	[//colorSet Array
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#0086b3",
        "#40ff00",
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90"                
    ]);

    CanvasJS.addColorSet("dataColors2",
	[//colorSet Array
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#ffff00",
        "#0086b3",
        "#40ff00",
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d"              
    ]);

    CanvasJS.addColorSet("dataColors3",
	[//colorSet Array
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#0086b3",
        "#40ff00"                
    ]);

     CanvasJS.addColorSet("dataColors4",
	[//colorSet Array
		"#cc0099",
        "#3CB371",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#90EE90",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#8a8a5c",
        "#669999",
        "#00b3b3",
        "#804000",
        "#0086b3",
        "#40ff00"                
    ]);
	//Pie Chart1

	var chartA1 = new CanvasJS.Chart("chartContainer1A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$Title1."'"; ?>
	  },
	  height: 455,
	  width: 600,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA12 = new CanvasJS.Chart("chartContainer1A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$Title1."'"; ?>
	  },
	  height: 575,
	  width: 600,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	//Pie Chart2
	
	var chartA12a = new CanvasJS.Chart("chartContainer1A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$Title1a."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA12b = new CanvasJS.Chart("chartContainer1A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$Title1b."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA12c = new CanvasJS.Chart("chartContainer1A2c", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$Title1c."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Ac, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA12d = new CanvasJS.Chart("chartContainer1A2d", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title1d."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Ad, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	//Pie Chart4

	var chartA2 = new CanvasJS.Chart("chartContainer2A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$Title2."'"; ?>
	  },
	  height: 455,
	  width: 600,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA22 = new CanvasJS.Chart("chartContainer2A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$Title2."'"; ?>
	  },
	  height: 575,
	  width: 600,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	//Pie Chart5

	var chartA22a = new CanvasJS.Chart("chartContainer2A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$Title2a."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA22b = new CanvasJS.Chart("chartContainer2A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$Title2b."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA22c = new CanvasJS.Chart("chartContainer2A2c", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$Title2c."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2Ac, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA22d = new CanvasJS.Chart("chartContainer2A2d", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title2d."'"; ?>
	  },
	  height: 281,
	  width: 342,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints2Ad, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	chartA1.render();
	chartA12.render();
	chartA12a.render();
	chartA12b.render();
	chartA12c.render();
	chartA12d.render();
	chartA2.render();
	chartA22.render();
	chartA22a.render();
	chartA22b.render();
	chartA22c.render();
	chartA22d.render();

	}
</script>

<div class="contents">
	<div id="ElemSchool" class="leftTab2" style="display:block;">
		<form class="timeStamp" action="PHP/selDate.php" method="POST" style="width: 98.65%;">
			<select class="selDate2" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page2" || $_SESSION['display'] == "Page3") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn2" type="submit" name="PNutri">Go</button>
			<button id="ElemButton" class="timeBtn2" type="submit" name="NextPage4" style="left: 0.5%;">
				<i class="fas fa-arrow-left"></i>
				<span class="tooltiptext2">Elementary School</span>
			</button>
		</form>

		<div class="graphCont" style="width: 99.5%; background-color: red;">
			<div class="pLeft">
				<div id="graphZoom11a" class="contPie1">
					<div id="chartContainer1A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
			<div class="pRight">
				<div id="graphZoom11b" class="contPie2">
					<div id="chartContainer2A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont" style="width: 99.3%;">
			<center>
				<h1>Disctric Nutritional Status (Elementary)</h1>
			</center>
			<button type="button" id="exportBut1" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
			<?php
			  echo "<div class=\"nutritable\">
			          <table id=\"myTableg1\">
			            <tr>
			              <td rowspan=\"3\" colspan=\"2\">School</td>
			              <td rowspan=\"2\" colspan=\"2\">Enrollment</td>
			              <td rowspan=\"2\" colspan=\"2\">Pupil Weighed</td>
			              <td colspan=\"10\">Body Mass Index (BMI)</td>
			              <td colspan=\"8\">HIEGHT-FOR-AGE (HFA)</td>
			              <td rowspan=\"2\" colspan=\"2\">Pupil Height Taken</td>
			            </tr>
			            <tr>
			              <td colspan=\"2\">Severely Wasted</td>
			              <td colspan=\"2\">Wasted</td>
			              <td colspan=\"2\">Normal</td>
			              <td colspan=\"2\">Overweight</td>
			              <td colspan=\"2\">Obese</td>
			              <td colspan=\"2\">Severely Stunted</td>
			              <td colspan=\"2\">Stunted</td>
			              <td colspan=\"2\">Normal</td>
			              <td colspan=\"2\">Tall</td>
			            </tr>
			            <tr>
			              <td>Gender</td>
			              <td>Enrollee</td>
			              <td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td>
			              <td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td>
			            </tr>";

			      $ntschooln1 = "SELECT COUNT(School) AS nschl FROM `{$tabName}` WHERE Groups = '$grouped' AND Year = '$chosenTime' ";
			      $ntschoolrest = mysqli_query($conn3, $ntschooln1);
			      $ntschlsrow = mysqli_fetch_array($ntschoolrest);
			      $ntschool = "SELECT * FROM `{$tabName}` WHERE Groups = '$grouped' And Year = '$chosenTime' ORDER BY School";
			      $ntschoolres = mysqli_query($conn3, $ntschool);
			      
			    if (mysqli_num_rows($ntschoolrest) > 0) {
			      for ($i=0; $i < $ntschlsrow['nschl']; $i++) { 
			      $ntschlsrows = mysqli_fetch_array($ntschoolres);
			      
			      echo "<tr>
			              <td colspan=\"2\" rowspan=\"3\">".$ntschlsrows['School']."</td>
			              <td>Male</td><td>".$ntschlsrows['enmale']."</td>
			              <td>".$ntschlsrows['pwmale']."</td>
			              <td>".round(($ntschlsrows['pwmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['bmiswmale']."</td>
			              <td>".round(($ntschlsrows['bmiswmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['bmiwmale']."</td>
			              <td>".round(($ntschlsrows['bmiwmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['bminmale']."</td>
			              <td>".round(($ntschlsrows['bminmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['bmiowmale']."</td>
			              <td>".round(($ntschlsrows['bmiowmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['bmiomale']."</td>
			              <td>".round(($ntschlsrows['bmiomale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['hfassmale']."</td>
			              <td>".round(($ntschlsrows['hfassmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['hfasmale']."</td>
			              <td>".round(($ntschlsrows['hfasmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['hfanmale']."</td>
			              <td>".round(($ntschlsrows['hfanmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['hfatmale']."</td>
			              <td>".round(($ntschlsrows['hfatmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              <td>".$ntschlsrows['pthmale']."</td>
			              <td>".round(($ntschlsrows['pthmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			              </tr>
			              <tr>
			                <td>Female</td><td>".$ntschlsrows['enfemale']."</td>
			                <td>".$ntschlsrows['pwfemale']."</td>
			                <td>".round(($ntschlsrows['pwfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiswfemale']."</td>
			                <td>".round(($ntschlsrows['bmiswfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiwfemale']."</td>
			                <td>".round(($ntschlsrows['bmiwfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bminfemale']."</td>
			                <td>".round(($ntschlsrows['bminfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiowfemale']."</td>
			                <td>".round(($ntschlsrows['bmiowfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiofemale']."</td>
			                <td>".round(($ntschlsrows['bmiofemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfassfemale']."</td>
			                <td>".round(($ntschlsrows['hfassfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfasfemale']."</td>
			                <td>".round(($ntschlsrows['hfasfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfanfemale']."</td>
			                <td>".round(($ntschlsrows['hfanfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfatfemale']."</td>
			                <td>".round(($ntschlsrows['hfatfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['pthfemale']."</td>
			                <td>".round(($ntschlsrows['pthfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			              </tr>
			              <tr>
			                <td>Total</td><td>".$ntschlsrows['enmale']+$ntschlsrows['enfemale']."</td>
			                <td>".$ntschlsrows['pwmale']+$ntschlsrows['pwfemale']."</td>
			                <td>".round(($ntschlsrows['pwmale']+$ntschlsrows['pwfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiswmale']+$ntschlsrows['bmiswfemale']."</td>
			                <td>".round(($ntschlsrows['bmiswmale']+$ntschlsrows['bmiswfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiwmale']+$ntschlsrows['bmiwfemale']."</td>
			                <td>".round(($ntschlsrows['bmiwmale']+$ntschlsrows['bmiwfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bminmale']+$ntschlsrows['bminfemale']."</td>
			                <td>".round(($ntschlsrows['bminmale']+$ntschlsrows['bminfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiowmale']+$ntschlsrows['bmiowfemale']."</td>
			                <td>".round(($ntschlsrows['bmiowmale']+$ntschlsrows['bmiowfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['bmiomale']+$ntschlsrows['bmiofemale']."</td>
			                <td>".round(($ntschlsrows['bmiomale']+$ntschlsrows['bmiofemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfassmale']+$ntschlsrows['hfassfemale']."</td>
			                <td>".round(($ntschlsrows['hfassmale']+$ntschlsrows['hfassfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfasmale']+$ntschlsrows['hfasfemale']."</td>
			                <td>".round(($ntschlsrows['hfasmale']+$ntschlsrows['hfasfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfanmale']+$ntschlsrows['hfanfemale']."</td>
			                <td>".round(($ntschlsrows['hfanmale']+$ntschlsrows['hfanfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['hfatmale']+$ntschlsrows['hfatfemale']."</td>
			                <td>".round(($ntschlsrows['hfatmale']+$ntschlsrows['hfatfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			                <td>".$ntschlsrows['pthmale']+$ntschlsrows['pthfemale']."</td>
			                <td>".round(($ntschlsrows['pthmale']+$ntschlsrows['pthfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			              </tr>";
			      }
			  	}
			    echo "</table>
			        </div>";

			?>
		</div>
	</div>
</div>

<div id="GrapModal1a" class="graphModal1">
	<span class="graphClose1a">&times;</span>
	<div id="chartContainer1A2" style="position: relative; height: 92%; width: 43.9%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
	<div style="position: absolute; left: 47.5%; top: 4.5%; width: 25%; height: 45%; background-color: red;">
		<div id="chartContainer1A2c" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 1.5%; top: 4.5%; width: 25%; height: 45%; background-color: red;">
		<div id="chartContainer1A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 47.5%; bottom: 4.5%; width: 25%; height: 44%; background-color: red;">
		<div id="chartContainer1A2d" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 1.5%; bottom: 4.5%; width: 25%; height: 44%; background-color: red;">
		<div id="chartContainer1A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal1b" class="graphModal1">
	<span class="graphClose1b">&times;</span>
	<div id="chartContainer2A2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
	<div style="position: absolute; left: 47.5%; top: 4.5%; width: 25%; height: 45%; background-color: red;">
		<div id="chartContainer2A2c" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 1.5%; top: 4.5%; width: 25%; height: 45%; background-color: red;">
		<div id="chartContainer2A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 47.5%; bottom: 4.5%; width: 25%; height: 44%; background-color: red;">
		<div id="chartContainer2A2d" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 1.5%; bottom: 4.5%; width: 25%; height: 44%; background-color: red;">
		<div id="chartContainer2A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<script>

	var modal1a = document.getElementById("GrapModal1a");
	var btn1a = document.getElementById("graphZoom11a");
	var span1a = document.getElementsByClassName("graphClose1a")[0];

	var modal1b = document.getElementById("GrapModal1b");
	var btn1b = document.getElementById("graphZoom11b");
	var span1b = document.getElementsByClassName("graphClose1b")[0];

	btn1a.onclick = function() {
	  modal1a.style.display = "block";
	}
	span1a.onclick = function() {
	  modal1a.style.display = "none";
	}


	btn1b.onclick = function() {
	  modal1b.style.display = "block";
	}
	span1b.onclick = function() {
	  modal1b.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modal1a) {
	    modal1a.style.display = "none";
	  }

	  if(event.target == modal1b){
	  	modal1b.style.display = "none";
	  }
	}


	function html_table_to_excel(type){
	    var data = document.getElementById('myTableg1');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $PI; ?>(Elementary).' + type);
		}

	    const export_button = document.getElementById('exportBut1');

	    export_button.addEventListener('click', () =>  {
	    	html_table_to_excel('xlsx');
	});
</script>

<script type="text/javascript" src="Script/animation.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>