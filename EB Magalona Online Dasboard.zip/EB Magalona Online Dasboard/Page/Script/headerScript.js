function change(evt, tabname) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("leftTab");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabname).style.display = "inherit";
  evt.currentTarget.className += " active";
}

function changeE(evt, tabname) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("leftTabE");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabname).style.display = "inherit";
  evt.currentTarget.className += " active";
}

function change2(evt, tabname) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("rightSide");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks2");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabname).style.display = "inherit";
  evt.currentTarget.className += " active";
}

function change3(evt, tabname) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("contab");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks3");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabname).style.display = "inherit";
  evt.currentTarget.className += " active";
}

function changeE4(evt, tabname) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("leftTabE2");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks4");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabname).style.display = "inherit";
  evt.currentTarget.className += " active";
}