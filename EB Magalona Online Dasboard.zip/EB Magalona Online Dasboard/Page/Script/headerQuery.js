$(document).ready(function(){

	//User dropdown
 	$("#iconHide").click(function(){
    	$(".usedrop").css("display", "inherit");
    	$(".imgCon").css("background-color", "#006600");
    	$(".imgCon").css("border-radius", "0%");
    	$(".imgCon").css("border-top-left-radius", "50%");
    	$(".imgCon").css("border-top-right-radius", "50%");
    	$("#iconHide").css("display", "none");
    	$("#iconOut").css("display", "inherit");

    	$(".ESPB1").css("display", "block");
    	$(".ESPB2").css("display", "none");
    	$(".allSchoolCont").css("display", "none");

    	$(".OPI1").css("display", "block");
    	$(".OPI2").css("display", "none");
    	$(".PerformIndi").css("display", "none");

    	$(".DPI1").css("display", "block");
    	$(".DPI2").css("display", "none");
    	$(".PhilIri").css("display", "none");

    	$(".DNS1").css("display", "block");
    	$(".DNS2").css("display", "none");
    	$(".NutriStats").css("display", "none");

    	$(".D4P1").css("display", "block");
    	$(".D4P2").css("display", "none");
    	$(".D4P").css("display", "none");
 	});
 	$("#iconOut").click(function(){
    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");
    	$("#iconHide").css("display", "inherit");
    	$("#iconOut").css("display", "none");
 	});
	
	//school dropdown
 	$(".ESPB1").click(function(){
    	$(".ESPB2").css("display", "block");
    	$(".ESPB2").css("background-color", "black");
    	$(".ESPB1").css("display", "none");
    	$(".allSchoolCont").css("display", "block");

    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");

    	$(".OPI1").css("display", "block");
    	$(".OPI2").css("display", "none");
    	$(".PerformIndi").css("display", "none");

    	$(".DPI1").css("display", "block");
    	$(".DPI2").css("display", "none");
    	$(".PhilIri").css("display", "none");

    	$(".DNS1").css("display", "block");
    	$(".DNS2").css("display", "none");
    	$(".NutriStats").css("display", "none");

    	$(".D4P1").css("display", "block");
    	$(".D4P2").css("display", "none");
    	$(".D4P").css("display", "none");
 	});
 	$(".ESPB2").click(function(){
    	$(".ESPB2").css("display", "none");
    	$(".ESPB1").css("display", "block");
    	$(".allSchoolCont").css("display", "none");
 	});

 	//distric Preformance Indicator
 	$(".OPI1").click(function(){
    	$(".OPI2").css("display", "block");
    	$(".OPI2").css("background-color", "black");
    	$(".OPI1").css("display", "none");
    	$(".PerformIndi").css("display", "block");

    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");

    	$(".ESPB1").css("display", "block");
    	$(".ESPB2").css("display", "none");
    	$(".allSchoolCont").css("display", "none");

    	$(".DPI1").css("display", "block");
    	$(".DPI2").css("display", "none");
    	$(".PhilIri").css("display", "none");

    	$(".DNS1").css("display", "block");
    	$(".DNS2").css("display", "none");
    	$(".NutriStats").css("display", "none");

    	$(".D4P1").css("display", "block");
    	$(".D4P2").css("display", "none");
    	$(".D4P").css("display", "none");
 	});
 	$(".OPI2").click(function(){
    	$(".OPI2").css("display", "none");
    	$(".OPI1").css("display", "block");
    	$(".PerformIndi").css("display", "none");
 	});

 	//Phil Iri
 	$(".DPI1").click(function(){
    	$(".DPI2").css("display", "block");
    	$(".DPI2").css("background-color", "black");
    	$(".DPI1").css("display", "none");
    	$(".PhilIri").css("display", "block");

    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");

    	$(".ESPB1").css("display", "block");
    	$(".ESPB2").css("display", "none");
    	$(".allSchoolCont").css("display", "none");

    	$(".OPI1").css("display", "block");
    	$(".OPI2").css("display", "none");
    	$(".PerformIndi").css("display", "none");

    	$(".DNS1").css("display", "block");
    	$(".DNS2").css("display", "none");
    	$(".NutriStats").css("display", "none");

    	$(".D4P1").css("display", "block");
    	$(".D4P2").css("display", "none");
    	$(".D4P").css("display", "none");
 	});
 	$(".DPI2").click(function(){
    	$(".DPI2").css("display", "none");
    	$(".DPI1").css("display", "block");
    	$(".PhilIri").css("display", "none");
 	});

 	//Nutritional Status
 	$(".DNS1").click(function(){
    	$(".DNS2").css("display", "block");
    	$(".DNS2").css("background-color", "black");
    	$(".DNS1").css("display", "none");
    	$(".NutriStats").css("display", "block");

    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");

    	$(".ESPB1").css("display", "block");
    	$(".ESPB2").css("display", "none");
    	$(".allSchoolCont").css("display", "none");

    	$(".OPI1").css("display", "block");
    	$(".OPI2").css("display", "none");
    	$(".PerformIndi").css("display", "none");

    	$(".DPI1").css("display", "block");
    	$(".DPI2").css("display", "none");
    	$(".PhilIri").css("display", "none");

    	$(".D4P1").css("display", "block");
    	$(".D4P2").css("display", "none");
    	$(".D4P").css("display", "none");
 	});
 	$(".DNS2").click(function(){
    	$(".DNS2").css("display", "none");
    	$(".DNS1").css("display", "block");
    	$(".NutriStats").css("display", "none");
 	});

 	$(".D4P1").click(function(){
    	$(".D4P2").css("display", "block");
    	$(".D4P2").css("background-color", "black");
    	$(".D4P1").css("display", "none");
    	$(".D4P").css("display", "block");

    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");

    	$(".ESPB1").css("display", "block");
    	$(".ESPB2").css("display", "none");
    	$(".allSchoolCont").css("display", "none");

    	$(".OPI1").css("display", "block");
    	$(".OPI2").css("display", "none");
    	$(".PerformIndi").css("display", "none");

    	$(".DPI1").css("display", "block");
    	$(".DPI2").css("display", "none");
    	$(".PhilIri").css("display", "none");

    	$(".DNS1").css("display", "block");
    	$(".DNS2").css("display", "none");
    	$(".NutriStats").css("display", "none");
 	});
 	$(".D4P2").click(function(){
    	$(".D4P2").css("display", "none");
    	$(".D4P1").css("display", "block");
    	$(".D4P").css("display", "none");
 	});

 	$(".outbut").click(function(){
    	$(".usedrop").css("display", "none");
    	$(".imgCon").css("background-color", "#00b33c");
    	$("#iconHide").css("display", "inherit");
    	$("#iconOut").css("display", "none");
    	$("#logoutModal").css("display", "block");
 	});
 	$(".No").click(function(){
    	$("#logoutModal").css("display", "none");
 	});

    $("#flip1").click(function(){
        $("#flip1").css("display", "none");
        $("#flop1").css("display", "inline-block");
        $("#flop2").css("display", "none");
        $("#flip2").css("display", "inline-block");
        $("#flop3").css("display", "none");
        $("#flip3").css("display", "inline-block");
        $("#flop4").css("display", "none");
        $("#flip4").css("display", "inline-block");
        $(".PIButPanel1").slideDown("slow");
        $(".PIButPanel2").slideUp("slow");
        $(".PIButPanel3").slideUp("slow");
        $(".PIButPanel4").slideUp("slow");
    });
    $("#flop1").click(function(){
        $("#flop1").css("display", "none");
        $("#flip1").css("display", "inline-block");
        $(".PIButPanel1").slideUp("slow");
    });

    $("#flip2").click(function(){
        $("#flip2").css("display", "none");
        $("#flop2").css("display", "inline-block");
        $("#flop1").css("display", "none");
        $("#flip1").css("display", "inline-block");
        $("#flop3").css("display", "none");
        $("#flip3").css("display", "inline-block");
        $("#flop4").css("display", "none");
        $("#flip4").css("display", "inline-block");
        $(".PIButPanel2").slideDown("slow");
        $(".PIButPanel1").slideUp("slow");
        $(".PIButPanel3").slideUp("slow");
        $(".PIButPanel4").slideUp("slow");
    });
    $("#flop2").click(function(){
        $("#flop2").css("display", "none");
        $("#flip2").css("display", "inline-block");
        $(".PIButPanel2").slideUp("slow");
    });

    $("#flip3").click(function(){
        $("#flip3").css("display", "none");
        $("#flop3").css("display", "inline-block");
        $("#flop1").css("display", "none");
        $("#flip1").css("display", "inline-block");
        $("#flop2").css("display", "none");
        $("#flip2").css("display", "inline-block");
        $("#flop4").css("display", "none");
        $("#flip4").css("display", "inline-block");
        $(".PIButPanel3").slideDown("slow");
        $(".PIButPanel1").slideUp("slow");
        $(".PIButPanel2").slideUp("slow");
        $(".PIButPanel4").slideUp("slow");
    });
    $("#flop3").click(function(){
        $("#flop3").css("display", "none");
        $("#flip3").css("display", "inline-block");
        $(".PIButPanel3").slideUp("slow");
    });

    $("#flip4").click(function(){
        $("#flip4").css("display", "none");
        $("#flop4").css("display", "inline-block");
        $("#flop1").css("display", "none");
        $("#flip1").css("display", "inline-block");
        $("#flop2").css("display", "none");
        $("#flip2").css("display", "inline-block");
        $("#flop3").css("display", "none");
        $("#flip3").css("display", "inline-block");
        $(".PIButPanel4").slideDown("slow");
        $(".PIButPanel1").slideUp("slow");
        $(".PIButPanel2").slideUp("slow");
        $(".PIButPanel3").slideUp("slow");
    });
    $("#flop4").click(function(){
        $("#flop4").css("display", "none");
        $("#flip4").css("display", "inline-block");
        $(".PIButPanel4").slideUp("slow");
    });
});