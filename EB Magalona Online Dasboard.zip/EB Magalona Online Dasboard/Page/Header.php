<?php
session_start();
include "PHP/connect.php";

if (!isset($_SESSION["usename"])) {
	header('Location: ../index.php?error=InvalidEntry');
}

$getschool1 = "SELECT * FROM elemAdmin ORDER BY school ASC";
$getQuery1 = mysqli_query($conn2, $getschool1);
$getRow1 = mysqli_num_rows($getQuery1);

$getschool2 = "SELECT * FROM highAdmin ORDER BY school ASC";
$getQuery2 = mysqli_query($conn2, $getschool2);
$getRow2 = mysqli_num_rows($getQuery2);

$getschool3 = "SELECT * FROM privateAdmin ORDER BY school ASC";
$getQuery3 = mysqli_query($conn2, $getschool3);
$getRow3 = mysqli_num_rows($getQuery3);

?>

<!DOCTYPE html>
<html>
<title>EB Magalona Dashboard</title>
<head>
	<link rel="stylesheet" href="CSS/headercss.css" type="text/css">
	<link rel="stylesheet" href="CSS/diffPages.css" type="text/css">
	<link rel="stylesheet" href="CSS/IndiPage.css" type="text/css">
	<script type="text/javascript" src="Script/jquery-3.6.0.js"></script>
  	<script type="text/javascript" src="Script/headerScript.js"></script>
  	<script type="text/javascript" src="Script/headerQuery.js"></script>
  	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
  	<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
  	<script src="https://kit.fontawesome.com/9b2509c5e6.js" crossorigin="anonymous"></script>
</head>
<body> 

<div class="NavBar">
	<div class="NavBarCon1">
		<img src="Images/icon.jpg" class="icon">

		<div class="user">
			<div class="imgCon">
				<img src="Images/AdminImages/user.png" class="useicon" id="iconHide">
				<img src="Images/AdminImages/user.png" class="useicon" id="iconOut" style="display: none;">
				<div class="usedrop">
					<div class="profileHold">
						<img class="useicon2" src="Images/AdminImages/user.png">
						<h3>Admin <?php echo $_SESSION['fname']." ".$_SESSION['midname'].". ".$_SESSION['lname'] ?></h3>
					</div>
					<form class="buttonHold" action="PHP/transfer.php" method="POST">
						<button type="Submit" name="useSet">User Settings</button>
						<button type="Submit" name="secSet">Security Settings</button>
						<button class="outbut" type="button">Logout</button>
					</form>
				</div>
			</div>
			<div class="usen">
				<h2>Welcome <?php if($_SESSION['mygender'] = "Male"){echo "Mr. ";}else{echo "Ms. ";} echo $_SESSION['fname']; ?></h2>
				<h3><?php echo $_SESSION['myjobDiscrip']; ?></h3>
			</div>
		</div>
	</div>

	<div class="NavBarCon2">
		<ul class="nabList">
		  <li>
		  	<button class="OPI1" style="border-left: 1px solid #bbb;"> Performance Indicators <i class="fas fa-caret-down"></i></button>
		  	<button class="OPI2" style="border-left: 1px solid #bbb; display: none; color: green;">Performance Indicators <i class="fas fa-caret-up"></i></button>
		  </li>
		  
		  <li>
		  	<button class="DPI1">District Phil-Iri <i class="fas fa-caret-down"></i></button>
		  	<button class="DPI2" style="display: none; color: green;">District Phil-Iri <i class="fas fa-caret-up"></i></button>
		  </li>

		  <li>
		  	<button class="DNS1">Nutritional Status <i class="fas fa-caret-down"></i></button>
		  	<button class="DNS2" style="display: none; color: green;">Nutritional Status <i class="fas fa-caret-up"></i></button>
		  </li>

		  <li>
		  	<button class="D4P1">District 4P's Benificiaries <i class="fas fa-caret-down"></i></button>
		  	<button class="D4P2" style="display: none; color: green;">District 4P's Benificiaries <i class="fas fa-caret-up"></i></button>
		  </li>

		  <li>
		  	<button class="ESPB1">Individual School Indicators <i class="fas fa-caret-down"></i></button>
		  	<button class="ESPB2" style="display: none; color: green;">Individual School Indicators <i class="fas fa-caret-up"></i></button>
		  </li>
		</ul>
		
		<form class="PerformIndi" action="PHP/transfer.php" method="POST">
			<button type="Submit" name="Gross" >Gross Enrollment</button>
			<button type="Submit" name="Net" >Net Enrollment Rate</button>
			<button type="Submit" name="Drop" >Drop-out Rate</button>
			<button type="Submit" name="Surv" >Survival Rate</button>
			<button type="Submit" name="Fail" >Failure Rate</button>
			<button type="Submit" name="Comp" >Completion Rate</button>
			<button type="Submit" name="Ret" >Retention Rate</button>
			<button type="Submit" name="Grad" >Graduation Rate</button>
			<button type="Submit" name="Prom" >Promotion Rate</button>
			<button type="Submit" name="Rep" >Repeatition Rate</button>
		</form>

		<form class="PhilIri" action="PHP/transfer.php" method="POST">
			<button type="Submit" name="EngOral" >English Oral</button>
			<button type="Submit" name="EngSilent" >English Silent</button>
			<button type="Submit" name="FilOral" >Filipino Oral</button>
			<button type="Submit" name="FilSilent" >Filipino Silent</button>
		</form>

		<form class="NutriStats" action="PHP/transfer.php" method="POST">
			<button type="Submit" name="NutriElem" >Elementary School</button>
			<button type="Submit" name="HutriPri" >Private School</button>
		</form>

		<form class="D4P" action="PHP/transfer.php" method="POST">
			<button type="Submit" name="Elem4P" >Elementary School</button>
			<button type="Submit" name="High4P" >High School</button>
		</form>

		<div class="allSchoolCont">
			<form class="schoolList" action="PHP/transfer.php" method="POST">
				<div class="elemCont" style="overflow-y: scroll;">
					<h3 style="text-decoration: underline; margin-bottom: 5px;">Elementary Schools:</h3>
					<?php
						for ($i=0; $i < $getRow1; $i++) { 
							$getData = mysqli_fetch_array($getQuery1);
							echo "<button type=\"Submit\" name=\"elemBut\" value=\"".$getData['school']."\"> ".$getData['school']." </button>";
						}
					?>
				</div>

				<div class="highCont" style="overflow-y: scroll;">
					<h3 style="text-decoration: underline; padding-left: 4%;">High Schools:</h3>
					<?php
						for ($i=0; $i < $getRow2; $i++) { 
							$getData2 = mysqli_fetch_array($getQuery2);
							echo "<button type=\"Submit\" name=\"highBut\" value=\"".$getData2['school']."\"> ".$getData2['school']." </button>";
						}
					?>
				</div>

				<div class="priCont" style="overflow-y: scroll;">
					<h3 style="text-decoration: underline; padding-left: 4%;">Private Schools:</h3>
					<?php
						for ($i=0; $i < $getRow3; $i++) { 
							$getData3 = mysqli_fetch_array($getQuery3);
							echo "<button type=\"Submit\" name=\"priBut\" value=\"".$getData3['school']."\"> ".$getData3['school']." </button>";
						}
					?>
				</div>
			</form>
		</div>
	</div>

	<div id="logoutModal">
		<span class="close">&times;</span>
		<div class="logouttab">
			<h1>Logout?</h1>
			<form action="PHP/transfer.php" method="POST">
				<button type="Submit" name="logout" style="margin-right: 5%;">Yes</button>
				<button class="No" type="button" style="margin-left: 5%;">No</button>
			</form>
		</div>
	</div>
</div>

<script>
// Get the modal
var modal = document.getElementById("logoutModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>