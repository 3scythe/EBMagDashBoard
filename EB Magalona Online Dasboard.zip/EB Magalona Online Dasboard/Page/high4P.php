<?php 
include "Header.php";

session_start();
$grossmin = $_SESSION['timeMin1'];
$grossmax = $_SESSION['timeMax1'];

if($_SESSION['display'] == "none"){
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax;
	$chosenTime3 = $grossmax;
}
elseif($_SESSION['display'] == "Page1"){
	$chosenTime = $_SESSION['theTime'];
	$chosenTime2 = $grossmax;
	$chosenTime3 = $grossmax;
}

$tabName = "distric4ps";
$PI = "4Ps Beneficiaries";
$PI2 = "4Ps";
$PI3 = "4Ps Beneficiary";

$Title1 = "High School ".$PI." Percentage";
$Title2 = "High School Students Male/Female Ratio (".$PI2.")";
$Title3 = "Distric ".$PI3." Studnets by Year (High School)";

$Titlex = "Number Of ".$PI3." Students";

include "PHP/tables.php";
include "PHP/tables2.php";
include "PHP/graph.php";

?>

<script type="text/javascript">
	window.onload = function() {
 	
	CanvasJS.addColorSet("dataColors",
	[//colorSet Array
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#0086b3",
        "#40ff00",
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90"                
    ]);
//Pie Chart1

 	//-------Elementary-----\\
	var chartA1 = new CanvasJS.Chart("chartContainer1A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$Title1."'"; ?>
	  },
	  height: 225,
	  width: 289,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPoints1Ah, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartA12 = new CanvasJS.Chart("chartContainer1A2", {
	  theme: "dark1",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$Title1."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "white",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Ah, JSON_NUMERIC_CHECK); ?>
	  }]
	});

//Pie Chart2

 	//--------Elementary--------\\
	var chartB1 = new CanvasJS.Chart("chartContainer1B", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title2."'"; ?>
	  },
	  height: 225,
	  width: 289,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPoints1Bh, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartB12 = new CanvasJS.Chart("chartContainer1B2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title2."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints1Bh, JSON_NUMERIC_CHECK); ?>
	  }]
	});

//Bar Chart3

	//--------------Elementary---------\\
	var chartC1 = new CanvasJS.Chart("chartContainer1C", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 439,
      width: 1007,
	  
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3h, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartC12 = new CanvasJS.Chart("chartContainer1C2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3h, JSON_NUMERIC_CHECK); ?>
        }]
    });

	chartA1.render();
	chartA12.render();
	chartB1.render();
	chartB12.render();
	chartC1.render();
	chartC12.render();

	}
</script>

<div class="contents">

	<div id="ElemSchool" class="leftTab2" style="display:block;">
		<form class="timeStamp" action="PHP/selDate.php" method="POST" style="width: 98.65%;">
			<select class="selDate2" name="time1">
				<?php
				if ($_SESSION['display'] != "none") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn2" type="submit" name="H4p">Go</button>
			<button id="ElemButton" class="timeBtn2" type="submit" name="NextPage2" style="left: 0.5%;">
				<i class="fas fa-arrow-left"></i>
				<span class="tooltiptext2">Elementary School</span>
			</button>
		</form>

		<div class="graphCont" style="width: 99.5%;">
			<div class="pieChartCont">
				<div id="graphZoom11a" class="pieUp">
					<div id="chartContainer1A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
				<div id="graphZoom11b" class="pieDown">
					<div id="chartContainer1B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
				</div>
			</div>
			<div id="graphZoom11c" class="barChartCont">
				<div class="barBorder">
					<div id="chartContainer1C" style="position: relative; height: 99%;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont2">
			<center>
		      <h3>4P's Beneficiaries of EB Magalona High Schools</h3>
		   </center>
		   <button type="button" id="exportBut1" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   <br>
		   <div class="nutritable" style="overflow-x: scroll;">
		    <?php
		      echo "
		        <table border='1' class=\"tabel2\" id=\"myTableg1\">
		            <tr>
		              <td colspan=\"2\" rowspan=\"2\"> </th>
		              <td colspan=\"24\">Year</th>
		            </tr>
		            <tr>";
		              for($a = $minh; $a <= $maxh; $a+=1){
		                echo "<td colspan=\"3\">" . $a ."-". $a+1 . "</td>";
		              }
		      echo "</tr>
		            <tr>
		              <td colspan=\"2\">Schools</td>";
		              for($a = $minh; $a <= $maxh; $a+=1){
		                echo "<td>Male</td>
		                      <td>Female</td>
		                      <td style=\"color:red;\">Total</td>";
		              }
		      echo "</tr>";
		      		$getGroup1h = "SELECT * FROM `{$tabName}` Where Groups = '$hs' Group BY School";
		      		$getGroprest1h = mysqli_query($conn3 ,$getGroup1h);
		      		$nrows1h = mysqli_num_rows($getGroprest1h);
		            for($b = 1; $b <= $nrows1h; $b+=1){
		              $rowh = mysqli_fetch_assoc($resultsh);
		              echo "
		              <tr>
		                <td colspan=\"2\">". $rowh['School'] ."</td>";
		                $yerh = $rowh['School'];
		                $maxxgh = "SELECT * FROM `{$tabName}` WHERE School = '$yerh' AND Groups = '$hs' AND Year <= '$max' ORDER BY Year DESC LIMIT 1;";
		                $resultg2h = mysqli_query($conn3, $maxxgh);
		                $rowsg2h = mysqli_fetch_array($resultg2h);
		                for($a = $minh; $a <= $rowsg2h['Year']; $a+=1){
		                  $rowsh = mysqli_fetch_array($results1h);
		                  echo "<td>". $rowsh['Male'] ."</td>
		                        <td>". $rowsh['Female'] ."</td>
		                        <td style=\"color:red;\">". $rowsh['Male']+$rowsh['Female'] ."</td>";
		                }
		              echo "</tr>";
		            }
		      echo "<tr>
		              <td colspan=\"2\" style=\"color:#cc0000;\">Total</td>";
		              for($a = $minh; $a <= $maxh; $a+=1){
		                $ttrowh = mysqli_fetch_array($ttresulth);
		                echo "<td style=\"color:#cc0000;\">". $ttrowh['tm'] ."</td>
		                      <td style=\"color:#cc0000;\">". $ttrowh['tf'] ."</td>
		                      <td style=\"color:#cc0000;\">". $ttrowh['tm']+$ttrowh['tf'] ."</td>";
		              }
		      echo "</tr>
		          </table>";
		    ?>
		</div>
		</div>
	</div>

</div>

<div id="GrapModal1a" class="graphModal1">
	<span class="graphClose1a">&times;</span>
	<div id="chartContainer1A2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1b" class="graphModal1">
	<span class="graphClose1b">&times;</span>
	<div id="chartContainer1B2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1c" class="graphModal1">
	<span class="graphClose1c">&times;</span>
	<div id="chartContainer1C2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<script>

var modal1a = document.getElementById("GrapModal1a");
var btn1a = document.getElementById("graphZoom11a");
var span1a = document.getElementsByClassName("graphClose1a")[0];

var modal1b = document.getElementById("GrapModal1b");
var btn1b = document.getElementById("graphZoom11b");
var span1b = document.getElementsByClassName("graphClose1b")[0];

var modal1c = document.getElementById("GrapModal1c");
var btn1c = document.getElementById("graphZoom11c");
var span1c = document.getElementsByClassName("graphClose1c")[0];


btn1a.onclick = function() {
  modal1a.style.display = "block";
}
span1a.onclick = function() {
  modal1a.style.display = "none";
}


btn1b.onclick = function() {
  modal1b.style.display = "block";
}
span1b.onclick = function() {
  modal1b.style.display = "none";
}

//Private

btn1c.onclick = function() {
  modal1c.style.display = "block";
}
span1c.onclick = function() {
  modal1c.style.display = "none";
}



window.onclick = function(event) {
  if (event.target == modal1a) {
    modal1a.style.display = "none";
  }

  if(event.target == modal1b){
  	modal1b.style.display = "none";
  }

  if(event.target == modal1c){
  	modal1c.style.display = "none";
  }
}

function html_table_to_excel(type){
    var data = document.getElementById('myTableg1');

    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

    XLSX.writeFile(file, '<?php echo $PI; ?>(Elementary).' + type);
	}

    const export_button = document.getElementById('exportBut1');

    export_button.addEventListener('click', () =>  {
    	html_table_to_excel('xlsx');
});

</script>

<script type="text/javascript" src="Script/animation.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>