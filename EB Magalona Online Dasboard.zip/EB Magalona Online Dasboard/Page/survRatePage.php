<?php 
include "Header.php";

$grossmin = $_SESSION['timeMin1'];
$grossmax = $_SESSION['timeMax1'];

$grossmin2 = $_SESSION['timeMin2'];
$grossmax2 = $_SESSION['timeMax2'];

$grossmin3 = $_SESSION['timeMin3'];
$grossmax3 = $_SESSION['timeMax3'];

if($_SESSION['display'] == "none"){
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
}
elseif($_SESSION['display'] == "Page1"){
	$chosenTime = $_SESSION['theTime'];
	$chosenTime2 = $grossmax2;
	$chosenTime3 = $grossmax3;
	
}
elseif($_SESSION['display'] == "Page2"){
	$chosenTime2 = $_SESSION['theTime2'];
	$chosenTime = $grossmax;
	$chosenTime3 = $grossmax3;
	
}
elseif($_SESSION['display'] == "Page3"){
	$chosenTime3 = $_SESSION['theTime3'];
	$chosenTime = $grossmax;
	$chosenTime2 = $grossmax2;
	
}

$tabName = "survivalrate";
$PI = "Student survive";
$PI2 = "survive";
$PI3 = "No. of Survived Students";

$Title3 = "Distric ".$PI3." by Year (Elementary)";
$Title3h = "Distric ".$PI3." by Year (High School)";
$Title3p = "Distric ".$PI3." by Year (Private)";

$Titlex = "Students ".$PI3." Percentage";

include "PHP/tables.php";
include "PHP/tables2.php";
include "PHP/graph2.php";

?>

<script type="text/javascript">
	window.onload = function() {
		//Bar Chart3

	//--------------Elementary---------\\
	var chartC1 = new CanvasJS.Chart("chartContainer1C", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 439,
      width: 1270,
	  
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartC12 = new CanvasJS.Chart("chartContainer1C2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3, JSON_NUMERIC_CHECK); ?>
        }]
    });
	//-----------Highschool---------\\
	var chartC1h = new CanvasJS.Chart("chartContainer1Ch", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3h."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 439,
      width: 1270,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	       yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3h, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartC12h = new CanvasJS.Chart("chartContainer1C2h", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3h."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2h, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	       	yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3h, JSON_NUMERIC_CHECK); ?>
        }]
    });
	//-----------Private---------\\
	var chartC1p = new CanvasJS.Chart("chartContainer1Cp", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3p."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 439,
      width: 1270,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1p, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2p, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "#,##0.00\"%\"",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3p, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartC12p = new CanvasJS.Chart("chartContainer1C2p", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title3p."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$Titlex."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C1p, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C2p, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints1C3p, JSON_NUMERIC_CHECK); ?>
        }]
    });

	chartC1.render();
	chartC12.render();
	chartC1h.render();
	chartC12h.render();
	chartC1p.render();
	chartC12p.render();
	}
</script>

<div class="contents">
	
	<div class="GroupButCont">
		<div class="butHolder">
			<button id="ElemButton" class="tablinks <?php if ($_SESSION['display'] == "Page1") {echo "active";}?>" onclick="change(event, 'ElemSchool')">
				<i class="fas fa-user-tie fa-1x"></i>
				<span class="tooltiptext">Elementary School</span>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page2") {echo "active";}?>" onclick="change(event, 'HighSchool')">
				<i class="fas fa-user-friends fa-1x"></i>
				<span class="tooltiptext">High School</span>
			</button>
			<button id="PriButton" class="tablinks <?php if ($_SESSION['display'] == "Page3") {echo "active";}?>" onclick="change(event, 'PrivateSchool')">
				<i class="fas fa-users fa-1x"></i>
				<span class="tooltiptext">Private School </span>
			</button>
		</div>
	</div>
	
	<div id="ElemSchool" class="leftTab" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?> >
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page2" || $_SESSION['display'] == "Page3") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin != "none") {
						for ($i=$grossmin; $i <= $grossmax; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
					for ($i=$grossmin; $i <= $grossmax; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="S1">Go</button>
		</form>

		<div class="graphCont">
			<div id="graphZoom11c" class="barChartCont" style="width: 100%;">
				<div class="barBorder">
					<div id="chartContainer1C" style="position: relative; height: 100%;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3><?php echo $PI; ?> Rate of EB Magalona Elementary Schools</h3>
		    </center>
		    <button type="button" id="exportBut1" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		    <br>
		    <?php
		      echo "
		        <table border='1' class=\"tabel\" id=\"myTableg1\">
		            <tr>
		              <td colspan=\"2\" rowspan=\"2\"> </th>
		              <td colspan=\"24\">Year</th>
		            </tr>
		            <tr>";
		            if ($min > 0) {
		              	for($a = $min; $a <= $max; $a+=1){

		              		echo "<td colspan=\"3\">" . $a ."-". $a+1 . "</td>";
		              	}
		            }
		            else{
		               	echo "<td colspan=\"3\">" . $min ."-". $min. "</td>";
		            }
		      echo "</tr>
		            <tr>
		              <td colspan=\"2\">Schools</td>";
		            if ($min>0) {
		              	for($a = $min; $a <= $max; $a+=1){
			                echo "<td>Male</td>
			                      <td>Female</td>
			                      <td style=\"color:red;\">Total</td>";
			            }
		            }
		            else {
		            	echo "<td>Male</td>
			            	  <td>Female</td>
			                  <td style=\"color:red;\">Total</td>";
		            }
		      echo "</tr>";
		      		$getGroup1 = "SELECT * FROM `{$tabName}` Where Groups = '$es' Group BY School";
		      		$getGroprest1 = mysqli_query($conn3 ,$getGroup1);
		      		$nrows1 = mysqli_num_rows($getGroprest1);
		            if (mysqli_num_rows($ttresult) > 0) {
		              	for($b = 1; $b <= $nrows1; $b+=1){
			              $row = mysqli_fetch_assoc($results);
			              echo "
			              <tr>
			                <td colspan=\"2\">". $row['School'] ."</td>";
			                $yer = $row['School'];
			                $maxxg = "SELECT * FROM `{$tabName}` WHERE School = '$yer' AND Groups = '$es' AND Year <= '$max' ORDER BY Year DESC LIMIT 1;";
			                $resultg2 = mysqli_query($conn3, $maxxg);
			                $rowsg2 = mysqli_fetch_array($resultg2);
			                for($a = $min; $a <= $rowsg2['Year']; $a+=1){
			                  $rows = mysqli_fetch_array($results1);
			                  echo "<td>". $rows['Male'] ."% </td>
			                        <td>". $rows['Female'] ."% </td>
			                        <td style=\"color:red;\">". round(($rows['Male']+$rows['Female'])/2,1) ."% </td>";
			                }
			              echo "</tr>";
			            }
		            }   
		      echo "<tr>
		              <td colspan=\"2\" style=\"color:#cc0000;\">Total</td>";
		            if (mysqli_num_rows($ttresult) > 0) {
		              	for($a = $min; $a <= $max; $a+=1){
			                $ttrow = mysqli_fetch_array($ttresult);
			                echo "<td style=\"color:#cc0000;\">". round($ttrow['tm']/$nrows1,1) ."% </td>
			                      <td style=\"color:#cc0000;\">". round($ttrow['tf']/$nrows1,1) ."% </td>
			                      <td style=\"color:#cc0000;\">". round(($ttrow['tm']+$ttrow['tf'])/($nrows1*2),1) ."% </td>";
			            }
		            }
		            else{
		            	echo "<td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>";
		            }
		      echo "</tr>
		          </table>";
		    ?>
		</div>
	</div>

	<div id="HighSchool" class="leftTab" <?php if ($_SESSION['display'] == "Page2") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page1" || $_SESSION['display'] == "Page3") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin2 != "none") {
						for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime2."-".($chosenTime2+1)."</option>";
					for ($i=$grossmin2; $i <= $grossmax2; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="S2">Go</button>
		</form>

		<div class="graphCont">
			<div id="graphZoom11ch" class="barChartCont" style="width: 100%;">
				<div class="barBorder">
					<div id="chartContainer1Ch" style="height: 100%;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3><?php echo $PI; ?> Rate of EB Magalona High Schools</h3>
		   </center>
		   <button type="button" id="exportBut2" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   <br>
		    <?php
		      echo "
		        <table border='1' class=\"tabel\" id=\"myTableg2\">
		            <tr>
		              <td colspan=\"2\" rowspan=\"2\"> </th>
		              <td colspan=\"24\">Year</th>
		            </tr>
		            <tr>";
		            if ($minh > 0) {
			            for($a = $minh; $a <= $maxh; $a+=1){
			               echo "<td colspan=\"3\">" . $a ."-". $a+1 . "</td>";
			            }
		            }
		            else{
		               	echo "<td colspan=\"3\">" . $minh ."-". $minh. "</td>";
		            }
		      echo "</tr>
		            <tr>
		              <td colspan=\"2\">Schools</td>";
		            if ($minh>0) {
		              	for($a = $minh; $a <= $maxh; $a+=1){
			                echo "<td>Male</td>
			                      <td>Female</td>
			                      <td style=\"color:red;\">Total</td>";
			            }
			        }
			        else {
			            echo "<td>Male</td>
				              <td>Female</td>
				              <td style=\"color:red;\">Total</td>";
			        }
		      echo "</tr>";
		      		$getGroup2 = "SELECT * FROM grossenrollrate Where Groups = '$hs' Group BY School";
		      		$getGroprest2 = mysqli_query($conn3 ,$getGroup2);
		      		$nrows2 = mysqli_num_rows($getGroprest2);
		      		if (mysqli_num_rows($ttresulth) > 0) {
			            for($b = 1; $b <= $nrows2; $b+=1){
			              $rowh = mysqli_fetch_assoc($resultsh);
			              echo "
			              <tr>
			                <td colspan=\"2\">". $rowh['School'] ."</td>";
			                $yerh = $rowh['School'];
			                $maxxgh = "SELECT * FROM grossenrollrate WHERE School = '$yerh' AND Groups = '$hs' AND Year <= '$maxh' ORDER BY Year DESC LIMIT 1;";
			                $resultg2h = mysqli_query($conn3, $maxxgh);
			                $rowsg2h = mysqli_fetch_array($resultg2h);
			                for($a = $minh; $a <= $rowsg2h['Year']; $a+=1){
			                  $rowsh = mysqli_fetch_array($results1h);
			                  echo "<td>". $rowsh['Male'] ."%</td>
			                        <td>". $rowsh['Female'] ."%</td>
			                        <td style=\"color:red;\">". round(($rowsh['Male']+$rowsh['Female'])/2,1) ."%</td>";
			                }
			              echo "</tr>";
			            }
			        }
		      echo "<tr>
		              <td colspan=\"2\" style=\"color:#cc0000;\">Total</td>";
		              if (mysqli_num_rows($ttresulth) > 0) {
			              for($a = $minh; $a <= $maxh; $a+=1){
			                $ttrowh = mysqli_fetch_array($ttresulth);
			                echo "<td style=\"color:#cc0000;\">". round($ttrowh['tm']/$nrows2,1) ."% </td>
			                      <td style=\"color:#cc0000;\">". round($ttrowh['tf']/$nrows2,1) ."% </td>
			                      <td style=\"color:#cc0000;\">". round(($ttrowh['tm']+$ttrowh['tf'])/($nrows2*2),1) ."% </td>";
			              }
			          }
			          else{
		            	echo "<td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>";
		              }
		      echo "</tr>
		          </table>";
		    ?>
		</div>
	</div>

	<div id="PrivateSchool" class="leftTab" <?php if ($_SESSION['display'] == "Page3") {echo "style=\"display:block;\" ";}?>>
		<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<form class="timeStamp" action="PHP/selDate.php" method="POST">
			<select class="selDate" name="time1">
				<?php
				if ($_SESSION['display'] == "none" || $_SESSION['display'] == "Page1" || $_SESSION['display'] == "Page2") {
					echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
					if ($grossmin3 != "none") {
						for ($i=$grossmi3n; $i <= $grossmax3; $i++) { 
							echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
						}
					}
					else{
						echo "<option value=\"".$i."\"> SY: No Entry</option>";
					}
				}
				else{
					echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime3."-".($chosenTime3+1)."</option>";
					for ($i=$grossmin3; $i <= $grossmax3; $i++) { 
						echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
					}
				}
				?>
			</select>
			<button class="timeBtn" type="submit" name="S3">Go</button>
		</form>

		<div class="graphCont">
			<div id="graphZoom11cp" class="barChartCont" style="width: 100%;">
				<div class="barBorder">
					<div id="chartContainer1Cp" style="height: 100%;"></div>
				</div>
			</div>
		</div>

		<div class="tableCont">
			<center>
		      <h3><?php echo $PI; ?> Rate of EB Magalona Private Schools</h3>
		   </center>
		   <button type="button" id="exportBut3" class="ExpButton">Export Table <i class="fas fa-download"></i></button>
		   <br>
		    <?php
		      echo "
		        <table border='1' class=\"tabel\" id=\"myTableg3\">
		            <tr>
		              <td colspan=\"2\" rowspan=\"2\"> </th>
		              <td colspan=\"24\">Year</th>
		            </tr>
		            <tr>";
		            if ($minp > 0) {
		            	for($a = $minp; $a <= $maxp; $a+=1){
			                echo "<td colspan=\"3\">" . $a ."-". $a+1 . "</td>";
			            }
					}
		            else{
		               	echo "<td colspan=\"3\">" . $minp ."-". $minp. "</td>";
		            }
		      echo "</tr>
		            <tr>
		              <td colspan=\"2\">Schools</td>";
		              if ($minh>0) {
		              	 for($a = $minp; $a <= $maxp; $a+=1){
			                echo "<td>Male</td>
			                      <td>Female</td>
			                      <td style=\"color:red;\">Total</td>";
			              }
					  }
			          else {
			            echo "<td>Male</td>
				              <td>Female</td>
				              <td style=\"color:red;\">Total</td>";
			          }
		      echo "</tr>";
		      		$getGroup3 = "SELECT * FROM grossenrollrate Where Groups = '$ps' Group BY School";
		      		$getGroprest3 = mysqli_query($conn3 ,$getGroup3);
		      		$nrows3 = mysqli_num_rows($getGroprest3);
		            if (mysqli_num_rows($ttresultp) > 0) {
			            for($b = 1; $b <= $nrows3; $b+=1){
			              $rowp = mysqli_fetch_array($resultsp);
			              echo "
			              <tr>
			                <td colspan=\"2\">". $rowp['School'] ."</td>";
			                $yerp = $rowp['School'];
			                $maxxgp = "SELECT * FROM grossenrollrate WHERE School = '$yerp' AND Groups = '$ps' AND Year <= '$maxp' ORDER BY Year DESC LIMIT 1;";
			                $resultg2p = mysqli_query($conn3, $maxxgp);
			                $rowsg2p = mysqli_fetch_array($resultg2p);
			                for($a = $minp; $a <= $rowsg2p['Year']; $a+=1){
			                  $rowsp = mysqli_fetch_array($results1p);
			                  echo "<td>". $rowsp['Male'] ."%</td>
			                        <td>". $rowsp['Female'] ."%</td>
			                        <td style=\"color:red;\">". round(($rowsp['Male']+$rowsp['Female'])/2,1) ."%</td>";
			                }
			              echo "</tr>";
			            }
		            }
		      echo "<tr>
		              <td colspan=\"2\" style=\"color:#cc0000;\">Total</td>";
		              if (mysqli_num_rows($ttresulth) > 0) {
			              for($a = $minp; $a <= $maxp; $a+=1){
			                $ttrowp = mysqli_fetch_array($ttresultp);
			                echo "<td style=\"color:#cc0000;\">". round($ttrowp['tm']/$nrows3,1) ."%</td>
			                      <td style=\"color:#cc0000;\">". round($ttrowp['tf']/$nrows3,1) ."%</td>
			                      <td style=\"color:#cc0000;\">". round(($ttrowp['tm']+$ttrowp['tf'])/($nrows3*2),1) ."%</td>";
			              }
			          }
			          else{
		            	echo "<td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>
			                  <td style=\"color:#cc0000;\">0% </td>";
		              }
		      echo "</tr>
		          </table>";
		    ?>
		</div>
	</div>
</div>

<div id="GrapModal1a" class="graphModal1">
	<span class="graphClose1a">&times;</span>
	<div id="chartContainer1A2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1ah" class="graphModal1">
	<span class="graphClose1ah">&times;</span>
	<div id="chartContainer1A2h" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1ap" class="graphModal1">
	<span class="graphClose1ap">&times;</span>
	<div id="chartContainer1A2p" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1b" class="graphModal1">
	<span class="graphClose1b">&times;</span>
	<div id="chartContainer1B2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1bh" class="graphModal1">
	<span class="graphClose1bh">&times;</span>
	<div id="chartContainer1B2h" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1bp" class="graphModal1">
	<span class="graphClose1bp">&times;</span>
	<div id="chartContainer1B2p" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1c" class="graphModal1">
	<span class="graphClose1c">&times;</span>
	<div id="chartContainer1C2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1ch" class="graphModal1">
	<span class="graphClose1ch">&times;</span>
	<div id="chartContainer1C2h" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal1cp" class="graphModal1">
	<span class="graphClose1cp">&times;</span>
	<div id="chartContainer1C2p" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<script>

	var modal1c = document.getElementById("GrapModal1c");
	var btn1c = document.getElementById("graphZoom11c");
	var span1c = document.getElementsByClassName("graphClose1c")[0];

	var modal1ch = document.getElementById("GrapModal1ch");
	var btn1ch = document.getElementById("graphZoom11ch");
	var span1ch = document.getElementsByClassName("graphClose1ch")[0];

	var modal1cp = document.getElementById("GrapModal1cp");
	var btn1cp = document.getElementById("graphZoom11cp");
	var span1cp = document.getElementsByClassName("graphClose1cp")[0];

	//bar graph

	btn1c.onclick = function() {
	  modal1c.style.display = "block";
	}
	span1c.onclick = function() {
	  modal1c.style.display = "none";
	}
	btn1ch.onclick = function() {
	  modal1ch.style.display = "block";
	}
	span1ch.onclick = function() {
	  modal1ch.style.display = "none";
	}
	btn1cp.onclick = function() {
	  modal1cp.style.display = "block";
	}
	span1cp.onclick = function() {
	  modal1cp.style.display = "none";
	}



	window.onclick = function(event) {

	  if(event.target == modal1c){
	  	modal1c.style.display = "none";
	  }
	  if(event.target == modal1ch){
	  	modal1ch.style.display = "none";
	  }
	  if(event.target == modal1cp){
	  	modal1cp.style.display = "none";
	  }
	}

function html_table_to_excel(type){

    var data = document.getElementById('myTableg1');

    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1", raw: true});

    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

    XLSX.writeFile(file, '<?php echo $PI; ?>(Elementary).' + type);
	}

    const export_button = document.getElementById('exportBut1');

    export_button.addEventListener('click', () =>  {
    	html_table_to_excel('xlsx');
});

function html_table_to_excel2(type){

    var data = document.getElementById('myTableg2');

    var file = XLSX.utils.table_to_book(data, {sheet: "sheet", raw: true});

    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

    XLSX.writeFile(file, '<?php echo $PI; ?>(Highschool).' + type);
	}

    const export_button2 = document.getElementById('exportBut2');

    export_button2.addEventListener('click', () =>  {
    	html_table_to_excel2('xlsx');
});

function html_table_to_excel3(type){

    var data = document.getElementById('myTableg3');

    var file = XLSX.utils.table_to_book(data, {sheet: "sheet", raw: true});

    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

    XLSX.writeFile(file, '<?php echo $PI; ?>(Private).' + type);
	}

    const export_button3 = document.getElementById('exportBut3');

    export_button3.addEventListener('click', () =>  {
    	html_table_to_excel3('xlsx');
});

</script>

<script type="text/javascript" src="Script/animation.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>