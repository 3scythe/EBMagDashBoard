<?php

include "connect.php";

//gross
	if(isset($_POST['g1'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];

		header('Location: ../grossRatePage.php');
	}
	elseif(isset($_POST['g2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../grossRatePage.php');
	}
	elseif(isset($_POST['g3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../grossRatePage.php');
	}
//net
	elseif(isset($_POST['N1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../netRatePage.php');
	}
	elseif(isset($_POST['N2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../netRatePage.php');
	}
	elseif(isset($_POST['N3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../netRatePage.php');
	}
//drop
	elseif(isset($_POST['D1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../dropRatePage.php');
	}
	elseif(isset($_POST['D2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../dropRatePage.php');
	}
	elseif(isset($_POST['D3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../dropRatePage.php');
	}
//surv
	elseif(isset($_POST['S1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../survRatePage.php');
	}
	elseif(isset($_POST['S2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../survRatePage.php');
	}
	elseif(isset($_POST['S3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../survRatePage.php');
	}
//fail
	elseif(isset($_POST['F1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../failRatePage.php');
	}
	elseif(isset($_POST['F2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../failRatePage.php');
	}
	elseif(isset($_POST['F3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../failRatePage.php');
	}
//com
	elseif(isset($_POST['Cp1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../CompRatePage.php');
	}
	elseif(isset($_POST['Cp2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../CompRatePage.php');
	}
	elseif(isset($_POST['Cp3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../CompRatePage.php');
	}
//ret
	elseif(isset($_POST['Rt1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../retRatePage.php');
	}
	elseif(isset($_POST['Rt2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../retRatePage.php');
	}
	elseif(isset($_POST['Rt3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../retRatePage.php');
	}
//grad
	elseif(isset($_POST['Gd1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../gradRatePage.php');
	}
	elseif(isset($_POST['Gd2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../gradRatePage.php');
	}
	elseif(isset($_POST['Gd3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../gradRatePage.php');
	}
//pro
	elseif(isset($_POST['P1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../promRatePage.php');
	}
	elseif(isset($_POST['P2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../promRatePage.php');
	}
	elseif(isset($_POST['P3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../promRatePage.php');
	}
//rep
	elseif(isset($_POST['Rp1'])){
		
		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../repRatePage.php');
	}
	elseif(isset($_POST['Rp2'])){
		
		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time2'];
		header('Location: ../repRatePage.php');
	}
	elseif(isset($_POST['Rp3'])){
		
		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time3'];
		header('Location: ../repRatePage.php');
	}
//4p
	if(isset($_POST['E4p'])){

		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../elem4P.php');

	}
	elseif(isset($_POST['H4p'])){

		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../high4P.php');
	}

	if (isset($_POST['NextPage1'])) {

		$minn1 = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
	    $resultmin1 = mysqli_query($conn3, $minn1);
	    $maxx1 = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
	    $resultmax1 = mysqli_query($conn3, $maxx1);

	    session_start();

	    if (mysqli_num_rows($resultmax1) > 0) {
	        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
	        $min1 = $rowsmin1['Year'];
	        $rows1 = mysqli_fetch_assoc($resultmax1);
	        $max1 = $rows1['Year'];

	        $_SESSION['timeMin1'] = $min1;
	        $_SESSION['timeMax1'] = $max1;
	    }
	    else{
	       $_SESSION['timeMin1'] = "none";
	       $_SESSION['timeMax1'] = "none";
	    }

	    $_SESSION['display'] = "none";
		header('Location: ../high4P.php');
	}

	if (isset($_POST['NextPage2'])) {
		
		$minn1 = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
	    $resultmin1 = mysqli_query($conn3, $minn1);
	    $maxx1 = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
	    $resultmax1 = mysqli_query($conn3, $maxx1);

	    session_start();

	    if (mysqli_num_rows($resultmax1) > 0) {
	        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
	        $min1 = $rowsmin1['Year'];
	        $rows1 = mysqli_fetch_assoc($resultmax1);
	        $max1 = $rows1['Year'];

	        $_SESSION['timeMin1'] = $min1;
	        $_SESSION['timeMax1'] = $max1;
	    }
	    else{
	       $_SESSION['timeMin1'] = "none";
	       $_SESSION['timeMax1'] = "none";
	    }

	    $_SESSION['display'] = "none";
		header('Location: ../elem4P.php');
	}
//nutritional Status

	if(isset($_POST['ENutri'])){

		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../elemNutri.php');

	}
	elseif(isset($_POST['PNutri'])){

		session_start();

		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../PriNutri.php');

	}

	if (isset($_POST['NextPage3'])) {

		$minn1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
	    $resultmin1 = mysqli_query($conn3, $minn1);
	    $maxx1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
	    $resultmax1 = mysqli_query($conn3, $maxx1);

	    session_start();

	    if (mysqli_num_rows($resultmax1) > 0) {
	        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
	        $min1 = $rowsmin1['Year'];
	        $rows1 = mysqli_fetch_assoc($resultmax1);
	        $max1 = $rows1['Year'];

	        $_SESSION['timeMin1'] = $min1;
	        $_SESSION['timeMax1'] = $max1;
	    }
	    else{
	       $_SESSION['timeMin1'] = "none";
	       $_SESSION['timeMax1'] = "none";
	    }

	    $_SESSION['display'] = "none";
		header('Location: ../PriNutri.php');
	}

	if (isset($_POST['NextPage4'])) {
		
		$minn1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
	    $resultmin1 = mysqli_query($conn3, $minn1);
	    $maxx1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
	    $resultmax1 = mysqli_query($conn3, $maxx1);

	    session_start();

	    if (mysqli_num_rows($resultmax1) > 0) {
	        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
	        $min1 = $rowsmin1['Year'];
	        $rows1 = mysqli_fetch_assoc($resultmax1);
	        $max1 = $rows1['Year'];

	        $_SESSION['timeMin1'] = $min1;
	        $_SESSION['timeMax1'] = $max1;
	    }
	    else{
	       $_SESSION['timeMin1'] = "none";
	       $_SESSION['timeMax1'] = "none";
	    }

	    $_SESSION['display'] = "none";
		header('Location: ../elemNutri.php');
	}
//PhilIriOral
	if(isset($_POST['EOgrd3'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../engOralPhiliri.php');

	}
	elseif(isset($_POST['EOgrd4'])){

		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../engOralPhiliri.php');
	}
	elseif(isset($_POST['EOgrd5'])){

		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../engOralPhiliri.php');
	}
	elseif(isset($_POST['EOgrd6'])){

		session_start();

		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../engOralPhiliri.php');
	}
	elseif(isset($_POST['EOgrd7'])){

		session_start();

		$_SESSION['display'] = "Page5";
		$_SESSION['theTime5'] = $_POST['time1'];
		header('Location: ../engOralPhiliri.php');
	}

	if(isset($_POST['FOgrd3'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../FilOralPhiliri.php');

	}
	elseif(isset($_POST['FOgrd4'])){

		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../FilOralPhiliri.php');
	}
	elseif(isset($_POST['FOgrd5'])){

		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../FilOralPhiliri.php');
	}
	elseif(isset($_POST['FOgrd6'])){

		session_start();

		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../FilOralPhiliri.php');
	}
	elseif(isset($_POST['FOgrd7'])){

		session_start();

		$_SESSION['display'] = "Page5";
		$_SESSION['theTime5'] = $_POST['time1'];
		header('Location: ../FilOralPhiliri.php');
	}
//PhilIriSilent
	if(isset($_POST['ESgrd3'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../engSilentPhiliri.php');

	}
	elseif(isset($_POST['ESgrd4'])){

		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../engSilentPhiliri.php');
	}
	elseif(isset($_POST['ESgrd5'])){

		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../engSilentPhiliri.php');
	}
	elseif(isset($_POST['ESgrd6'])){

		session_start();

		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../engSilentPhiliri.php');
	}
	elseif(isset($_POST['ESgrd7'])){

		session_start();

		$_SESSION['display'] = "Page5";
		$_SESSION['theTime5'] = $_POST['time1'];
		header('Location: ../engSilentPhiliri.php');
	}

	if(isset($_POST['FSgrd3'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../FilSilentPhiliri.php');

	}
	elseif(isset($_POST['FSgrd4'])){

		session_start();

		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../FilSilentPhiliri.php');
	}
	elseif(isset($_POST['FSgrd5'])){

		session_start();

		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../FilSilentPhiliri.php');
	}
	elseif(isset($_POST['FSgrd6'])){

		session_start();

		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../FilSilentPhiliri.php');
	}
	elseif(isset($_POST['FSgrd7'])){

		session_start();

		$_SESSION['display'] = "Page5";
		$_SESSION['theTime5'] = $_POST['time1'];
		header('Location: ../FilSilentPhiliri.php');
	}

//Individual
	if(isset($_POST['ESPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../ElemSchool.php');
	}
	elseif(isset($_POST['ESPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../ElemSchool.php');
	}
	elseif(isset($_POST['ESNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}
	elseif(isset($_POST['ES4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}

//High
	if(isset($_POST['HSPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}
	elseif(isset($_POST['HSPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}
	elseif(isset($_POST['HSNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}
	elseif(isset($_POST['HS4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../HighSchool.php');
	}
//Pri
	if(isset($_POST['PSPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../PriSchool.php');
	}
	elseif(isset($_POST['PSPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../PriSchool.php');
	}
	elseif(isset($_POST['PSNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../PriSchool.php');
	}
	elseif(isset($_POST['PS4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../PriSchool.php');
	}

?>