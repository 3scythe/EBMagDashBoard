<?php
include "connect.php";

if(isset($_POST['adlogin'])){

    $uname = mysqli_real_escape_string($conn,$_POST['UserID']);
    $password = mysqli_real_escape_string($conn,$_POST['UserPass']);


    if ($uname != "" && $password != ""){

        $sql_query = "select * from adminusers where username='".$uname."' and passcode='".$password."'";
        $result = mysqli_query($conn, $sql_query);
        $cntUser = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);

        if($cntUser > 0){
            session_start();
            $_SESSION['usename'] = $row['username'];
            $_SESSION['usepass'] = $row['passcode'];
            $_SESSION['fname'] = $row['first_name'];
            $_SESSION['midname'] = $row['middle_name'];
            $_SESSION['lname'] = $row['last_name'];
            $_SESSION['bdate'] = $row['birth_date'];
            $_SESSION['myage'] = $row['age'];
            $_SESSION['mygender'] = $row['gender'];
            $_SESSION['myaddress'] = $row['address'];
            $_SESSION['myjobDiscrip'] = $row['jobDiscrip'];
            $_SESSION['mycontact'] = $row['contactNum'];
            header('Location: ../AdminDashboard.php');
        }else{
        	header('Location: ../index.php?error=invalid&user&or&password');
        }
    }
    else{
    	header('Location: ../index.php?error=missingfields');
    }

}