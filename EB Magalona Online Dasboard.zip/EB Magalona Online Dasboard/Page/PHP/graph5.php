<?php
	include "connect.php";

//Grade3
 	$data1a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1a = mysqli_query($conn3, $data1a);

	if (mysqli_num_rows($dataresult1a) > 0) {
		$total1a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1a = mysqli_query($conn3, $total1a);
		$totaldata1a = mysqli_fetch_assoc($totalresult1a);

		$totalGross1a = $totaldata1a['ertm']+$totaldata1a['ertf'];

		$dataPoints1A = array(
			array("label" => "Slow", "y" => (($totaldata1a['sstm']+$totaldata1a['sstf'])/$totalGross1a)*100),
			array("label" => "Average", "y" => (($totaldata1a['satm']+$totaldata1a['satf'])/$totalGross1a)*100),
			array("label" => "Fast", "y" => (($totaldata1a['sftm']+$totaldata1a['sftf'])/$totalGross1a)*100)
		);

			$dataPoints1Aa = array(
				array("label" => "Slow", "y" => ($totaldata1a['sstm']/$totaldata1a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a['satm']/$totaldata1a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['sftm']/$totaldata1a['ertm'])*100)
			);

			$dataPoints1Ab = array(
				array("label" => "Slow", "y" => ($totaldata1a['sstf']/$totaldata1a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a['satf']/$totaldata1a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['sftf']/$totaldata1a['ertf'])*100)
			);

		$dataPoints1B = array(
			array("label" => "Frustration", "y" => (($totaldata1a['cfttm']+$totaldata1a['cfttf'])/$totalGross1a)*100),
			array("label" => "Instructional", "y" => (($totaldata1a['cittm']+$totaldata1a['cittf'])/$totalGross1a)*100),
			array("label" => "Independent", "y" => (($totaldata1a['cidtm']+$totaldata1a['cidtf'])/$totalGross1a)*100)
		);

			$dataPoints1Ba = array(
				array("label" => "Slow", "y" => ($totaldata1a['cfttm']/$totaldata1a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a['cittm']/$totaldata1a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['cidtm']/$totaldata1a['ertm'])*100)
			);

			$dataPoints1Bb = array(
				array("label" => "Slow", "y" => ($totaldata1a['cfttf']/$totaldata1a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a['cittf']/$totaldata1a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['cidtf']/$totaldata1a['ertf'])*100)
			);

		$dataPoints1C = array(
			array("label" => "Frustration", "y" => (($totaldata1a['rlfttm']+$totaldata1a['rlfttf'])/$totalGross1a)*100),
			array("label" => "Instructional", "y" => (($totaldata1a['rlittm']+$totaldata1a['rlittf'])/$totalGross1a)*100),
			array("label" => "Independent", "y" => (($totaldata1a['rlidtm']+$totaldata1a['rlidtf'])/$totalGross1a)*100)
		);

			$dataPoints1Ca = array(
				array("label" => "Slow", "y" => ($totaldata1a['rlfttm']/$totaldata1a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a['rlittm']/$totaldata1a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['rlidtm']/$totaldata1a['ertm'])*100)
			);

			$dataPoints1Cb = array(
				array("label" => "Slow", "y" => ($totaldata1a['rlfttf']/$totaldata1a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a['rlittf']/$totaldata1a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a['rlidtf']/$totaldata1a['ertf'])*100)
			);
	}
	else {
		$dataPoints1A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1a2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1a2 = mysqli_query($conn3, $data1a2);

	if (mysqli_num_rows($dataresult1a2) > 0) {
		$total1a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1a2 = mysqli_query($conn3, $total1a2);
		$totaldata1a2 = mysqli_fetch_assoc($totalresult1a2);

		$totalGross1a2 = $totaldata1a2['ertm']+$totaldata1a2['ertf'];

		$dataPoints1A2 = array(
			array("label" => "Slow", "y" => (($totaldata1a2['sstm']+$totaldata1a2['sstf'])/$totalGross1a2)*100),
			array("label" => "Average", "y" => (($totaldata1a2['satm']+$totaldata1a2['satf'])/$totalGross1a2)*100),
			array("label" => "Fast", "y" => (($totaldata1a2['sftm']+$totaldata1a2['sftf'])/$totalGross1a2)*100)
		);

			$dataPoints1A2a = array(
				array("label" => "Slow", "y" => ($totaldata1a2['sstm']/$totaldata1a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['satm']/$totaldata1a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['sftm']/$totaldata1a2['ertm'])*100)
			);

			$dataPoints1A2b = array(
				array("label" => "Slow", "y" => ($totaldata1a2['sstf']/$totaldata1a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['satf']/$totaldata1a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['sftf']/$totaldata1a2['ertf'])*100)
			);

		$dataPoints1B2 = array(
			array("label" => "Frustration", "y" => (($totaldata1a2['cfttm']+$totaldata1a2['cfttf'])/$totalGross1a2)*100),
			array("label" => "Instructional", "y" => (($totaldata1a2['cittm']+$totaldata1a2['cittf'])/$totalGross1a2)*100),
			array("label" => "Independent", "y" => (($totaldata1a2['cidtm']+$totaldata1a2['cidtf'])/$totalGross1a2)*100)
		);

			$dataPoints1B2a = array(
				array("label" => "Slow", "y" => ($totaldata1a2['cfttm']/$totaldata1a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['cittm']/$totaldata1a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['cidtm']/$totaldata1a2['ertm'])*100)
			);

			$dataPoints1B2b = array(
				array("label" => "Slow", "y" => ($totaldata1a2['cfttf']/$totaldata1a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['cittf']/$totaldata1a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['cidtf']/$totaldata1a2['ertf'])*100)
			);

		$dataPoints1C2 = array(
			array("label" => "Frustration", "y" => (($totaldata1a2['rlfttm']+$totaldata1a2['rlfttf'])/$totalGross1a2)*100),
			array("label" => "Instructional", "y" => (($totaldata1a2['rlittm']+$totaldata1a2['rlittf'])/$totalGross1a2)*100),
			array("label" => "Independent", "y" => (($totaldata1a2['rlidtm']+$totaldata1a2['rlidtf'])/$totalGross1a2)*100)
		);

			$dataPoints1C2a = array(
				array("label" => "Slow", "y" => ($totaldata1a2['rlfttm']/$totaldata1a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['rlittm']/$totaldata1a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['rlidtm']/$totaldata1a2['ertm'])*100)
			);

			$dataPoints1C2b = array(
				array("label" => "Slow", "y" => ($totaldata1a2['rlfttf']/$totaldata1a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata1a2['rlittf']/$totaldata1a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata1a2['rlidtf']/$totaldata1a2['ertf'])*100)
			);
	}
	else {
		$dataPoints1A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade4
 	
 	$data2a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult2a = mysqli_query($conn3, $data2a);

	if (mysqli_num_rows($dataresult2a) > 0) {
		$total2a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult2a = mysqli_query($conn3, $total2a);
		$totaldata2a = mysqli_fetch_assoc($totalresult2a);

		$totalGross2a = $totaldata2a['ertm']+$totaldata2a['ertf'];

		$dataPoints2A = array(
			array("label" => "Slow", "y" => (($totaldata2a['sstm']+$totaldata2a['sstf'])/$totalGross2a)*100),
			array("label" => "Average", "y" => (($totaldata2a['satm']+$totaldata2a['satf'])/$totalGross2a)*100),
			array("label" => "Fast", "y" => (($totaldata2a['sftm']+$totaldata2a['sftf'])/$totalGross2a)*100)
		);

			$dataPoints2Aa = array(
				array("label" => "Slow", "y" => ($totaldata2a['sstm']/$totaldata2a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a['satm']/$totaldata2a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['sftm']/$totaldata2a['ertm'])*100)
			);

			$dataPoints2Ab = array(
				array("label" => "Slow", "y" => ($totaldata2a['sstf']/$totaldata2a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a['satf']/$totaldata2a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['sftf']/$totaldata2a['ertf'])*100)
			);

		$dataPoints2B = array(
			array("label" => "Frustration", "y" => (($totaldata2a['cfttm']+$totaldata2a['cfttf'])/$totalGross2a)*100),
			array("label" => "Instructional", "y" => (($totaldata2a['cittm']+$totaldata2a['cittf'])/$totalGross2a)*100),
			array("label" => "Independent", "y" => (($totaldata2a['cidtm']+$totaldata2a['cidtf'])/$totalGross2a)*100)
		);

			$dataPoints2Ba = array(
				array("label" => "Slow", "y" => ($totaldata2a['cfttm']/$totaldata2a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a['cittm']/$totaldata2a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['cidtm']/$totaldata2a['ertm'])*100)
			);

			$dataPoints2Bb = array(
				array("label" => "Slow", "y" => ($totaldata2a['cfttf']/$totaldata2a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a['cittf']/$totaldata2a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['cidtf']/$totaldata2a['ertf'])*100)
			);

		$dataPoints2C = array(
			array("label" => "Frustration", "y" => (($totaldata2a['rlfttm']+$totaldata2a['rlfttf'])/$totalGross2a)*100),
			array("label" => "Instructional", "y" => (($totaldata2a['rlittm']+$totaldata2a['rlittf'])/$totalGross2a)*100),
			array("label" => "Independent", "y" => (($totaldata2a['rlidtm']+$totaldata2a['rlidtf'])/$totalGross2a)*100)
		);

			$dataPoints2Ca = array(
				array("label" => "Slow", "y" => ($totaldata2a['rlfttm']/$totaldata2a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a['rlittm']/$totaldata2a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['rlidtm']/$totaldata2a['ertm'])*100)
			);

			$dataPoints2Cb = array(
				array("label" => "Slow", "y" => ($totaldata2a['rlfttf']/$totaldata2a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a['rlittf']/$totaldata2a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a['rlidtf']/$totaldata2a['ertf'])*100)
			);
	}
	else {
		$dataPoints2A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data2a2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult2a2 = mysqli_query($conn3, $data2a2);

	if (mysqli_num_rows($dataresult2a2) > 0) {
		$total2a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' AND pORp = 'post'";
		$totalresult2a2 = mysqli_query($conn3, $total2a2);
		$totaldata2a2 = mysqli_fetch_assoc($totalresult2a2);

		$totalGross2a2 = $totaldata2a2['ertm']+$totaldata2a2['ertf'];

		$dataPoints2A2 = array(
			array("label" => "Slow", "y" => (($totaldata2a2['sstm']+$totaldata2a2['sstf'])/$totalGross2a2)*100),
			array("label" => "Average", "y" => (($totaldata2a2['satm']+$totaldata2a2['satf'])/$totalGross2a2)*100),
			array("label" => "Fast", "y" => (($totaldata2a2['sftm']+$totaldata2a2['sftf'])/$totalGross2a2)*100)
		);

			$dataPoints2A2a = array(
				array("label" => "Slow", "y" => ($totaldata2a2['sstm']/$totaldata2a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['satm']/$totaldata2a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['sftm']/$totaldata2a2['ertm'])*100)
			);

			$dataPoints2A2b = array(
				array("label" => "Slow", "y" => ($totaldata2a2['sstf']/$totaldata2a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['satf']/$totaldata2a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['sftf']/$totaldata2a2['ertf'])*100)
			);

		$dataPoints2B2 = array(
			array("label" => "Frustration", "y" => (($totaldata2a2['cfttm']+$totaldata2a2['cfttf'])/$totalGross2a2)*100),
			array("label" => "Instructional", "y" => (($totaldata2a2['cittm']+$totaldata2a2['cittf'])/$totalGross2a2)*100),
			array("label" => "Independent", "y" => (($totaldata2a2['cidtm']+$totaldata2a2['cidtf'])/$totalGross2a2)*100)
		);

			$dataPoints2B2a = array(
				array("label" => "Slow", "y" => ($totaldata2a2['cfttm']/$totaldata2a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['cittm']/$totaldata2a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['cidtm']/$totaldata2a2['ertm'])*100)
			);

			$dataPoints2B2b = array(
				array("label" => "Slow", "y" => ($totaldata2a2['cfttf']/$totaldata2a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['cittf']/$totaldata2a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['cidtf']/$totaldata2a2['ertf'])*100)
			);

		$dataPoints2C2 = array(
			array("label" => "Frustration", "y" => (($totaldata2a2['rlfttm']+$totaldata2a2['rlfttf'])/$totalGross2a2)*100),
			array("label" => "Instructional", "y" => (($totaldata2a2['rlittm']+$totaldata2a2['rlittf'])/$totalGross2a2)*100),
			array("label" => "Independent", "y" => (($totaldata2a2['rlidtm']+$totaldata2a2['rlidtf'])/$totalGross2a2)*100)
		);

			$dataPoints2C2a = array(
				array("label" => "Slow", "y" => ($totaldata2a2['rlfttm']/$totaldata2a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['rlittm']/$totaldata2a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['rlidtm']/$totaldata2a2['ertm'])*100)
			);

			$dataPoints2C2b = array(
				array("label" => "Slow", "y" => ($totaldata2a2['rlfttf']/$totaldata2a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata2a2['rlittf']/$totaldata2a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata2a2['rlidtf']/$totaldata2a2['ertf'])*100)
			);
	}
	else {
		$dataPoints2A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade5
 	
 	$data3a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult3a = mysqli_query($conn3, $data3a);

	if (mysqli_num_rows($dataresult3a) > 0) {
		$total3a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult3a = mysqli_query($conn3, $total3a);
		$totaldata3a = mysqli_fetch_assoc($totalresult3a);

		$totalGross3a = $totaldata3a['ertm']+$totaldata3a['ertf'];

		$dataPoints3A = array(
			array("label" => "Slow", "y" => (($totaldata3a['sstm']+$totaldata3a['sstf'])/$totalGross3a)*100),
			array("label" => "Average", "y" => (($totaldata3a['satm']+$totaldata3a['satf'])/$totalGross3a)*100),
			array("label" => "Fast", "y" => (($totaldata3a['sftm']+$totaldata3a['sftf'])/$totalGross3a)*100)
		);

			$dataPoints3Aa = array(
				array("label" => "Slow", "y" => ($totaldata3a['sstm']/$totaldata3a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a['satm']/$totaldata3a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['sftm']/$totaldata3a['ertm'])*100)
			);

			$dataPoints3Ab = array(
				array("label" => "Slow", "y" => ($totaldata3a['sstf']/$totaldata3a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a['satf']/$totaldata3a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['sftf']/$totaldata3a['ertf'])*100)
			);

		$dataPoints3B = array(
			array("label" => "Frustration", "y" => (($totaldata3a['cfttm']+$totaldata3a['cfttf'])/$totalGross3a)*100),
			array("label" => "Instructional", "y" => (($totaldata3a['cittm']+$totaldata3a['cittf'])/$totalGross3a)*100),
			array("label" => "Independent", "y" => (($totaldata3a['cidtm']+$totaldata3a['cidtf'])/$totalGross3a)*100)
		);

			$dataPoints3Ba = array(
				array("label" => "Slow", "y" => ($totaldata3a['cfttm']/$totaldata3a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a['cittm']/$totaldata3a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['cidtm']/$totaldata3a['ertm'])*100)
			);

			$dataPoints3Bb = array(
				array("label" => "Slow", "y" => ($totaldata3a['cfttf']/$totaldata3a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a['cittf']/$totaldata3a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['cidtf']/$totaldata3a['ertf'])*100)
			);

		$dataPoints3C = array(
			array("label" => "Frustration", "y" => (($totaldata3a['rlfttm']+$totaldata3a['rlfttf'])/$totalGross3a)*100),
			array("label" => "Instructional", "y" => (($totaldata3a['rlittm']+$totaldata3a['rlittf'])/$totalGross3a)*100),
			array("label" => "Independent", "y" => (($totaldata3a['rlidtm']+$totaldata3a['rlidtf'])/$totalGross3a)*100)
		);

			$dataPoints3Ca = array(
				array("label" => "Slow", "y" => ($totaldata3a['rlfttm']/$totaldata3a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a['rlittm']/$totaldata3a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['rlidtm']/$totaldata3a['ertm'])*100)
			);

			$dataPoints3Cb = array(
				array("label" => "Slow", "y" => ($totaldata3a['rlfttf']/$totaldata3a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a['rlittf']/$totaldata3a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a['rlidtf']/$totaldata3a['ertf'])*100)
			);
	}
	else {
		$dataPoints3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data3a2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult3a2 = mysqli_query($conn3, $data3a2);

	if (mysqli_num_rows($dataresult3a2) > 0) {
		$total3a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' AND pORp = 'post'";
		$totalresult3a2 = mysqli_query($conn3, $total3a2);
		$totaldata3a2 = mysqli_fetch_assoc($totalresult3a2);

		$totalGross3a2 = $totaldata3a2['ertm']+$totaldata3a2['ertf'];

		$dataPoints3A2 = array(
			array("label" => "Slow", "y" => (($totaldata3a2['sstm']+$totaldata3a2['sstf'])/$totalGross3a2)*100),
			array("label" => "Average", "y" => (($totaldata3a2['satm']+$totaldata3a2['satf'])/$totalGross3a2)*100),
			array("label" => "Fast", "y" => (($totaldata3a2['sftm']+$totaldata3a2['sftf'])/$totalGross3a2)*100)
		);

			$dataPoints3A2a = array(
				array("label" => "Slow", "y" => ($totaldata3a2['sstm']/$totaldata3a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['satm']/$totaldata3a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['sftm']/$totaldata3a2['ertm'])*100)
			);

			$dataPoints3A2b = array(
				array("label" => "Slow", "y" => ($totaldata3a2['sstf']/$totaldata3a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['satf']/$totaldata3a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['sftf']/$totaldata3a2['ertf'])*100)
			);

		$dataPoints3B2 = array(
			array("label" => "Frustration", "y" => (($totaldata3a2['cfttm']+$totaldata3a2['cfttf'])/$totalGross3a2)*100),
			array("label" => "Instructional", "y" => (($totaldata3a2['cittm']+$totaldata3a2['cittf'])/$totalGross3a2)*100),
			array("label" => "Independent", "y" => (($totaldata3a2['cidtm']+$totaldata3a2['cidtf'])/$totalGross3a2)*100)
		);

			$dataPoints3B2a = array(
				array("label" => "Slow", "y" => ($totaldata3a2['cfttm']/$totaldata3a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['cittm']/$totaldata3a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['cidtm']/$totaldata3a2['ertm'])*100)
			);

			$dataPoints3B2b = array(
				array("label" => "Slow", "y" => ($totaldata3a2['cfttf']/$totaldata3a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['cittf']/$totaldata3a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['cidtf']/$totaldata3a2['ertf'])*100)
			);

		$dataPoints3C2 = array(
			array("label" => "Frustration", "y" => (($totaldata3a2['rlfttm']+$totaldata3a2['rlfttf'])/$totalGross3a2)*100),
			array("label" => "Instructional", "y" => (($totaldata3a2['rlittm']+$totaldata3a2['rlittf'])/$totalGross3a2)*100),
			array("label" => "Independent", "y" => (($totaldata3a2['rlidtm']+$totaldata3a2['rlidtf'])/$totalGross3a2)*100)
		);

			$dataPoints3C2a = array(
				array("label" => "Slow", "y" => ($totaldata3a2['rlfttm']/$totaldata3a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['rlittm']/$totaldata3a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['rlidtm']/$totaldata3a2['ertm'])*100)
			);

			$dataPoints3C2b = array(
				array("label" => "Slow", "y" => ($totaldata3a2['rlfttf']/$totaldata3a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata3a2['rlittf']/$totaldata3a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata3a2['rlidtf']/$totaldata3a2['ertf'])*100)
			);
	}
	else {
		$dataPoints3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints3C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade6
 	
 	$data4a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult4a = mysqli_query($conn3, $data4a);

	if (mysqli_num_rows($dataresult4a) > 0) {
		$total4a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult4a = mysqli_query($conn3, $total4a);
		$totaldata4a = mysqli_fetch_assoc($totalresult4a);

		$totalGross4a = $totaldata4a['ertm']+$totaldata4a['ertf'];

		$dataPoints4A = array(
			array("label" => "Slow", "y" => (($totaldata4a['sstm']+$totaldata4a['sstf'])/$totalGross4a)*100),
			array("label" => "Average", "y" => (($totaldata4a['satm']+$totaldata4a['satf'])/$totalGross4a)*100),
			array("label" => "Fast", "y" => (($totaldata4a['sftm']+$totaldata4a['sftf'])/$totalGross4a)*100)
		);

			$dataPoints4Aa = array(
				array("label" => "Slow", "y" => ($totaldata4a['sstm']/$totaldata4a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a['satm']/$totaldata4a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['sftm']/$totaldata4a['ertm'])*100)
			);

			$dataPoints4Ab = array(
				array("label" => "Slow", "y" => ($totaldata4a['sstf']/$totaldata4a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a['satf']/$totaldata4a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['sftf']/$totaldata4a['ertf'])*100)
			);

		$dataPoints4B = array(
			array("label" => "Frustration", "y" => (($totaldata4a['cfttm']+$totaldata4a['cfttf'])/$totalGross4a)*100),
			array("label" => "Instructional", "y" => (($totaldata4a['cittm']+$totaldata4a['cittf'])/$totalGross4a)*100),
			array("label" => "Independent", "y" => (($totaldata4a['cidtm']+$totaldata4a['cidtf'])/$totalGross4a)*100)
		);

			$dataPoints4Ba = array(
				array("label" => "Slow", "y" => ($totaldata4a['cfttm']/$totaldata4a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a['cittm']/$totaldata4a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['cidtm']/$totaldata4a['ertm'])*100)
			);

			$dataPoints4Bb = array(
				array("label" => "Slow", "y" => ($totaldata4a['cfttf']/$totaldata4a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a['cittf']/$totaldata4a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['cidtf']/$totaldata4a['ertf'])*100)
			);

		$dataPoints4C = array(
			array("label" => "Frustration", "y" => (($totaldata4a['rlfttm']+$totaldata4a['rlfttf'])/$totalGross4a)*100),
			array("label" => "Instructional", "y" => (($totaldata4a['rlittm']+$totaldata4a['rlittf'])/$totalGross4a)*100),
			array("label" => "Independent", "y" => (($totaldata4a['rlidtm']+$totaldata4a['rlidtf'])/$totalGross4a)*100)
		);

			$dataPoints4Ca = array(
				array("label" => "Slow", "y" => ($totaldata4a['rlfttm']/$totaldata4a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a['rlittm']/$totaldata4a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['rlidtm']/$totaldata4a['ertm'])*100)
			);

			$dataPoints4Cb = array(
				array("label" => "Slow", "y" => ($totaldata4a['rlfttf']/$totaldata4a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a['rlittf']/$totaldata4a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a['rlidtf']/$totaldata4a['ertf'])*100)
			);
	}
	else {
		$dataPoints4A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data4a2 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult4a2 = mysqli_query($conn3, $data4a2);

	if (mysqli_num_rows($dataresult4a2) > 0) {
		$total4a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' AND pORp = 'post'";
		$totalresult4a2 = mysqli_query($conn3, $total4a2);
		$totaldata4a2 = mysqli_fetch_assoc($totalresult4a2);

		$totalGross4a2 = $totaldata4a2['ertm']+$totaldata4a2['ertf'];

		$dataPoints4A2 = array(
			array("label" => "Slow", "y" => (($totaldata4a2['sstm']+$totaldata4a2['sstf'])/$totalGross4a2)*100),
			array("label" => "Average", "y" => (($totaldata4a2['satm']+$totaldata4a2['satf'])/$totalGross4a2)*100),
			array("label" => "Fast", "y" => (($totaldata4a2['sftm']+$totaldata4a2['sftf'])/$totalGross4a2)*100)
		);

			$dataPoints4A2a = array(
				array("label" => "Slow", "y" => ($totaldata4a2['sstm']/$totaldata4a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['satm']/$totaldata4a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['sftm']/$totaldata4a2['ertm'])*100)
			);

			$dataPoints4A2b = array(
				array("label" => "Slow", "y" => ($totaldata4a2['sstf']/$totaldata4a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['satf']/$totaldata4a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['sftf']/$totaldata4a2['ertf'])*100)
			);

		$dataPoints4B2 = array(
			array("label" => "Frustration", "y" => (($totaldata4a2['cfttm']+$totaldata4a2['cfttf'])/$totalGross4a2)*100),
			array("label" => "Instructional", "y" => (($totaldata4a2['cittm']+$totaldata4a2['cittf'])/$totalGross4a2)*100),
			array("label" => "Independent", "y" => (($totaldata4a2['cidtm']+$totaldata4a2['cidtf'])/$totalGross4a2)*100)
		);

			$dataPoints4B2a = array(
				array("label" => "Slow", "y" => ($totaldata4a2['cfttm']/$totaldata4a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['cittm']/$totaldata4a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['cidtm']/$totaldata4a2['ertm'])*100)
			);

			$dataPoints4B2b = array(
				array("label" => "Slow", "y" => ($totaldata4a2['cfttf']/$totaldata4a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['cittf']/$totaldata4a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['cidtf']/$totaldata4a2['ertf'])*100)
			);

		$dataPoints4C2 = array(
			array("label" => "Frustration", "y" => (($totaldata4a2['rlfttm']+$totaldata4a2['rlfttf'])/$totalGross4a2)*100),
			array("label" => "Instructional", "y" => (($totaldata4a2['rlittm']+$totaldata4a2['rlittf'])/$totalGross4a2)*100),
			array("label" => "Independent", "y" => (($totaldata4a2['rlidtm']+$totaldata4a2['rlidtf'])/$totalGross4a2)*100)
		);

			$dataPoints4C2a = array(
				array("label" => "Slow", "y" => ($totaldata4a2['rlfttm']/$totaldata4a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['rlittm']/$totaldata4a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['rlidtm']/$totaldata4a2['ertm'])*100)
			);

			$dataPoints4C2b = array(
				array("label" => "Slow", "y" => ($totaldata4a2['rlfttf']/$totaldata4a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata4a2['rlittf']/$totaldata4a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata4a2['rlidtf']/$totaldata4a2['ertf'])*100)
			);
	}
	else {
		$dataPoints4A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade7
 	
 	$data5a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult5a = mysqli_query($conn3, $data5a);

	if (mysqli_num_rows($dataresult5a) > 0) {
		$total5a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult5a = mysqli_query($conn3, $total5a);
		$totaldata5a = mysqli_fetch_assoc($totalresult5a);

		$totalGross5a = $totaldata5a['ertm']+$totaldata5a['ertf'];

		$dataPoints5A = array(
			array("label" => "Slow", "y" => (($totaldata5a['sstm']+$totaldata5a['sstf'])/$totalGross5a)*100),
			array("label" => "Average", "y" => (($totaldata5a['satm']+$totaldata5a['satf'])/$totalGross5a)*100),
			array("label" => "Fast", "y" => (($totaldata5a['sftm']+$totaldata5a['sftf'])/$totalGross5a)*100)
		);

			$dataPoints5Aa = array(
				array("label" => "Slow", "y" => ($totaldata5a['sstm']/$totaldata5a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a['satm']/$totaldata5a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['sftm']/$totaldata5a['ertm'])*100)
			);

			$dataPoints5Ab = array(
				array("label" => "Slow", "y" => ($totaldata5a['sstf']/$totaldata5a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a['satf']/$totaldata5a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['sftf']/$totaldata5a['ertf'])*100)
			);

		$dataPoints5B = array(
			array("label" => "Frustration", "y" => (($totaldata5a['cfttm']+$totaldata5a['cfttf'])/$totalGross5a)*100),
			array("label" => "Instructional", "y" => (($totaldata5a['cittm']+$totaldata5a['cittf'])/$totalGross5a)*100),
			array("label" => "Independent", "y" => (($totaldata5a['cidtm']+$totaldata5a['cidtf'])/$totalGross5a)*100)
		);

			$dataPoints5Ba = array(
				array("label" => "Slow", "y" => ($totaldata5a['cfttm']/$totaldata5a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a['cittm']/$totaldata5a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['cidtm']/$totaldata5a['ertm'])*100)
			);

			$dataPoints5Bb = array(
				array("label" => "Slow", "y" => ($totaldata5a['cfttf']/$totaldata5a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a['cittf']/$totaldata5a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['cidtf']/$totaldata5a['ertf'])*100)
			);

		$dataPoints5C = array(
			array("label" => "Frustration", "y" => (($totaldata5a['rlfttm']+$totaldata5a['rlfttf'])/$totalGross5a)*100),
			array("label" => "Instructional", "y" => (($totaldata5a['rlittm']+$totaldata5a['rlittf'])/$totalGross5a)*100),
			array("label" => "Independent", "y" => (($totaldata5a['rlidtm']+$totaldata5a['rlidtf'])/$totalGross5a)*100)
		);

			$dataPoints5Ca = array(
				array("label" => "Slow", "y" => ($totaldata5a['rlfttm']/$totaldata5a['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a['rlittm']/$totaldata5a['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['rlidtm']/$totaldata5a['ertm'])*100)
			);

			$dataPoints5Cb = array(
				array("label" => "Slow", "y" => ($totaldata5a['rlfttf']/$totaldata5a['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a['rlittf']/$totaldata5a['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a['rlidtf']/$totaldata5a['ertf'])*100)
			);
	}
	else {
		$dataPoints5A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data5a2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult5a2 = mysqli_query($conn3, $data5a2);

	if (mysqli_num_rows($dataresult5a2) > 0) {
		$total5a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' AND pORp = 'post'";
		$totalresult5a2 = mysqli_query($conn3, $total5a2);
		$totaldata5a2 = mysqli_fetch_assoc($totalresult5a2);

		$totalGross5a2 = $totaldata5a2['ertm']+$totaldata5a2['ertf'];

		$dataPoints5A2 = array(
			array("label" => "Slow", "y" => (($totaldata5a2['sstm']+$totaldata5a2['sstf'])/$totalGross5a2)*100),
			array("label" => "Average", "y" => (($totaldata5a2['satm']+$totaldata5a2['satf'])/$totalGross5a2)*100),
			array("label" => "Fast", "y" => (($totaldata5a2['sftm']+$totaldata5a2['sftf'])/$totalGross5a2)*100)
		);

			$dataPoints5A2a = array(
				array("label" => "Slow", "y" => ($totaldata5a2['sstm']/$totaldata5a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['satm']/$totaldata5a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['sftm']/$totaldata5a2['ertm'])*100)
			);

			$dataPoints5A2b = array(
				array("label" => "Slow", "y" => ($totaldata5a2['sstf']/$totaldata5a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['satf']/$totaldata5a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['sftf']/$totaldata5a2['ertf'])*100)
			);

		$dataPoints5B2 = array(
			array("label" => "Frustration", "y" => (($totaldata5a2['cfttm']+$totaldata5a2['cfttf'])/$totalGross5a2)*100),
			array("label" => "Instructional", "y" => (($totaldata5a2['cittm']+$totaldata5a2['cittf'])/$totalGross5a2)*100),
			array("label" => "Independent", "y" => (($totaldata5a2['cidtm']+$totaldata5a2['cidtf'])/$totalGross5a2)*100)
		);

			$dataPoints5B2a = array(
				array("label" => "Slow", "y" => ($totaldata5a2['cfttm']/$totaldata5a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['cittm']/$totaldata5a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['cidtm']/$totaldata5a2['ertm'])*100)
			);

			$dataPoints5B2b = array(
				array("label" => "Slow", "y" => ($totaldata5a2['cfttf']/$totaldata5a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['cittf']/$totaldata5a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['cidtf']/$totaldata5a2['ertf'])*100)
			);

		$dataPoints5C2 = array(
			array("label" => "Frustration", "y" => (($totaldata5a2['rlfttm']+$totaldata5a2['rlfttf'])/$totalGross5a2)*100),
			array("label" => "Instructional", "y" => (($totaldata5a2['rlittm']+$totaldata5a2['rlittf'])/$totalGross5a2)*100),
			array("label" => "Independent", "y" => (($totaldata5a2['rlidtm']+$totaldata5a2['rlidtf'])/$totalGross5a2)*100)
		);

			$dataPoints5C2a = array(
				array("label" => "Slow", "y" => ($totaldata5a2['rlfttm']/$totaldata5a2['ertm'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['rlittm']/$totaldata5a2['ertm'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['rlidtm']/$totaldata5a2['ertm'])*100)
			);

			$dataPoints5C2b = array(
				array("label" => "Slow", "y" => ($totaldata5a2['rlfttf']/$totaldata5a2['ertf'])*100),
				array("label" => "Average", "y" => ($totaldata5a2['rlittf']/$totaldata5a2['ertf'])*100),
				array("label" => "Fast", "y" => ($totaldata5a2['rlidtf']/$totaldata5a2['ertf'])*100)
			);
	}
	else {
		$dataPoints5A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints5C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

?>