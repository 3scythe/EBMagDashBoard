<?php
	$tb1 = "SELECT * FROM philirioral WHERE School = '$School' AND Grade = 5 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year ASC";
    $tbresult = mysqli_query($conn3,$tb1);

    $tblpre1 = "SELECT * FROM philirioral WHERE pORp = 'pre' AND School = '$School' AND Grade = 5 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year";
    $tblpost1 = "SELECT * FROM philirioral WHERE pORp = 'post' AND School = '$School' AND Grade = 5 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year";
    $tblpre = mysqli_query($conn3, $tblpre1);
    $tblpost = mysqli_query($conn3, $tblpost1);

    $tblnum1 = "SELECT count(*) AS ttldata FROM philirioral WHERE School = '$School' AND Grade = 5 AND subject = 'Filipino' And Year <= '$chosenTime2' GROUP BY pORp";
    $tblnum = mysqli_query($conn3, $tblnum1);
    $tblnm = mysqli_fetch_array($tblnum);

	$tnr = mysqli_num_rows($tbresult);

	  echo " <table border='1' width='100%' id=\"myTableFO5\">
	              <tr>
	                <td colspan=\"2\">School</td>
	                <td colspan=\"6\">Enrolment</td><td colspan=\"6\">PUPIL TESTED</td><td colspan=\"6\">FRUSTRATION</td>
	                <td colspan=\"6\">INSTRUCTIONAL</td><td colspan=\"6\">INDEPENDENT</td><td colspan=\"6\">NON-READER</td>
	              </tr>
	              <tr>
	                <td colspan=\"2\"> </td>
	                <td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td>
	                <td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td>
	                <td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td>
	              </tr>
	              <tr>
	                <td colspan=\"2\"></td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	              </tr>
	              <tr>";
	  if ($tnr > 0) {
	  	for ($tbl=0; $tbl < $tblnm['ttldata']; $tbl++){ 
			$tblrow = mysqli_fetch_array($tbresult);
			$tblrow2 = mysqli_fetch_array($tblpre);
			$tblrow3 = mysqli_fetch_array($tblpost);
			  echo "<td colspan=\"2\">".$tblrow['Year']+$tbl."</td>
			        <td>".$tblrow2['ermale']."</td>
			        <td>".$tblrow2['erfemale']."</td>
			        <td>".$tblrow2['ermale']+$tblrow2['erfemale']."</td>
			        <td>".$tblrow3['ermale']."</td>
			        <td>".$tblrow3['erfemale']."</td>
			        <td>".$tblrow3['ermale']+$tblrow3['erfemale']."</td>

			        <td>".$tblrow2['ptmale']."</td>
			        <td>".$tblrow2['ptfemale']."</td>
			        <td>".$tblrow2['ptmale']+$tblrow2['ptfemale']."</td>
			        <td>".$tblrow3['ptmale']."</td>
			        <td>".$tblrow3['ptfemale']."</td>
			        <td>".$tblrow3['ptmale']+$tblrow3['ptfemale']."</td>

			        <td>".$tblrow2['ftmale']."</td>
			        <td>".$tblrow2['ftfemale']."</td>
			        <td>".$tblrow2['ftmale']+$tblrow2['ftfemale']."</td>
			        <td>".$tblrow3['ftmale']."</td>
			        <td>".$tblrow3['ftfemale']."</td>
			        <td>".$tblrow3['ftmale']+$tblrow3['ftfemale']."</td>

			        <td>".$tblrow2['itmale']."</td>
			        <td>".$tblrow2['itfemale']."</td>
			        <td>".$tblrow2['itmale']+$tblrow2['itfemale']."</td>
			        <td>".$tblrow3['itmale']."</td>
			        <td>".$tblrow3['itfemale']."</td>
			        <td>".$tblrow3['itmale']+$tblrow3['itfemale']."</td>

			        <td>".$tblrow2['idmale']."</td>
			        <td>".$tblrow2['idfemale']."</td>
			        <td>".$tblrow2['idmale']+$tblrow2['idfemale']."</td>
			        <td>".$tblrow3['idmale']."</td>
			        <td>".$tblrow3['idfemale']."</td>
			        <td>".$tblrow3['idmale']+$tblrow3['idfemale']."</td>

			        <td>".$tblrow2['nrmale']."</td>
			        <td>".$tblrow2['nrfemale']."</td>
			        <td>".$tblrow2['nrmale']+$tblrow2['nrfemale']."</td>
			        <td>".$tblrow3['nrmale']."</td>
			        <td>".$tblrow3['nrfemale']."</td>
			        <td>".$tblrow3['nrmale']+$tblrow3['nrfemale']."</td>";
		  echo "</tr>";
		}
	  }
	  echo "</table>";
?>