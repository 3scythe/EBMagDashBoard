<?php
include "connect.php";

if(isset($_POST['adlogin2'])){

    $uname = mysqli_real_escape_string($conn,$_POST['UserID2']);
    $password = mysqli_real_escape_string($conn,$_POST['UserPass2']);
    $lvl = mysqli_real_escape_string($conn,$_POST['lvl']);


    if ($uname != "" && $password != ""){

        if ($lvl == "Elementary") {
            $tabName = "elemadmin";
        }
        elseif ($lvl == "High School") {
            $tabName = "highdmin";
        }
        elseif ($lvl == "Private") {
            $tabName = "pridmin";
        }

        $sql_query = "SELECT * FROM `{$tabName}` WHERE username ='$uname' AND passcode ='$password'";
        $result = mysqli_query($conn2, $sql_query);
        $cntUser = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);

        if($cntUser > 0){
            session_start();
            $_SESSION['usename'] = $row['username'];
            $_SESSION['usepass'] = $row['passcode'];
            $_SESSION['fname'] = $row['first_name'];
            $_SESSION['midname'] = $row['middle_name'];
            $_SESSION['lastname'] = $row['last_name'];
            $_SESSION['School'] = $row['school'];
            $_SESSION['myposition'] = $row['position'];
            $_SESSION['mygender'] = $row['gender'];

            $schl = $row['school'];

            $minnG = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminG = mysqli_query($conn3, $minnG);
            $maxxG = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxG = mysqli_query($conn3, $maxxG);

            $minnEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminEO = mysqli_query($conn3, $minnEO);
            $maxxEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxEO = mysqli_query($conn3, $maxxEO);

            $minnFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminFO = mysqli_query($conn3, $minnFO);
            $maxxFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxFO = mysqli_query($conn3, $maxxFO);

            $minnES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminES = mysqli_query($conn3, $minnES);
            $maxxES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxES = mysqli_query($conn3, $maxxES);

            $minnFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminFS = mysqli_query($conn3, $minnFS);
            $maxxFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxFS = mysqli_query($conn3, $maxxFS);

            $minnNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultminNS = mysqli_query($conn3, $minnNS);
            $maxxNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmaxNS = mysqli_query($conn3, $maxxNS);

            $minn4p = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
            $resultmin4p = mysqli_query($conn3, $minn4p);
            $maxx4p = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
            $resultmax4p = mysqli_query($conn3, $maxx4p);

            session_start();

            if (mysqli_num_rows($resultmaxG) > 0) {
                $rowsminG = mysqli_fetch_assoc($resultminG);
                $rowsG = mysqli_fetch_assoc($resultmaxG);

                $_SESSION['timeMinG'] = $rowsminG['Year'];
                $_SESSION['timeMaxG'] = $rowsG['Year'];
            }
            else{
               $_SESSION['timeMinG'] = "none";
               $_SESSION['timeMaxG'] = "none";
            }

            if (mysqli_num_rows($resultmaxEO) > 0) {
                $rowsminEO = mysqli_fetch_assoc($resultminEO);
                $rowsEO = mysqli_fetch_assoc($resultmaxEO);

                $_SESSION['timeMinEO'] = $rowsminEO['Year'];;
                $_SESSION['timeMaxEO'] = $rowsEO['Year'];;
            }
            else{
               $_SESSION['timeMinEO'] = "none";
               $_SESSION['timeMaxEO'] = "none";
            }

            if (mysqli_num_rows($resultmaxFO) > 0) {
                $rowsminFO = mysqli_fetch_assoc($resultminFO);
                $rowsFO = mysqli_fetch_assoc($resultmaxFO);

                $_SESSION['timeMinFO'] = $rowsminFO['Year'];;
                $_SESSION['timeMaxFO'] = $rowsFO['Year'];;
            }
            else{
               $_SESSION['timeMinFO'] = "none";
               $_SESSION['timeMaxFO'] = "none";
            }

            if (mysqli_num_rows($resultmaxES) > 0) {
                $rowsminES = mysqli_fetch_assoc($resultminES);
                $rowsES = mysqli_fetch_assoc($resultmaxES);

                $_SESSION['timeMinES'] = $rowsminES['Year'];
                $_SESSION['timeMaxES'] = $rowsES['Year'];
            }
            else{
               $_SESSION['timeMinES'] = "none";
               $_SESSION['timeMaxES'] = "none";
            }

            if (mysqli_num_rows($resultmaxFS) > 0) {
                $rowsminFS = mysqli_fetch_assoc($resultminFS);
                $rowsFS = mysqli_fetch_assoc($resultmaxFS);

                $_SESSION['timeMinFS'] = $rowsminFS['Year'];
                $_SESSION['timeMaxFS'] = $rowsFS['Year'];
            }
            else{
               $_SESSION['timeMinFS'] = "none";
               $_SESSION['timeMaxFS'] = "none";
            }

            if (mysqli_num_rows($resultmaxNS) > 0) {
                $rowsminNS = mysqli_fetch_assoc($resultminNS);
                $rowsNS = mysqli_fetch_assoc($resultmaxNS);

                $_SESSION['timeMinNS'] = $rowsminNS['Year'];
                $_SESSION['timeMaxNS'] = $rowsNS['Year'];
            }
            else{
               $_SESSION['timeMinNS'] = "none";
               $_SESSION['timeMaxNS'] = "none";
            }  

            if (mysqli_num_rows($resultmax4p) > 0) {
                $rowsmin4p = mysqli_fetch_assoc($resultmin4p);
                $rows4p = mysqli_fetch_assoc($resultmax4p);

                $_SESSION['timeMin4p'] = $rowsmin4p['Year'];
                $_SESSION['timeMax4p'] = $rows4p['Year'];
            }
            else{
               $_SESSION['timeMin4p'] = "none";
               $_SESSION['timeMax4p'] = "none";
            } 

            $_SESSION['display'] = "none";

            if ($lvl == "Elementary") {
                header('Location: ../ElemSchoolD.php');
            }
            elseif ($lvl == "High School") {
                header('Location: ../HighSchoolD.php');
            }
            elseif ($lvl == "Private") {
                header('Location: ../PriSchoolD.php');
            }
        }else{
        	header('Location: ../index.php?error=invalid&user&or&password');
        }
    }
    else{
    	header('Location: ../index.php?error=missingfields');
    }

}