<?php
	include "connect.php";

	//Bar Chart

	//Elementary
	$data1c1 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary' AND Year <= '$max' GROUP BY Year";
	$dataresult1c1 = mysqli_query($conn3, $data1c1);


	if (mysqli_num_rows($dataresult1c1)>0) {
		$getNSchool = "SELECT * FROM `{$tabName}` Where Groups = '$es' Group BY School";
		$getNSres = mysqli_query($conn3 ,$getNSchool);
		$SNR = mysqli_num_rows($getNSres);

		$dataPoints1C1 = array();
		while($dataPoint1c1 = mysqli_fetch_array($dataresult1c1)) {   
		  array_push($dataPoints1C1, array("y" => round(($dataPoint1c1['m']+$dataPoint1c1['f'])/($SNR*2),1), "label" => $dataPoint1c1['Year']));
		}

		$data1c2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary' AND Year <= '$max' GROUP BY Year";
		$dataresult1c2 = mysqli_query($conn3, $data1c2);

		$dataPoints1C2 = array();
		while($dataPoint1c2 = mysqli_fetch_array($dataresult1c2)) {   
		  array_push($dataPoints1C2, array("y" => round($dataPoint1c2['m']/$SNR,1), "label" => $dataPoint1c2['Year']));
		}

		$data1c3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary'AND Year <= '$max'  GROUP BY Year";
		$dataresult1c3 = mysqli_query($conn3, $data1c3);

		$dataPoints1C3 = array();
		while($dataPoint1c3 = mysqli_fetch_array($dataresult1c3)) {   
		  array_push($dataPoints1C3, array("y" => round($dataPoint1c3['f']/$SNR,1), "label" => $dataPoint1c3['Year']));
		}
	}
	else {
		$dataPoints1C1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

		

	//HighSchool

	$data1c1h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
	$dataresult1c1h = mysqli_query($conn3, $data1c1h);

	if (mysqli_num_rows($dataresult1c1h) > 0) {

		$getNSchoolh = "SELECT * FROM `{$tabName}` Where Groups = '$hs' Group BY School";
		$getNSresh = mysqli_query($conn3 ,$getNSchoolh);
		$SNRh = mysqli_num_rows($getNSresh);

		$dataPoints1C1h = array();
		while($dataPoint1c1h = mysqli_fetch_array($dataresult1c1h)) {   
		  array_push($dataPoints1C1h, array("y" => round(($dataPoint1c1h['m']+$dataPoint1c1h['f'])/($SNRh*2),1), "label" => $dataPoint1c1h['Year']));
		}

		$data1c2h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
		$dataresult1c2h = mysqli_query($conn3, $data1c2h);

		$dataPoints1C2h = array();
		while($dataPoint1c2h = mysqli_fetch_array($dataresult1c2h)) {   
		  array_push($dataPoints1C2h, array("y" => round($dataPoint1c2h['m']/$SNRh,1), "label" => $dataPoint1c2h['Year']));
		}

		$data1c3h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
		$dataresult1c3h = mysqli_query($conn3, $data1c3h);

		$dataPoints1C3h = array();
		while($dataPoint1c3h = mysqli_fetch_array($dataresult1c3h)) {   
		  array_push($dataPoints1C3h, array("y" => round($dataPoint1c3h['f']/$SNRh,1), "label" => $dataPoint1c3h['Year']));
		}
	}
	else{
		$dataPoints1C1h = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2h = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3h = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	//Ptivate

	$data1c1p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
	$dataresult1c1p = mysqli_query($conn3, $data1c1p);

	if (mysqli_num_rows($dataresult1c1p) > 0 ) {

		$getNSchoolp = "SELECT * FROM `{$tabName}` Where Groups = '$ps' Group BY School";
		$getNSresp = mysqli_query($conn3 ,$getNSchoolp);
		$SNRp = mysqli_num_rows($getNSresp);

		$dataPoints1C1p = array();
		while($dataPoint1c1p = mysqli_fetch_array($dataresult1c1p)) {   
		  array_push($dataPoints1C1p, array("y" => round(($dataPoint1c1p['m']+$dataPoint1c1p['f'])/($SNRp*2),2), "label" => $dataPoint1c1p['Year']));
		}

		$data1c2p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
		$dataresult1c2p = mysqli_query($conn3, $data1c2p);

		$dataPoints1C2p = array();
		while($dataPoint1c2p = mysqli_fetch_array($dataresult1c2p)) {   
		  array_push($dataPoints1C2p, array("y" => round($dataPoint1c2p['m']/$SNRp,1), "label" => $dataPoint1c2p['Year']));
		}

		$data1c3p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
		$dataresult1c3p = mysqli_query($conn3, $data1c3p);

		$dataPoints1C3p = array();
		while($dataPoint1c3p = mysqli_fetch_array($dataresult1c3p)) {   
		  array_push($dataPoints1C3p, array("y" => round($dataPoint1c3p['f']/$SNRp,1), "label" => $dataPoint1c3p['Year']));
		}
	}
	else{
		$dataPoints1C1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3p = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
?>