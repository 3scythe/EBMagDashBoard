<?php

include "connect.php";

//Individual
	if(isset($_POST['ESPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../ElemSchoolD.php');
	}
	elseif(isset($_POST['ESPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../ElemSchoolD.php');
	}
	elseif(isset($_POST['ESNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../ElemSchoolD.php');
	}
	elseif(isset($_POST['ES4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../ElemSchoolD.php');
	}
//High
	if(isset($_POST['HSPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../HighSchoolD.php');
	}
	elseif(isset($_POST['HSPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../HighSchoolD.php');
	}
	elseif(isset($_POST['HSNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../HighSchoolD.php');
	}
	elseif(isset($_POST['HS4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../HighSchoolD.php');
	}
//Pri
	if(isset($_POST['PSPI'])){
		
		session_start();
		
		$_SESSION['display'] = "Page1";
		$_SESSION['theTime'] = $_POST['time1'];
		header('Location: ../PriSchoolD.php');
	}
	elseif(isset($_POST['PSPHilIRi'])){
		
		session_start();
		
		$_SESSION['display'] = "Page2";
		$_SESSION['theTime2'] = $_POST['time1'];
		header('Location: ../PriSchoolD.php');
	}
	elseif(isset($_POST['PSNutri'])){
		
		session_start();
		
		$_SESSION['display'] = "Page3";
		$_SESSION['theTime3'] = $_POST['time1'];
		header('Location: ../PriSchoolD.php');
	}
	elseif(isset($_POST['PS4Ps'])){
		
		session_start();
		
		$_SESSION['display'] = "Page4";
		$_SESSION['theTime4'] = $_POST['time1'];
		header('Location: ../PriSchoolD.php');
	}

?>