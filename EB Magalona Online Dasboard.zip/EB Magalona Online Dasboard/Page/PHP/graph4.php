<?php
	include "connect.php";

//Grade3
 	$data1a = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1a = mysqli_query($conn3, $data1a);

	if (mysqli_num_rows($dataresult1a) > 0) {
		$total1a = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1a = mysqli_query($conn3, $total1a);
		$totaldata1a = mysqli_fetch_assoc($totalresult1a);

		$totalGross1a = $totaldata1a['ertm']+$totaldata1a['ertf'];

		$dataPoints1A = array(
			array("label" => "Frustration", "y" => (($totaldata1a['fttm']+$totaldata1a['fttf'])/$totalGross1a)*100),
			array("label" => "Instructional", "y" => (($totaldata1a['ittm']+$totaldata1a['ittf'])/$totalGross1a)*100),
			array("label" => "Idependent", "y" => (($totaldata1a['idtm']+$totaldata1a['idtf'])/$totalGross1a)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1a['nrtm']+$totaldata1a['nrtf'])/$totalGross1a)*100)
		);

		$dataPoints1Aa = array(
			array("label" => "Frustration", "y" => ($totaldata1a['fttm']/$totaldata1a['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1a['ittm']/$totaldata1a['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1a['idtm']/$totaldata1a['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1a['nrtm']/$totaldata1a['ertm'])*100)
		);

		$dataPoints1Ab = array(
			array("label" => "Frustration", "y" => ($totaldata1a['fttf']/$totaldata1a['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1a['ittf']/$totaldata1a['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1a['idtf']/$totaldata1a['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1a['nrtf']/$totaldata1a['ertf'])*100)
		);
	}
	else{
		$dataPoints1A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1a2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1a2 = mysqli_query($conn3, $data1a2);

	if (mysqli_num_rows($dataresult1a2) > 0) {
		$total1a2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1a2 = mysqli_query($conn3, $total1a2);
		$totaldata1a2 = mysqli_fetch_assoc($totalresult1a2);

		$totalGross1a2 = $totaldata1a2['ertm']+$totaldata1a2['ertf'];

		$dataPoints1A2 = array(
			array("label" => "Frustration", "y" => (($totaldata1a2['fttm']+$totaldata1a2['fttf'])/$totalGross1a2)*100),
			array("label" => "Instructional", "y" => (($totaldata1a2['ittm']+$totaldata1a2['ittf'])/$totalGross1a2)*100),
			array("label" => "Idependent", "y" => (($totaldata1a2['idtm']+$totaldata1a2['idtf'])/$totalGross1a2)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1a2['nrtm']+$totaldata1a2['nrtf'])/$totalGross1a2)*100)
		);

		$dataPoints1A2a = array(
			array("label" => "Frustration", "y" => ($totaldata1a2['fttm']/$totaldata1a2['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1a2['ittm']/$totaldata1a2['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1a2['idtm']/$totaldata1a2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1a2['nrtm']/$totaldata1a2['ertm'])*100)
		);

		$dataPoints1A2b = array(
			array("label" => "Frustration", "y" => ($totaldata1a2['fttf']/$totaldata1a2['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1a2['ittf']/$totaldata1a2['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1a2['idtf']/$totaldata1a2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1a2['nrtf']/$totaldata1a2['ertf'])*100)
		);
	}
	else{
		$dataPoints1A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1A2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1A2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade4	
	$data1b = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1b = mysqli_query($conn3, $data1b);

	if (mysqli_num_rows($dataresult1b) > 0) {
		$total1b = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1b = mysqli_query($conn3, $total1b);
		$totaldata1b = mysqli_fetch_assoc($totalresult1b);

		$totalGross1b = $totaldata1b['ertm']+$totaldata1b['ertf'];

		$dataPoints1B = array(
			array("label" => "Frustration", "y" => (($totaldata1b['fttm']+$totaldata1b['fttf'])/$totalGross1b)*100),
			array("label" => "Instructional", "y" => (($totaldata1b['ittm']+$totaldata1b['ittf'])/$totalGross1b)*100),
			array("label" => "Idependent", "y" => (($totaldata1b['idtm']+$totaldata1b['idtf'])/$totalGross1b)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1b['nrtm']+$totaldata1b['nrtf'])/$totalGross1b)*100)
		);

		$dataPoints1Ba = array(
			array("label" => "Frustration", "y" => ($totaldata1b['fttm']/$totaldata1b['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1b['ittm']/$totaldata1b['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1b['idtm']/$totaldata1b['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1b['nrtm']/$totaldata1b['ertm'])*100)
		);

		$dataPoints1Bb = array(
			array("label" => "Frustration", "y" => ($totaldata1b['fttf']/$totaldata1b['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1b['ittf']/$totaldata1b['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1b['idtf']/$totaldata1b['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1b['nrtf']/$totaldata1b['ertf'])*100)
		);
	}
	else{
		$dataPoints1B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1b2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1b2 = mysqli_query($conn3, $data1b2);

	if (mysqli_num_rows($dataresult1b2) > 0) {
		$total1b2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1b2 = mysqli_query($conn3, $total1b2);
		$totaldata1b2 = mysqli_fetch_assoc($totalresult1b2);

		$totalGross1b2 = $totaldata1b2['ertm']+$totaldata1b2['ertf'];

		$dataPoints1B2 = array(
			array("label" => "Frustration", "y" => (($totaldata1b2['fttm']+$totaldata1b2['fttf'])/$totalGross1b2)*100),
			array("label" => "Instructional", "y" => (($totaldata1b2['ittm']+$totaldata1b2['ittf'])/$totalGross1b2)*100),
			array("label" => "Idependent", "y" => (($totaldata1b2['idtm']+$totaldata1b2['idtf'])/$totalGross1b2)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1b2['nrtm']+$totaldata1b2['nrtf'])/$totalGross1b2)*100)
		);

		$dataPoints1B2a = array(
			array("label" => "Frustration", "y" => ($totaldata1b2['fttm']/$totaldata1b2['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1b2['ittm']/$totaldata1b2['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1b2['idtm']/$totaldata1b2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1b2['nrtm']/$totaldata1b2['ertm'])*100)
		);

		$dataPoints1B2b = array(
			array("label" => "Frustration", "y" => ($totaldata1b2['fttf']/$totaldata1b2['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1b2['ittf']/$totaldata1b2['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1b2['idtf']/$totaldata1b2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1b2['nrtf']/$totaldata1b2['ertf'])*100)
		);
	}
	else{
		$dataPoints1B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade5	
	$data1c = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1c = mysqli_query($conn3, $data1c);

	if (mysqli_num_rows($dataresult1c) > 0) {
		$total1c = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1c = mysqli_query($conn3, $total1c);
		$totaldata1c = mysqli_fetch_assoc($totalresult1c);

		$totalGross1c = $totaldata1c['ertm']+$totaldata1c['ertf'];

		$dataPoints1C = array(
			array("label" => "Frustration", "y" => (($totaldata1c['fttm']+$totaldata1c['fttf'])/$totalGross1c)*100),
			array("label" => "Instructional", "y" => (($totaldata1c['ittm']+$totaldata1c['ittf'])/$totalGross1c)*100),
			array("label" => "Idependent", "y" => (($totaldata1c['idtm']+$totaldata1c['idtf'])/$totalGross1c)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1c['nrtm']+$totaldata1c['nrtf'])/$totalGross1c)*100)
		);

		$dataPoints1Ca = array(
			array("label" => "Frustration", "y" => ($totaldata1c['fttm']/$totaldata1c['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1c['ittm']/$totaldata1c['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1c['idtm']/$totaldata1c['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1c['nrtm']/$totaldata1c['ertm'])*100)
		);

		$dataPoints1Cb = array(
			array("label" => "Frustration", "y" => ($totaldata1c['fttf']/$totaldata1c['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1c['ittf']/$totaldata1c['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1c['idtf']/$totaldata1c['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1c['nrtf']/$totaldata1c['ertf'])*100)
		);
	}
	else{
		$dataPoints1C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1c2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1c2 = mysqli_query($conn3, $data1c2);

	if (mysqli_num_rows($dataresult1c2) > 0) {
		$total1c2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1c2 = mysqli_query($conn3, $total1c2);
		$totaldata1c2 = mysqli_fetch_assoc($totalresult1c2);

		$totalGross1c2 = $totaldata1c2['ertm']+$totaldata1c2['ertf'];

		$dataPoints1C2 = array(
			array("label" => "Frustration", "y" => (($totaldata1c2['fttm']+$totaldata1c2['fttf'])/$totalGross1c2)*100),
			array("label" => "Instructional", "y" => (($totaldata1c2['ittm']+$totaldata1c2['ittf'])/$totalGross1c2)*100),
			array("label" => "Idependent", "y" => (($totaldata1c2['idtm']+$totaldata1c2['idtf'])/$totalGross1c2)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1c2['nrtm']+$totaldata1c2['nrtf'])/$totalGross1c2)*100)
		);

		$dataPoints1C2a = array(
			array("label" => "Frustration", "y" => ($totaldata1c2['fttm']/$totaldata1c2['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1c2['ittm']/$totaldata1c2['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1c2['idtm']/$totaldata1c2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1c2['nrtm']/$totaldata1c2['ertm'])*100)
		);

		$dataPoints1C2b = array(
			array("label" => "Frustration", "y" => ($totaldata1c2['fttf']/$totaldata1c2['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1c2['ittf']/$totaldata1c2['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1c2['idtf']/$totaldata1c2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1c2['nrtf']/$totaldata1c2['ertf'])*100)
		);
	}
	else{
		$dataPoints1C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade6	
	$data1d = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1d = mysqli_query($conn3, $data1d);

	if (mysqli_num_rows($dataresult1d) > 0) {
		$total1d = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1d = mysqli_query($conn3, $total1d);
		$totaldata1d = mysqli_fetch_assoc($totalresult1d);

		$totalGross1d = $totaldata1d['ertm']+$totaldata1d['ertf'];

		$dataPoints1D = array(
			array("label" => "Frustration", "y" => (($totaldata1d['fttm']+$totaldata1d['fttf'])/$totalGross1d)*100),
			array("label" => "Instructional", "y" => (($totaldata1d['ittm']+$totaldata1d['ittf'])/$totalGross1d)*100),
			array("label" => "Idependent", "y" => (($totaldata1d['idtm']+$totaldata1d['idtf'])/$totalGross1d)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1d['nrtm']+$totaldata1d['nrtf'])/$totalGross1d)*100)
		);

		$dataPoints1Da = array(
			array("label" => "Frustration", "y" => ($totaldata1d['fttm']/$totaldata1d['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1d['ittm']/$totaldata1d['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1d['idtm']/$totaldata1d['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1d['nrtm']/$totaldata1d['ertm'])*100)
		);

		$dataPoints1Db = array(
			array("label" => "Frustration", "y" => ($totaldata1d['fttf']/$totaldata1d['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1d['ittf']/$totaldata1d['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1d['idtf']/$totaldata1d['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1d['nrtf']/$totaldata1d['ertf'])*100)
		);
	}
	else{
		$dataPoints1D = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Da = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Db = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1d2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 6 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1d2 = mysqli_query($conn3, $data1d2);

	if (mysqli_num_rows($dataresult1d2) > 0) {
		$total1d2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 6 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1d2 = mysqli_query($conn3, $total1d2);
		$totaldata1d2 = mysqli_fetch_assoc($totalresult1d2);

		$totalGross1d2 = $totaldata1d2['ertm']+$totaldata1d2['ertf'];

		$dataPoints1D2 = array(
			array("label" => "Frustration", "y" => (($totaldata1d2['fttm']+$totaldata1d2['fttf'])/$totalGross1d2)*100),
			array("label" => "Instructional", "y" => (($totaldata1d2['ittm']+$totaldata1d2['ittf'])/$totalGross1d2)*100),
			array("label" => "Idependent", "y" => (($totaldata1d2['idtm']+$totaldata1d2['idtf'])/$totalGross1d2)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1d2['nrtm']+$totaldata1d2['nrtf'])/$totalGross1d2)*100)
		);

		$dataPoints1D2a = array(
			array("label" => "Frustration", "y" => ($totaldata1d2['fttm']/$totaldata1d2['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1d2['ittm']/$totaldata1d2['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1d2['idtm']/$totaldata1d2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1d2['nrtm']/$totaldata1d2['ertm'])*100)
		);

		$dataPoints1D2b = array(
			array("label" => "Frustration", "y" => ($totaldata1d2['fttf']/$totaldata1d2['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1d2['ittf']/$totaldata1d2['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1d2['idtf']/$totaldata1d2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1d2['nrtf']/$totaldata1d2['ertf'])*100)
		);
	}
	else{
		$dataPoints1D2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1D2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1D2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Grade7	
	$data1e = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' AND pORp = 'pre' ORDER BY School";
	$dataresult1e = mysqli_query($conn3, $data1e);

	if (mysqli_num_rows($dataresult1e) > 0) {
		$total1e = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' AND pORp = 'pre'";
		$totalresult1e = mysqli_query($conn3, $total1e);
		$totaldata1e = mysqli_fetch_assoc($totalresult1e);

		$totalGross1e = $totaldata1e['ertm']+$totaldata1e['ertf'];

		$dataPoints1E = array(
			array("label" => "Frustration", "y" => (($totaldata1e['fttm']+$totaldata1e['fttf'])/$totalGross1e)*100),
			array("label" => "Instructional", "y" => (($totaldata1e['ittm']+$totaldata1e['ittf'])/$totalGross1e)*100),
			array("label" => "Idependent", "y" => (($totaldata1e['idtm']+$totaldata1e['idtf'])/$totalGross1e)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1e['nrtm']+$totaldata1e['nrtf'])/$totalGross1e)*100)
		);

		$dataPoints1Ea = array(
			array("label" => "Frustration", "y" => ($totaldata1e['fttm']/$totaldata1e['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1e['ittm']/$totaldata1e['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1e['idtm']/$totaldata1e['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1e['nrtm']/$totaldata1e['ertm'])*100)
		);

		$dataPoints1Eb = array(
			array("label" => "Frustration", "y" => ($totaldata1e['fttf']/$totaldata1e['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1e['ittf']/$totaldata1e['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1e['idtf']/$totaldata1e['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1e['nrtf']/$totaldata1e['ertf'])*100)
		);
	}
	else{
		$dataPoints1E = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ea = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Eb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$data1e2 = "SELECT  * FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' AND pORp = 'post' ORDER BY School";
	$dataresult1e2 = mysqli_query($conn3, $data1e2);

	if (mysqli_num_rows($dataresult1e2) > 0) {
		$total1e2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' AND pORp = 'post'";
		$totalresult1e2 = mysqli_query($conn3, $total1e2);
		$totaldata1e2 = mysqli_fetch_assoc($totalresult1e2);

		$totalGross1e2 = $totaldata1e2['ertm']+$totaldata1e2['ertf'];

		$dataPoints1E2 = array(
			array("label" => "Frustration", "y" => (($totaldata1e2['fttm']+$totaldata1e2['fttf'])/$totalGross1e2)*100),
			array("label" => "Instructional", "y" => (($totaldata1e2['ittm']+$totaldata1e2['ittf'])/$totalGross1e2)*100),
			array("label" => "Idependent", "y" => (($totaldata1e2['idtm']+$totaldata1e2['idtf'])/$totalGross1e2)*100),
			array("label" => "Non-Reader", "y" => (($totaldata1e2['nrtm']+$totaldata1e2['nrtf'])/$totalGross1e2)*100)
		);

		$dataPoints1E2a = array(
			array("label" => "Frustration", "y" => ($totaldata1e2['fttm']/$totaldata1e2['ertm'])*100),
			array("label" => "Instructional", "y" => ($totaldata1e2['ittm']/$totaldata1e2['ertm'])*100),
			array("label" => "Idependent", "y" => ($totaldata1e2['idtm']/$totaldata1e2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1e2['nrtm']/$totaldata1e2['ertm'])*100)
		);

		$dataPoints1E2b = array(
			array("label" => "Frustration", "y" => ($totaldata1e2['fttf']/$totaldata1e2['ertf'])*100),
			array("label" => "Instructional", "y" => ($totaldata1e2['ittf']/$totaldata1e2['ertf'])*100),
			array("label" => "Idependent", "y" => ($totaldata1e2['idtf']/$totaldata1e2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($totaldata1e2['nrtf']/$totaldata1e2['ertf'])*100)
		);
	}
	else{
		$dataPoints1E2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1E2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1E2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
?>