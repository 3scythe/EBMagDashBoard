<?php

include "connect.php";

if(isset($_POST['useSet'])){
    header('Location: ../userSettings.php');
}
elseif(isset($_POST['secSet'])){
    header('Location: ../SecureSettings.php');
}
elseif(isset($_POST['logout'])){
    header('Location: http://localhost/EB%20Magalona%20Online%20Dasboard/');
}


if(isset($_POST['Gross'])){
    
    $minn1 = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM grossenrollrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM grossenrollrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM grossenrollrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM grossenrollrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../grossRatePage.php');
}
elseif(isset($_POST['Net'])){

    $minn1 = "SELECT * FROM netenrollrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM netenrollrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM netenrollrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM netenrollrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM netenrollrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM netenrollrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../netRatePage.php');
}
elseif(isset($_POST['Drop'])){

    $minn1 = "SELECT * FROM droprate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM droprate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM droprate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM droprate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM droprate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM droprate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../dropRatePage.php');
}
elseif(isset($_POST['Surv'])){

    $minn1 = "SELECT * FROM survivalrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM survivalrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM survivalrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM survivalrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM survivalrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM survivalrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../survRatePage.php');
}
elseif(isset($_POST['Fail'])){

    $minn1 = "SELECT * FROM failurerate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM failurerate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM failurerate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM failurerate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM failurerate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM failurerate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../failRatePage.php');
}
elseif(isset($_POST['Comp'])){

    $minn1 = "SELECT * FROM completionrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM completionrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM completionrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM completionrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM completionrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM completionrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../CompRatePage.php');
}
elseif(isset($_POST['Ret'])){

    $minn1 = "SELECT * FROM retentionrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM retentionrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM retentionrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM retentionrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM retentionrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM retentionrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../retRatePage.php');
}
elseif(isset($_POST['Grad'])){

    $minn1 = "SELECT * FROM graduationrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM graduationrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM graduationrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM graduationrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM graduationrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM graduationrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../gradRatePage.php');
}
elseif(isset($_POST['Prom'])){

    $minn1 = "SELECT * FROM promotionrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM promotionrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM promotionrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM promotionrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM promotionrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM promotionrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../promRatePage.php');
}
elseif(isset($_POST['Rep'])){

    $minn1 = "SELECT * FROM repeatitionrate WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM repeatitionrate WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM repeatitionrate WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM repeatitionrate WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM repeatitionrate WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM repeatitionrate WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin2['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows2['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../repRatePage.php');
}
elseif(isset($_POST['EngOral'])){
    
    $minn1 = "SELECT * FROM philirioral WHERE Grade = 3 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM philirioral WHERE Grade = 3 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM philirioral WHERE Grade = 4 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM philirioral WHERE Grade = 4 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM philirioral WHERE Grade = 5 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM philirioral WHERE Grade = 5 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin3 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin3['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows3['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }
    $minn4 = "SELECT * FROM philirioral WHERE Grade = 6 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin4 = mysqli_query($conn3, $minn4);
    $maxx4 = "SELECT * FROM philirioral WHERE Grade = 6 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax4 = mysqli_query($conn3, $maxx4);

    if (mysqli_num_rows($resultmax4) > 0) {
        $rowsmin4 = mysqli_fetch_assoc($resultmin4);
        $min4 = $rowsmin4['Year'];
        $rows4 = mysqli_fetch_assoc($resultmax4);
        $max4 = $rows4['Year'];

        $_SESSION['timeMin4'] = $min4;
        $_SESSION['timeMax4'] = $max4;
    }
    else{
       $_SESSION['timeMin4'] = "none";
       $_SESSION['timeMax4'] = "none";
    }

    $minn5 = "SELECT * FROM philirioral WHERE Grade = 7 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin5 = mysqli_query($conn3, $minn5);
    $maxx5 = "SELECT * FROM philirioral WHERE Grade = 7 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax5 = mysqli_query($conn3, $maxx5);
    
    if (mysqli_num_rows($resultmax5) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin5);
        $min5 = $rowsmin5['Year'];
        $rows5 = mysqli_fetch_array($resultmax5);
        $max5 = $rows5['Year'];

        $_SESSION['timeMin5'] = $min5;
        $_SESSION['timeMax5'] = $max5;
    }
    else{
       $_SESSION['timeMin5'] = "none";
       $_SESSION['timeMax5'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../engOralPhiliri.php');
}
elseif(isset($_POST['FilOral'])){

    $minn1 = "SELECT * FROM philirioral WHERE Grade = '3' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM philirioral WHERE Grade = '3' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM philirioral WHERE Grade = '4' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM philirioral WHERE Grade = '4' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM philirioral WHERE Grade = '5' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM philirioral WHERE Grade = '5' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin3 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin3['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows3['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }
    $minn4 = "SELECT * FROM philirioral WHERE Grade = '6' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin4 = mysqli_query($conn3, $minn4);
    $maxx4 = "SELECT * FROM philirioral WHERE Grade = '6' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax4 = mysqli_query($conn3, $maxx4);

    if (mysqli_num_rows($resultmax4) > 0) {
        $rowsmin4 = mysqli_fetch_assoc($resultmin4);
        $min4 = $rowsmin4['Year'];
        $rows4 = mysqli_fetch_assoc($resultmax4);
        $max4 = $rows4['Year'];

        $_SESSION['timeMin4'] = $min4;
        $_SESSION['timeMax4'] = $max4;
    }
    else{
       $_SESSION['timeMin4'] = "none";
       $_SESSION['timeMax4'] = "none";
    }

    $minn5 = "SELECT * FROM philirioral WHERE Grade = '7' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin5 = mysqli_query($conn3, $minn5);
    $maxx5 = "SELECT * FROM philirioral WHERE Grade = '7' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax5 = mysqli_query($conn3, $maxx5);
    
    if (mysqli_num_rows($resultmax5) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin5);
        $min5 = $rowsmin5['Year'];
        $rows5 = mysqli_fetch_array($resultmax5);
        $max5 = $rows5['Year'];

        $_SESSION['timeMin5'] = $min5;
        $_SESSION['timeMax5'] = $max5;
    }
    else{
       $_SESSION['timeMin5'] = "none";
       $_SESSION['timeMax5'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../filOralPhiliri.php');
}
elseif(isset($_POST['EngSilent'])){
    
    $minn1 = "SELECT * FROM philirisilent WHERE Grade = 3 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM philirisilent WHERE Grade = 3 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM philirisilent WHERE Grade = 4 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM philirisilent WHERE Grade = 4 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM philirisilent WHERE Grade = 5 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM philirisilent WHERE Grade = 5 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin3 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin3['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows3['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }
    $minn4 = "SELECT * FROM philirisilent WHERE Grade = 6 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin4 = mysqli_query($conn3, $minn4);
    $maxx4 = "SELECT * FROM philirisilent WHERE Grade = 6 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax4 = mysqli_query($conn3, $maxx4);

    if (mysqli_num_rows($resultmax4) > 0) {
        $rowsmin4 = mysqli_fetch_assoc($resultmin4);
        $min4 = $rowsmin4['Year'];
        $rows4 = mysqli_fetch_assoc($resultmax4);
        $max4 = $rows4['Year'];

        $_SESSION['timeMin4'] = $min4;
        $_SESSION['timeMax4'] = $max4;
    }
    else{
       $_SESSION['timeMin4'] = "none";
       $_SESSION['timeMax4'] = "none";
    }

    $minn5 = "SELECT * FROM philirisilent WHERE Grade = 7 AND subject = 'English' ORDER BY Year ASC LIMIT 1;";
    $resultmin5 = mysqli_query($conn3, $minn5);
    $maxx5 = "SELECT * FROM philirisilent WHERE Grade = 7 AND subject = 'English' ORDER BY Year DESC LIMIT 1;";
    $resultmax5 = mysqli_query($conn3, $maxx5);
    
    if (mysqli_num_rows($resultmax5) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin5);
        $min5 = $rowsmin5['Year'];
        $rows5 = mysqli_fetch_array($resultmax5);
        $max5 = $rows5['Year'];

        $_SESSION['timeMin5'] = $min5;
        $_SESSION['timeMax5'] = $max5;
    }
    else{
       $_SESSION['timeMin5'] = "none";
       $_SESSION['timeMax5'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../engSilentPhiliri.php');
}
elseif(isset($_POST['FilSilent'])){

    $minn1 = "SELECT * FROM philirisilent WHERE Grade = '3' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM philirisilent WHERE Grade = '3' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $minn2 = "SELECT * FROM philirisilent WHERE Grade = '4' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin2 = mysqli_query($conn3, $minn2);
    $maxx2 = "SELECT * FROM philirisilent WHERE Grade = '4' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax2 = mysqli_query($conn3, $maxx2);
    
    if (mysqli_num_rows($resultmax2) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin2);
        $min2 = $rowsmin2['Year'];
        $rows2 = mysqli_fetch_array($resultmax2);
        $max2 = $rows2['Year'];

        $_SESSION['timeMin2'] = $min2;
        $_SESSION['timeMax2'] = $max2;
    }
    else{
       $_SESSION['timeMin2'] = "none";
       $_SESSION['timeMax2'] = "none";
    }

    $minn3 = "SELECT * FROM philirisilent WHERE Grade = '5' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin3 = mysqli_query($conn3, $minn3);
    $maxx3 = "SELECT * FROM philirisilent WHERE Grade = '5' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax3 = mysqli_query($conn3, $maxx3);
    
    if (mysqli_num_rows($resultmax3) > 0) {
        $rowsmin3 = mysqli_fetch_array($resultmin3);
        $min3 = $rowsmin3['Year'];
        $rows3 = mysqli_fetch_array($resultmax3);
        $max3 = $rows3['Year'];

        $_SESSION['timeMin3'] = $min3;
        $_SESSION['timeMax3'] = $max3;
    }
    else{
       $_SESSION['timeMin3'] = "none";
       $_SESSION['timeMax3'] = "none";
    }
    $minn4 = "SELECT * FROM philirisilent WHERE Grade = '6' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin4 = mysqli_query($conn3, $minn4);
    $maxx4 = "SELECT * FROM philirisilent WHERE Grade = '6' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax4 = mysqli_query($conn3, $maxx4);

    if (mysqli_num_rows($resultmax4) > 0) {
        $rowsmin4 = mysqli_fetch_assoc($resultmin4);
        $min4 = $rowsmin4['Year'];
        $rows4 = mysqli_fetch_assoc($resultmax4);
        $max4 = $rows4['Year'];

        $_SESSION['timeMin4'] = $min4;
        $_SESSION['timeMax4'] = $max4;
    }
    else{
       $_SESSION['timeMin4'] = "none";
       $_SESSION['timeMax4'] = "none";
    }

    $minn5 = "SELECT * FROM philirisilent WHERE Grade = '7' AND subject = 'Filipino' ORDER BY Year ASC LIMIT 1;";
    $resultmin5 = mysqli_query($conn3, $minn5);
    $maxx5 = "SELECT * FROM philirisilent WHERE Grade = '7' AND subject = 'Filipino' ORDER BY Year DESC LIMIT 1;";
    $resultmax5 = mysqli_query($conn3, $maxx5);
    
    if (mysqli_num_rows($resultmax5) > 0) {
        $rowsmin2 = mysqli_fetch_array($resultmin5);
        $min5 = $rowsmin5['Year'];
        $rows5 = mysqli_fetch_array($resultmax5);
        $max5 = $rows5['Year'];

        $_SESSION['timeMin5'] = $min5;
        $_SESSION['timeMax5'] = $max5;
    }
    else{
       $_SESSION['timeMin5'] = "none";
       $_SESSION['timeMax5'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../filSilentPhiliri.php');
}
elseif(isset($_POST['NutriElem'])){
    
    $minn1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../elemNutri.php');
}
elseif(isset($_POST['HutriPri'])){

    $minn1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../priNutri.php');
}
elseif(isset($_POST['Elem4P'])){

    $minn1 = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../elem4P.php');
}
elseif(isset($_POST['High4P'])){

    $minn1 = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' ORDER BY Year ASC LIMIT 1;";
    $resultmin1 = mysqli_query($conn3, $minn1);
    $maxx1 = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' ORDER BY Year DESC LIMIT 1;";
    $resultmax1 = mysqli_query($conn3, $maxx1);

    session_start();

    if (mysqli_num_rows($resultmax1) > 0) {
        $rowsmin1 = mysqli_fetch_assoc($resultmin1);
        $min1 = $rowsmin1['Year'];
        $rows1 = mysqli_fetch_assoc($resultmax1);
        $max1 = $rows1['Year'];

        $_SESSION['timeMin1'] = $min1;
        $_SESSION['timeMax1'] = $max1;
    }
    else{
       $_SESSION['timeMin1'] = "none";
       $_SESSION['timeMax1'] = "none";
    }

    $_SESSION['display'] = "none";
    header('Location: ../high4P.php');
}

if (isset($_POST['elemBut'])) {

    $schl = $_POST['elemBut'];

    $minnG = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminG = mysqli_query($conn3, $minnG);
    $maxxG = "SELECT * FROM grossenrollrate WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxG = mysqli_query($conn3, $maxxG);

    $minnEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminEO = mysqli_query($conn3, $minnEO);
    $maxxEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxEO = mysqli_query($conn3, $maxxEO);

    $minnFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFO = mysqli_query($conn3, $minnFO);
    $maxxFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFO = mysqli_query($conn3, $maxxFO);

    $minnES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminES = mysqli_query($conn3, $minnES);
    $maxxES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxES = mysqli_query($conn3, $maxxES);

    $minnFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFS = mysqli_query($conn3, $minnFS);
    $maxxFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade < 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFS = mysqli_query($conn3, $maxxFS);

    $minnNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminNS = mysqli_query($conn3, $minnNS);
    $maxxNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxNS = mysqli_query($conn3, $maxxNS);

    $minn4p = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultmin4p = mysqli_query($conn3, $minn4p);
    $maxx4p = "SELECT * FROM distric4ps WHERE Groups = 'Elementary' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmax4p = mysqli_query($conn3, $maxx4p);

    session_start();

    if (mysqli_num_rows($resultmaxG) > 0) {
        $rowsminG = mysqli_fetch_assoc($resultminG);
        $rowsG = mysqli_fetch_assoc($resultmaxG);

        $_SESSION['timeMinG'] = $rowsminG['Year'];
        $_SESSION['timeMaxG'] = $rowsG['Year'];
    }
    else{
       $_SESSION['timeMinG'] = "none";
       $_SESSION['timeMaxG'] = "none";
    }

    if (mysqli_num_rows($resultmaxEO) > 0) {
        $rowsminEO = mysqli_fetch_assoc($resultminEO);
        $rowsEO = mysqli_fetch_assoc($resultmaxEO);

        $_SESSION['timeMinEO'] = $rowsminEO['Year'];;
        $_SESSION['timeMaxEO'] = $rowsEO['Year'];;
    }
    else{
       $_SESSION['timeMinEO'] = "none";
       $_SESSION['timeMaxEO'] = "none";
    }

    if (mysqli_num_rows($resultmaxFO) > 0) {
        $rowsminFO = mysqli_fetch_assoc($resultminFO);
        $rowsFO = mysqli_fetch_assoc($resultmaxFO);

        $_SESSION['timeMinFO'] = $rowsminFO['Year'];;
        $_SESSION['timeMaxFO'] = $rowsFO['Year'];;
    }
    else{
       $_SESSION['timeMinFO'] = "none";
       $_SESSION['timeMaxFO'] = "none";
    }

    if (mysqli_num_rows($resultmaxES) > 0) {
        $rowsminES = mysqli_fetch_assoc($resultminES);
        $rowsES = mysqli_fetch_assoc($resultmaxES);

        $_SESSION['timeMinES'] = $rowsminES['Year'];
        $_SESSION['timeMaxES'] = $rowsES['Year'];
    }
    else{
       $_SESSION['timeMinES'] = "none";
       $_SESSION['timeMaxES'] = "none";
    }

    if (mysqli_num_rows($resultmaxFS) > 0) {
        $rowsminFS = mysqli_fetch_assoc($resultminFS);
        $rowsFS = mysqli_fetch_assoc($resultmaxFS);

        $_SESSION['timeMinFS'] = $rowsminFS['Year'];
        $_SESSION['timeMaxFS'] = $rowsFS['Year'];
    }
    else{
       $_SESSION['timeMinFS'] = "none";
       $_SESSION['timeMaxFS'] = "none";
    }

    if (mysqli_num_rows($resultmaxNS) > 0) {
        $rowsminNS = mysqli_fetch_assoc($resultminNS);
        $rowsNS = mysqli_fetch_assoc($resultmaxNS);

        $_SESSION['timeMinNS'] = $rowsminNS['Year'];
        $_SESSION['timeMaxNS'] = $rowsNS['Year'];
    }
    else{
       $_SESSION['timeMinNS'] = "none";
       $_SESSION['timeMaxNS'] = "none";
    }  

    if (mysqli_num_rows($resultmax4p) > 0) {
        $rowsmin4p = mysqli_fetch_assoc($resultmin4p);
        $rows4p = mysqli_fetch_assoc($resultmax4p);

        $_SESSION['timeMin4p'] = $rowsmin4p['Year'];
        $_SESSION['timeMax4p'] = $rows4p['Year'];
    }
    else{
       $_SESSION['timeMin4p'] = "none";
       $_SESSION['timeMax4p'] = "none";
    } 

    $_SESSION['School'] = $schl;
    $_SESSION['display'] = "None";
    $_SESSION['display2'] = "None";
    header('Location: ../ElemSchool.php');
}

if (isset($_POST['highBut'])) {

    $schl = $_POST['highBut'];

    $minnG = "SELECT * FROM grossenrollrate WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminG = mysqli_query($conn3, $minnG);
    $maxxG = "SELECT * FROM grossenrollrate WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxG = mysqli_query($conn3, $maxxG);

    $minnEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade = 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminEO = mysqli_query($conn3, $minnEO);
    $maxxEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade = 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxEO = mysqli_query($conn3, $maxxEO);

    $minnFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade = 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFO = mysqli_query($conn3, $minnFO);
    $maxxFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade = 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFO = mysqli_query($conn3, $maxxFO);

    $minnES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade = 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminES = mysqli_query($conn3, $minnES);
    $maxxES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade = 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxES = mysqli_query($conn3, $maxxES);

    $minnFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade = 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFS = mysqli_query($conn3, $minnFS);
    $maxxFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade = 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFS = mysqli_query($conn3, $maxxFS);

    $minnNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminNS = mysqli_query($conn3, $minnNS);
    $maxxNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxNS = mysqli_query($conn3, $maxxNS);

    $minn4p = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultmin4p = mysqli_query($conn3, $minn4p);
    $maxx4p = "SELECT * FROM distric4ps WHERE Groups = 'Highschool' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmax4p = mysqli_query($conn3, $maxx4p);

    session_start();

    if (mysqli_num_rows($resultmaxG) > 0) {
        $rowsminG = mysqli_fetch_assoc($resultminG);
        $rowsG = mysqli_fetch_assoc($resultmaxG);

        $_SESSION['timeMinG'] = $rowsminG['Year'];
        $_SESSION['timeMaxG'] = $rowsG['Year'];
    }
    else{
       $_SESSION['timeMinG'] = "none";
       $_SESSION['timeMaxG'] = "none";
    }

    if (mysqli_num_rows($resultmaxEO) > 0) {
        $rowsminEO = mysqli_fetch_assoc($resultminEO);
        $rowsEO = mysqli_fetch_assoc($resultmaxEO);

        $_SESSION['timeMinEO'] = $rowsminEO['Year'];;
        $_SESSION['timeMaxEO'] = $rowsEO['Year'];;
    }
    else{
       $_SESSION['timeMinEO'] = "none";
       $_SESSION['timeMaxEO'] = "none";
    }

    if (mysqli_num_rows($resultmaxFO) > 0) {
        $rowsminFO = mysqli_fetch_assoc($resultminFO);
        $rowsFO = mysqli_fetch_assoc($resultmaxFO);

        $_SESSION['timeMinFO'] = $rowsminFO['Year'];;
        $_SESSION['timeMaxFO'] = $rowsFO['Year'];;
    }
    else{
       $_SESSION['timeMinFO'] = "none";
       $_SESSION['timeMaxFO'] = "none";
    }

    if (mysqli_num_rows($resultmaxES) > 0) {
        $rowsminES = mysqli_fetch_assoc($resultminES);
        $rowsES = mysqli_fetch_assoc($resultmaxES);

        $_SESSION['timeMinES'] = $rowsminES['Year'];
        $_SESSION['timeMaxES'] = $rowsES['Year'];
    }
    else{
       $_SESSION['timeMinES'] = "none";
       $_SESSION['timeMaxES'] = "none";
    }

    if (mysqli_num_rows($resultmaxFS) > 0) {
        $rowsminES = mysqli_fetch_assoc($resultminFS);
        $rowsES = mysqli_fetch_assoc($resultmaxFS);

        $_SESSION['timeMinFS'] = $rowsminFS['Year'];
        $_SESSION['timeMaxFS'] = $rowsFS['Year'];
    }
    else{
       $_SESSION['timeMinFS'] = "none";
       $_SESSION['timeMaxFS'] = "none";
    }

    if (mysqli_num_rows($resultmaxNS) > 0) {
        $rowsminNS = mysqli_fetch_assoc($resultminNS);
        $rowsNS = mysqli_fetch_assoc($resultmaxNS);

        $_SESSION['timeMinNS'] = $rowsminNS['Year'];
        $_SESSION['timeMaxNS'] = $rowsNS['Year'];
    }
    else{
       $_SESSION['timeMinNS'] = "none";
       $_SESSION['timeMaxNS'] = "none";
    }  

    if (mysqli_num_rows($resultmax4p) > 0) {
        $rowsmin4p = mysqli_fetch_assoc($resultmin4p);
        $rows4p = mysqli_fetch_assoc($resultmax4p);

        $_SESSION['timeMin4p'] = $rowsmin4p['Year'];
        $_SESSION['timeMax4p'] = $rows4p['Year'];
    }
    else{
       $_SESSION['timeMin4p'] = "none";
       $_SESSION['timeMax4p'] = "none";
    } 

    $_SESSION['School'] = $schl;
    $_SESSION['display'] = "None";
    $_SESSION['display2'] = "None";
    header('Location: ../HighSchool.php');
}

if (isset($_POST['priBut'])) {

    $schl = $_POST['priBut'];

    $minnG = "SELECT * FROM grossenrollrate WHERE Groups = 'Private' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminG = mysqli_query($conn3, $minnG);
    $maxxG = "SELECT * FROM grossenrollrate WHERE Groups = 'Private' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxG = mysqli_query($conn3, $maxxG);

    $minnEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade > 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminEO = mysqli_query($conn3, $minnEO);
    $maxxEO = "SELECT * FROM philirioral WHERE subject = 'English' AND Grade > 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxEO = mysqli_query($conn3, $maxxEO);

    $minnFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade > 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFO = mysqli_query($conn3, $minnFO);
    $maxxFO = "SELECT * FROM philirioral WHERE subject = 'Filipino' AND Grade > 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFO = mysqli_query($conn3, $maxxFO);

    $minnES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade > 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminES = mysqli_query($conn3, $minnES);
    $maxxES = "SELECT * FROM philirisilent WHERE subject = 'English' AND Grade > 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxES = mysqli_query($conn3, $maxxES);

    $minnFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade > 7 AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminFS = mysqli_query($conn3, $minnFS);
    $maxxFS = "SELECT * FROM philirisilent WHERE subject = 'Filipino' AND Grade > 7 AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxFS = mysqli_query($conn3, $maxxFS);

    $minnNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' AND School = '$schl' ORDER BY Year ASC LIMIT 1;";
    $resultminNS = mysqli_query($conn3, $minnNS);
    $maxxNS = "SELECT * FROM nutritionstatus WHERE Groups = 'Private' AND School = '$schl' ORDER BY Year DESC LIMIT 1;";
    $resultmaxNS = mysqli_query($conn3, $maxxNS);

    session_start();

    if (mysqli_num_rows($resultmaxG) > 0) {
        $rowsminG = mysqli_fetch_assoc($resultminG);
        $rowsG = mysqli_fetch_assoc($resultmaxG);

        $_SESSION['timeMinG'] = $rowsminG['Year'];
        $_SESSION['timeMaxG'] = $rowsG['Year'];
    }
    else{
       $_SESSION['timeMinG'] = "none";
       $_SESSION['timeMaxG'] = "none";
    }

    if (mysqli_num_rows($resultmaxEO) > 0) {
        $rowsminEO = mysqli_fetch_assoc($resultminEO);
        $rowsEO = mysqli_fetch_assoc($resultmaxEO);

        $_SESSION['timeMinEO'] = $rowsminEO['Year'];;
        $_SESSION['timeMaxEO'] = $rowsEO['Year'];;
    }
    else{
       $_SESSION['timeMinEO'] = "none";
       $_SESSION['timeMaxEO'] = "none";
    }

    if (mysqli_num_rows($resultmaxFO) > 0) {
        $rowsminFO = mysqli_fetch_assoc($resultminFO);
        $rowsFO = mysqli_fetch_assoc($resultmaxFO);

        $_SESSION['timeMinFO'] = $rowsminFO['Year'];;
        $_SESSION['timeMaxFO'] = $rowsFO['Year'];;
    }
    else{
       $_SESSION['timeMinFO'] = "none";
       $_SESSION['timeMaxFO'] = "none";
    }

    if (mysqli_num_rows($resultmaxES) > 0) {
        $rowsminES = mysqli_fetch_assoc($resultminES);
        $rowsES = mysqli_fetch_assoc($resultmaxES);

        $_SESSION['timeMinES'] = $rowsminES['Year'];
        $_SESSION['timeMaxES'] = $rowsES['Year'];
    }
    else{
       $_SESSION['timeMinES'] = "none";
       $_SESSION['timeMaxES'] = "none";
    }

    if (mysqli_num_rows($resultmaxFS) > 0) {
        $rowsminES = mysqli_fetch_assoc($resultminFS);
        $rowsES = mysqli_fetch_assoc($resultmaxFS);

        $_SESSION['timeMinFS'] = $rowsminFS['Year'];
        $_SESSION['timeMaxFS'] = $rowsFS['Year'];
    }
    else{
       $_SESSION['timeMinFS'] = "none";
       $_SESSION['timeMaxFS'] = "none";
    }

    if (mysqli_num_rows($resultmaxNS) > 0) {
        $rowsminNS = mysqli_fetch_assoc($resultminNS);
        $rowsNS = mysqli_fetch_assoc($resultmaxNS);

        $_SESSION['timeMinNS'] = $rowsminNS['Year'];
        $_SESSION['timeMaxNS'] = $rowsNS['Year'];
    }
    else{
       $_SESSION['timeMinNS'] = "none";
       $_SESSION['timeMaxNS'] = "none";
    }

    $_SESSION['School'] = $schl;
    $_SESSION['display'] = "None";
    $_SESSION['display2'] = "None";
    header('Location: ../PriSchool.php');
}

?>