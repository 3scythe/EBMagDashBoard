<?php
//Philiri Oral

	//grade 3
	$tb1 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' GROUP BY School";
    $tbresult = mysqli_query($conn3,$tb1);

    $tblpre1 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' ORDER BY School";
    $tblpost1 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' ORDER BY School";
    $tblpre = mysqli_query($conn3, $tblpre1);
    $tblpost = mysqli_query($conn3, $tblpost1);

    $tblnum1 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' GROUP BY pORp";
    $tblnum = mysqli_query($conn3, $tblnum1);
    $tblnm = mysqli_fetch_array($tblnum);

    //grade 4
    $tb12 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' GROUP BY School";
    $tbresult2 = mysqli_query($conn3,$tb12);

    $tblpre12 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' ORDER BY School";
    $tblpost12 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' ORDER BY School";
    $tblpre2 = mysqli_query($conn3, $tblpre12);
    $tblpost2 = mysqli_query($conn3, $tblpost12);

    $tblnum12 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime2' AND Grade = 4 AND subject = '$subj' GROUP BY pORp";
    $tblnum2 = mysqli_query($conn3, $tblnum12);
    $tblnm2 = mysqli_fetch_array($tblnum2);

    //grade 5
    $tb13 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' GROUP BY School";
    $tbresult3 = mysqli_query($conn3,$tb13);

    $tblpre13 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' ORDER BY School";
    $tblpost13 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' ORDER BY School";
    $tblpre3 = mysqli_query($conn3, $tblpre13);
    $tblpost3 = mysqli_query($conn3, $tblpost13);

    $tblnum13 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime3' AND Grade = 5 AND subject = '$subj' GROUP BY pORp";
    $tblnum3 = mysqli_query($conn3, $tblnum13);
    $tblnm3 = mysqli_fetch_array($tblnum3);

    //grade 6
    $tb14 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' GROUP BY School";
    $tbresult4 = mysqli_query($conn3,$tb14);

    $tblpre14 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' ORDER BY School";
    $tblpost14 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' ORDER BY School";
    $tblpre4 = mysqli_query($conn3, $tblpre14);
    $tblpost4 = mysqli_query($conn3, $tblpost14);

    $tblnum14 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime4' AND Grade = 6 AND subject = '$subj' GROUP BY pORp";
    $tblnum4 = mysqli_query($conn3, $tblnum14);
    $tblnm4 = mysqli_fetch_array($tblnum4);

    //grade 7
    $tb15 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' GROUP BY School";
    $tbresult5 = mysqli_query($conn3,$tb15);

    $tblpre15 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' ORDER BY School";
    $tblpost15 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' ORDER BY School";
    $tblpre5 = mysqli_query($conn3, $tblpre15);
    $tblpost5 = mysqli_query($conn3, $tblpost15);

    $tblnum15 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime5' AND Grade = 7 AND subject = '$subj' GROUP BY pORp";
    $tblnum5 = mysqli_query($conn3, $tblnum15);
    $tblnm5 = mysqli_fetch_array($tblnum5);
?>