<?php
//Philiri Oral

//grade 3
    
    $stb1 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' GROUP BY School";
    $stbresult = mysqli_query($conn3,$stb1);

    $stblpre1 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' ORDER BY School";
    $stblpost1 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' ORDER BY School";
    $stblpre = mysqli_query($conn3, $stblpre1);
    $stblpost = mysqli_query($conn3, $stblpost1);

    $stblnum1 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 3 AND subject = '$subj' GROUP BY pORp";
    $stblnum = mysqli_query($conn3, $stblnum1);
    $stblnm = mysqli_fetch_array($stblnum);

//grade 4
    
    $stb12 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' GROUP BY School";
    $stbresult2 = mysqli_query($conn3,$stb12);

    $stblpre12 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' ORDER BY School";
    $stblpost12 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' ORDER BY School";
    $stblpre2 = mysqli_query($conn3, $stblpre12);
    $stblpost2 = mysqli_query($conn3, $stblpost12);

    $stblnum12 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 4 AND subject = '$subj' GROUP BY pORp";
    $stblnum2 = mysqli_query($conn3, $stblnum12);
    $stblnm2 = mysqli_fetch_array($stblnum2);

//grade 5
    
    $stb13 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' GROUP BY School";
    $stbresult3 = mysqli_query($conn3,$stb13);

    $stblpre13 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' ORDER BY School";
    $stblpost13 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' ORDER BY School";
    $stblpre3 = mysqli_query($conn3, $stblpre13);
    $stblpost3 = mysqli_query($conn3, $stblpost13);

    $stblnum13 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 5 AND subject = '$subj' GROUP BY pORp";
    $stblnum3 = mysqli_query($conn3, $stblnum13);
    $stblnm3 = mysqli_fetch_array($stblnum3);

//grade 6
   
    $stb14 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' GROUP BY School";
    $stbresult4 = mysqli_query($conn3,$stb14);

    $stblpre14 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' ORDER BY School";
    $stblpost14 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' ORDER BY School";
    $stblpre4 = mysqli_query($conn3, $stblpre14);
    $stblpost4 = mysqli_query($conn3, $stblpost14);

    $stblnum14 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 6 AND subject = '$subj' GROUP BY pORp";
    $stblnum4 = mysqli_query($conn3, $stblnum14);
    $stblnm4 = mysqli_fetch_array($stblnum4);

//grade 7
   
    $stb15 = "SELECT * FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' GROUP BY School";
    $stbresult5 = mysqli_query($conn3,$stb15);

    $stblpre15 = "SELECT * FROM `{$tabName}` WHERE pORp = 'pre' AND Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' ORDER BY School";
    $stblpost15 = "SELECT * FROM `{$tabName}` WHERE pORp = 'post' AND Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' ORDER BY School";
    $stblpre5 = mysqli_query($conn3, $stblpre15);
    $stblpost5 = mysqli_query($conn3, $stblpost15);

    $stblnum15 = "SELECT count(*) AS ttldata FROM `{$tabName}` WHERE Year = '$chosenTime' AND Grade = 7 AND subject = '$subj' GROUP BY pORp";
    $stblnum5 = mysqli_query($conn3, $stblnum15);
    $stblnm5 = mysqli_fetch_array($stblnum5);

?>