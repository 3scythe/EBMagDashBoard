<?php
	include "connect.php";
 	
//Pie Chart

	//Elementary
	$data1a = "SELECT * FROM `{$tabName}` WHERE Groups = '$grouped' AND Year = '$chosenTime' ORDER BY School";
	$dataresult1a = mysqli_query($conn3, $data1a);

	if (mysqli_num_rows($dataresult1a) > 0) {
		$total1a = "SELECT 
		SUM(enmale) AS 'tm', 
		SUM(enfemale) AS 'tf', 
		SUM(pwmale) AS 'pwtm', 
		SUM(pwfemale) AS 'pwtf', 
		SUM(bmiswmale) AS 'bmiswtm', 
		SUM(bmiswfemale) AS 'bmiswtf',
		SUM(bmiwmale) AS 'bmiwtm', 
		SUM(bmiwfemale) AS 'bmiwtf',
		SUM(bminmale) AS 'bmintm', 
		SUM(bminfemale) AS 'bmintf',
		SUM(bmiowmale) AS 'bmiowtm', 
		SUM(bmiowfemale) AS 'bmiowtf',
		SUM(bmiomale) AS 'bmiotm', 
		SUM(bmiofemale) AS 'bmiotf',

		SUM(hfassmale) AS 'hfasstm',
		SUM(hfassfemale) AS 'hfasstf',
		SUM(hfasmale) AS 'hfastm',
		SUM(hfasfemale) AS 'hfastf',
		SUM(hfanmale) AS 'hfantm',
		SUM(hfanfemale) AS 'hfantf',
		SUM(hfatmale) AS 'hfattm',
		SUM(hfatfemale) AS 'hfattf',
		SUM(pthmale) AS 'pthtm',
		SUM(pthfemale) AS 'pthtf'
		
		FROM `{$tabName}` Where Groups = '$grouped' AND Year = '$chosenTime'";
		$totalresult1a = mysqli_query($conn3, $total1a);
		$totaldata1a = mysqli_fetch_assoc($totalresult1a);

		$totalGross1a = $totaldata1a['tm']+$totaldata1a['tf'];

		$dataPoints1A = array(
			array("label" => "Severely Wasted", "y" => (($totaldata1a['bmiswtm']+$totaldata1a['bmiswtf'])/$totalGross1a)*100),
			array("label" => "Wasted", "y" => (($totaldata1a['bmiwtm']+$totaldata1a['bmiwtf'])/$totalGross1a)*100),
			array("label" => "Normal", "y" => (($totaldata1a['bmintm']+$totaldata1a['bmintf'])/$totalGross1a)*100),
			array("label" => "Overweight", "y" => (($totaldata1a['bmiowtm']+$totaldata1a['bmiowtf'])/$totalGross1a)*100),
			array("label" => "Obese", "y" => (($totaldata1a['bmiotm']+$totaldata1a['bmiotf'])/$totalGross1a)*100)
		);

		$dataPoints1Aa = array(
			array("label" => "Severely Wasted", "y" => ($totaldata1a['bmiswtm']/$totaldata1a['pwtm'])*100),
			array("label" => "Wasted", "y" => ($totaldata1a['bmiwtm']/$totaldata1a['pwtm'])*100),
			array("label" => "Normal", "y" => ($totaldata1a['bmintm']/$totaldata1a['pwtm'])*100),
			array("label" => "Overweight", "y" => ($totaldata1a['bmiowtm']/$totaldata1a['pwtm'])*100),
			array("label" => "Obese", "y" => ($totaldata1a['bmiotm']/$totaldata1a['pwtm'])*100)
		);	
		$dataPoints1Ab = array(
			array("label" => "Severely Wasted", "y" => ($totaldata1a['bmiswtf']/$totaldata1a['pwtf'])*100),
			array("label" => "Wasted", "y" => ($totaldata1a['bmiwtf']/$totaldata1a['pwtf'])*100),
			array("label" => "Normal", "y" => ($totaldata1a['bmintf']/$totaldata1a['pwtf'])*100),
			array("label" => "Overweight", "y" => ($totaldata1a['bmiowtf']/$totaldata1a['pwtf'])*100),
			array("label" => "Obese", "y" => ($totaldata1a['bmiotf']/$totaldata1a['pwtf'])*100)
		);

		$dataPoints1Ac = array(
			array("label" => "Male Weighted", "y" => ($totaldata1a['pwtm']/$totaldata1a['tm'])*100)
		);

		$dataPoints1Ad = array(
			array("label" => "Female Weighted", "y" => ($totaldata1a['pwtf']/$totaldata1a['tf'])*100)
		);

		$dataPoints2A = array(
			array("label" => "Severely Stunted", "y" => (($totaldata1a['hfasstm']+$totaldata1a['hfasstf'])/$totalGross1a)*100),
			array("label" => "Stunted", "y" => (($totaldata1a['hfastm']+$totaldata1a['hfastf'])/$totalGross1a)*100),
			array("label" => "Normal", "y" => (($totaldata1a['hfantm']+$totaldata1a['hfantf'])/$totalGross1a)*100),
			array("label" => "Tall", "y" => (($totaldata1a['hfattm']+$totaldata1a['hfattf'])/$totalGross1a)*100)
		);	

		$dataPoints2Aa = array(
			array("label" => "Severely Stunted", "y" => ($totaldata1a['hfasstm']/$totaldata1a['pthtm'])*100),
			array("label" => "Stunted", "y" => ($totaldata1a['hfastm']/$totaldata1a['pthtm'])*100),
			array("label" => "Normal", "y" => ($totaldata1a['hfantm']/$totaldata1a['pthtm'])*100),
			array("label" => "Tall", "y" => ($totaldata1a['hfattm']/$totaldata1a['pthtm'])*100)
		);	
		$dataPoints2Ab = array(
			array("label" => "Severely Stunted", "y" => ($totaldata1a['hfasstf']/$totaldata1a['pthtf'])*100),
			array("label" => "Stunted", "y" => ($totaldata1a['hfastf']/$totaldata1a['pthtf'])*100),
			array("label" => "Normal", "y" => ($totaldata1a['hfantf']/$totaldata1a['pthtf'])*100),
			array("label" => "Tall", "y" => ($totaldata1a['hfattf']/$totaldata1a['pthtf'])*100)
		);	
		$dataPoints2Ac = array(
			array("label" => "Male Height Taken", "y" => ($totaldata1a['pthtm']/$totaldata1a['tm'])*100)
		);	
		$dataPoints2Ad = array(
			array("label" => "Female Hieght Taken", "y" => ($totaldata1a['pthtf']/$totaldata1a['tf'])*100)
		);	
	}
	else{
		$dataPoints1A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ac = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Ad = array( 
			array("label" => "No Data", "y" => 0 )
		);

		$dataPoints2A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ac = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints2Ad = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	
?>