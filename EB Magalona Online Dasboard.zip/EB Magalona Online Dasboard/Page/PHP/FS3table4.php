<?php
	$stb1 = "SELECT * FROM philirisilent WHERE School = '$School' AND Grade = 6 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year ASC";
    $stbresult = mysqli_query($conn3,$stb1);

    $stblpre1 = "SELECT * FROM philirisilent WHERE pORp = 'pre' AND School = '$School' AND Grade = 6 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year";
    $stblpost1 = "SELECT * FROM philirisilent WHERE pORp = 'post' AND School = '$School' AND Grade = 6 AND subject = 'Filipino' And Year <= '$chosenTime2' ORDER BY Year";
    $stblpre = mysqli_query($conn3, $stblpre1);
    $stblpost = mysqli_query($conn3, $stblpost1);

    $stblnum1 = "SELECT count(*) AS ttldata FROM philirisilent WHERE School = '$School' AND Grade = 6 AND subject = 'Filipino' And Year <= '$chosenTime2' GROUP BY pORp";
    $stblnum = mysqli_query($conn3, $stblnum1);
    $stblnm = mysqli_fetch_array($stblnum);

	$tnr = mysqli_num_rows($stbresult);

	  echo " <table id=\"myTableFS6\">
	         	<tr>
	            	<td colspan=\"2\">School</td><td colspan=\"6\">Enrollment</td><td colspan=\"6\">Pupil Tested</td>
	                <td colspan=\"18\">Speed Level</td><td colspan=\"18\">Comprehension Level</td><td colspan=\"18\">Reading Level</td>
	            </tr>
	            <tr>
	                <td colspan=\"2\"> </td><td colspan=\"6\"> </td><td colspan=\"6\"> </td><td colspan=\"6\">Slow</td>
	                <td colspan=\"6\">Average</td><td colspan=\"6\">Fast</td><td colspan=\"6\">Frustration</td>
	                <td colspan=\"6\">instructional</td><td colspan=\"6\">Independent</td><td colspan=\"6\">Frustration</td>
	                <td colspan=\"6\">instructional</td><td colspan=\"6\">Independent</td>
	            </tr>
	            <tr>
	                <td colspan=\"2\"> </td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td>
	                <td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td>
	                <td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td>
	                <td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td>
	                <td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td>
	                <td colspan=\"3\">Post</td><td colspan=\"3\">Pre</td><td colspan=\"3\">Post</td>
	            </tr>
	            <tr>
	                <td colspan=\"2\"> </td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	                <td>Male</td><td>Female</td><td>Total</td><td>Male</td><td>Female</td><td>Total</td>
	            </tr>
	            <tr>";
	  if ($tnr > 0) {
	  	for ($tbl=0; $tbl < $stblnm['ttldata']; $tbl++){ 
			$stblrow = mysqli_fetch_array($stbresult);
			 $stblrow2 = mysqli_fetch_array($stblpre);
			 $stblrow3 = mysqli_fetch_array($stblpost);
			  echo "<td colspan=\"2\">".$stblrow['Year']+$tbl."</td>
			        <td>".$stblrow2['ermale']."</td>
			        <td>".$stblrow2['erfemale']."</td>
			        <td>".$stblrow2['ermale']+$stblrow2['erfemale']."</td>
			        <td>".$stblrow3['ermale']."</td>
			        <td>".$stblrow3['erfemale']."</td>
			        <td>".$stblrow3['ermale']+$stblrow3['erfemale']."</td>

			        <td>".$stblrow2['ptmale']."</td>
			        <td>".$stblrow2['ptfemale']."</td>
			        <td>".$stblrow2['ptmale']+$stblrow2['ptfemale']."</td>
			        <td>".$stblrow3['ptmale']."</td>
			        <td>".$stblrow3['ptfemale']."</td>
			        <td>".$stblrow3['ptmale']+$stblrow3['ptfemale']."</td>

			        <td>".$stblrow2['ssmale']."</td>
			        <td>".$stblrow2['ssfemale']."</td>
			        <td>".$stblrow2['ssmale']+$stblrow2['ssfemale']."</td>
			        <td>".$stblrow3['ssmale']."</td>
			        <td>".$stblrow3['ssfemale']."</td>
			        <td>".$stblrow3['ssmale']+$stblrow3['ssfemale']."</td>

			        <td>".$stblrow2['samale']."</td>
			        <td>".$stblrow2['safemale']."</td>
			        <td>".$stblrow2['samale']+$stblrow2['safemale']."</td>
			        <td>".$stblrow3['samale']."</td>
			        <td>".$stblrow3['safemale']."</td>
			        <td>".$stblrow3['samale']+$stblrow3['safemale']."</td>

			        <td>".$stblrow2['sfmale']."</td>
			        <td>".$stblrow2['sffemale']."</td>
			        <td>".$stblrow2['sfmale']+$stblrow2['sffemale']."</td>
			        <td>".$stblrow3['sfmale']."</td>
			        <td>".$stblrow3['sffemale']."</td>
			        <td>".$stblrow3['sfmale']+$stblrow3['sffemale']."</td>

			        <td>".$stblrow2['cftmale']."</td>
			        <td>".$stblrow2['cftfemale']."</td>                    
			        <td>".$stblrow2['cftmale']+$stblrow2['cftfemale']."</td>
			        <td>".$stblrow3['cftmale']."</td>
			        <td>".$stblrow3['cftfemale']."</td>
			        <td>".$stblrow3['cftmale']+$stblrow3['cftfemale']."</td>

			        <td>".$stblrow2['citmale']."</td>
			        <td>".$stblrow2['citfemale']."</td>
			        <td>".$stblrow2['citmale']+$stblrow2['citfemale']."</td>
			        <td>".$stblrow3['citmale']."</td>
			        <td>".$stblrow3['citfemale']."</td>
			        <td>".$stblrow3['citmale']+$stblrow3['citfemale']."</td>

			        <td>".$stblrow2['cidmale']."</td>
			        <td>".$stblrow2['cidfemale']."</td>
			        <td>".$stblrow2['cidmale']+$stblrow2['cidfemale']."</td>
			        <td>".$stblrow3['cidmale']."</td>
			        <td>".$stblrow3['cidfemale']."</td>
			        <td>".$stblrow3['cidmale']+$stblrow3['cidfemale']."</td>

			        <td>".$stblrow2['rlftmale']."</td>
			        <td>".$stblrow2['rlftfemale']."</td>
			        <td>".$stblrow2['rlftmale']+$stblrow2['rlftfemale']."</td>
			        <td>".$stblrow3['rlftmale']."</td>
			        <td>".$stblrow3['rlftfemale']."</td>
			        <td>".$stblrow3['rlftmale']+$stblrow3['rlftfemale']."</td>

			        <td>".$stblrow2['rlitmale']."</td>
			        <td>".$stblrow2['rlitfemale']."</td>
			        <td>".$stblrow2['rlitmale']+$stblrow2['rlitfemale']."</td>
			        <td>".$stblrow3['rlitmale']."</td>
			        <td>".$stblrow3['rlitfemale']."</td>
			        <td>".$stblrow3['rlitmale']+$stblrow3['rlitfemale']."</td>

			        <td>".$stblrow2['rlidmale']."</td>
			        <td>".$stblrow2['rlidfemale']."</td>
			        <td>".$stblrow2['rlidmale']+$stblrow2['rlidfemale']."</td>
			        <td>".$stblrow3['rlidmale']."</td>
			        <td>".$stblrow3['rlidfemale']."</td>
			        <td>".$stblrow3['rlidmale']+$stblrow3['rlidfemale']."</td>";
		  echo "</tr>";
		}
	  }
	  echo "</table>";
?>