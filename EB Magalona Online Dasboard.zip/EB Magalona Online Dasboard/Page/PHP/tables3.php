<?php
	$minnutri1 = "SELECT * FROM `{$tabName}` WHERE Groups = '$grouped' AND Year = $chosenTime ORDER BY Year LIMIT 1";
	$maxnutri1 = "SELECT * FROM `{$tabName}` WHERE Groups = '$grouped' AND Year = $chosenTime ORDER BY Year DESC LIMIT 1";
	$nutriresmn = mysqli_query($conn3, $minnutri1);
	$nutriresmx = mysqli_query($conn3, $maxnutri1);
	
	if (mysqli_num_rows($nutriresmx) > 0) {
		$mnnutrirow = mysqli_fetch_array($nutriresmn);
		$mxnutrirow = mysqli_fetch_array($nutriresmx);
		$mnnutri = $mnnutrirow['Year'];
		$mxnutri = $mxnutrirow['Year'];
	}
	else{
		$mnnutri = " ";
		$mxnutri = " ";
	}
?>