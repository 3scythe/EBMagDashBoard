<?php
	include "connect.php";
 	
//Pie Chart

	//Elementary
	$data1a = "SELECT  Male, Female, School FROM `{$tabName}` WHERE Groups = 'Elementary' AND Year = '$max' ORDER BY School";
	$dataresult1a = mysqli_query($conn3, $data1a);

	if (mysqli_num_rows($dataresult1a) > 0) {
		$total1a = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` Where Groups = 'Elementary' AND Year = '$max'";
		$totalresult1a = mysqli_query($conn3, $total1a);
		$totaldata1a = mysqli_fetch_assoc($totalresult1a);

		$totalGross1a = $totaldata1a['tm']+$totaldata1a['tf'];
		
		$dataPoints1A = array();
		while($dataPoint1a = mysqli_fetch_array($dataresult1a)) {   
		  array_push($dataPoints1A, array("label" => $dataPoint1a['School'], "y" => (($dataPoint1a['Male']+$dataPoint1a['Female'])/$totalGross1a)*100));
		}

		$dataPoints1B = array(
			array("label" => "Female", "y" => ($totaldata1a['tf']/$totalGross1a)*100),
			array("label" => "Male", "y" => ($totaldata1a['tm']/$totalGross1a)*100));
	}
	else {
		$dataPoints1A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1B = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	

	//Highschool 

	$data1ah = "SELECT  Male, Female, School FROM `{$tabName}` WHERE Groups = 'Highschool' AND Year = '$maxh' ORDER BY School";
	$dataresult1ah = mysqli_query($conn3, $data1ah);

	if (mysqli_num_rows($dataresult1ah) > 0) {
		$total1ah = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` Where Groups = 'Highschool' AND Year = '$maxh'";
		$totalresult1ah = mysqli_query($conn3, $total1ah);
		$totaldata1ah = mysqli_fetch_assoc($totalresult1ah);

		$totalGross1ah = $totaldata1ah['tm']+$totaldata1ah['tf'];

		$dataPoints1Ah = array();
		while($dataPoint1ah = mysqli_fetch_array($dataresult1ah)) {   
		  array_push($dataPoints1Ah, array("label" => $dataPoint1ah['School'], "y" => (($dataPoint1ah['Male']+$dataPoint1ah['Female'])/$totalGross1ah)*100));
		}

		$dataPoints1Bh = array(
			array("label" => "Female", "y" => ($totaldata1ah['tf']/$totalGross1ah)*100),
			array("label" => "Male", "y" => ($totaldata1ah['tm']/$totalGross1ah)*100));
	}
	else {
		$dataPoints1Ah = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Bh = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	

	//Private

	$data1ap = "SELECT  Male, Female, School FROM `{$tabName}` WHERE Groups = 'Private' AND Year = '$maxp' ORDER BY School";
	$dataresult1ap = mysqli_query($conn3, $data1ap);
	if (mysqli_num_rows($dataresult1ap) > 0) {
		$total1ap = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` Where Groups = 'Private' AND Year = '$maxp'";
		$totalresult1ap = mysqli_query($conn3, $total1ap);
		$totaldata1ap = mysqli_fetch_assoc($totalresult1ap);

		$totalGross1ap = $totaldata1ap['tm']+$totaldata1ap['tf'];

		$dataPoints1Ap = array();
		while($dataPoint1ap = mysqli_fetch_array($dataresult1ap)) {   
		  array_push($dataPoints1Ap, array("label" => $dataPoint1ap['School'], "y" => (($dataPoint1ap['Male']+$dataPoint1ap['Female'])/$totalGross1ap)*100));
		}

		$dataPoints1Bp = array(
			array("label" => "Female", "y" => ($totaldata1ap['tf']/$totalGross1ap)*100),
			array("label" => "Male", "y" => ($totaldata1ap['tm']/$totalGross1ap)*100));
	}
	else {
		$dataPoints1Ap = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1Bp = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

//Bar Chart

	//Elementary
	$data1c1 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary' AND Year <= '$max' GROUP BY Year";
	$dataresult1c1 = mysqli_query($conn3, $data1c1);
	if (mysqli_num_rows($dataresult1c1) > 0) {
		$dataPoints1C1 = array();
		while($dataPoint1c1 = mysqli_fetch_array($dataresult1c1)) {   
		  array_push($dataPoints1C1, array("y" => $dataPoint1c1['m']+$dataPoint1c1['f'], "label" => $dataPoint1c1['Year']));
		}

		$data1c2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary' AND Year <= '$max' GROUP BY Year";
		$dataresult1c2 = mysqli_query($conn3, $data1c2);

		$dataPoints1C2 = array();
		while($dataPoint1c2 = mysqli_fetch_array($dataresult1c2)) {   
		  array_push($dataPoints1C2, array("y" => $dataPoint1c2['m'], "label" => $dataPoint1c2['Year']));
		}

		$data1c3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Elementary'AND Year <= '$max'  GROUP BY Year";
		$dataresult1c3 = mysqli_query($conn3, $data1c3);

		$dataPoints1C3 = array();
		while($dataPoint1c3 = mysqli_fetch_array($dataresult1c3)) {   
		  array_push($dataPoints1C3, array("y" => $dataPoint1c3['f'], "label" => $dataPoint1c3['Year']));
		}
	}
	else {
		$dataPoints1C1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	//HighSchool

	$data1c1h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
	$dataresult1c1h = mysqli_query($conn3, $data1c1h);
	if (mysqli_num_rows($dataresult1c1h) > 0) {
		$dataPoints1C1h = array();
		while($dataPoint1c1h = mysqli_fetch_array($dataresult1c1h)) {   
		  array_push($dataPoints1C1h, array("y" => $dataPoint1c1h['m']+$dataPoint1c1h['f'], "label" => $dataPoint1c1h['Year']));
		}

		$data1c2h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
		$dataresult1c2h = mysqli_query($conn3, $data1c2h);

		$dataPoints1C2h = array();
		while($dataPoint1c2h = mysqli_fetch_array($dataresult1c2h)) {   
		  array_push($dataPoints1C2h, array("y" => $dataPoint1c2h['m'], "label" => $dataPoint1c2h['Year']));
		}

		$data1c3h = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Highschool' AND Year <= '$maxh' GROUP BY Year";
		$dataresult1c3h = mysqli_query($conn3, $data1c3h);

		$dataPoints1C3h = array();
		while($dataPoint1c3h = mysqli_fetch_array($dataresult1c3h)) {   
		  array_push($dataPoints1C3h, array("y" => $dataPoint1c3h['f'], "label" => $dataPoint1c3h['Year']));
		}
	}
	else {
		$dataPoints1C1h = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2h = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3h = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	//Ptivate

	$data1c1p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
	$dataresult1c1p = mysqli_query($conn3, $data1c1p);
	if (mysqli_num_rows($dataresult1c1p) > 0) {
		$dataPoints1C1p = array();
		while($dataPoint1c1p = mysqli_fetch_array($dataresult1c1p)) {   
		  array_push($dataPoints1C1p, array("y" => $dataPoint1c1p['m']+$dataPoint1c1p['f'], "label" => $dataPoint1c1p['Year']));
		}

		$data1c2p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
		$dataresult1c2p = mysqli_query($conn3, $data1c2p);

		$dataPoints1C2p = array();
		while($dataPoint1c2p = mysqli_fetch_array($dataresult1c2p)) {   
		  array_push($dataPoints1C2p, array("y" => $dataPoint1c2p['m'], "label" => $dataPoint1c2p['Year']));
		}

		$data1c3p = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM `{$tabName}` Where Groups = 'Private' AND Year <= '$maxp' GROUP BY Year";
		$dataresult1c3p = mysqli_query($conn3, $data1c3p);

		$dataPoints1C3p = array();
		while($dataPoint1c3p = mysqli_fetch_array($dataresult1c3p)) {   
		  array_push($dataPoints1C3p, array("y" => $dataPoint1c3p['f'], "label" => $dataPoint1c3p['Year']));
		}
	}
	else {
		$dataPoints1C1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C2p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints1C3p = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
?>