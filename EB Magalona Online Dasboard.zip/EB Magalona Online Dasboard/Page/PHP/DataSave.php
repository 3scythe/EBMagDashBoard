<?php
include "connect.php";

	if (isset($_POST['SG'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO grossenrollrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SN'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO netenrollrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SD'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO droprate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SS'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO survivalrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SF'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO failurerate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SC'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO completionrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SRT'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO retentionrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SGD'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO Structuregraduationrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SPR'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO promotionrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['SRP'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO repeatitionrate (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}

	if (isset($_POST['S4P'])) {
		$schol = $_POST['Schools'];
		$yrs = $_POST['date'];
		$ml = $_POST['MaleTab'];
  		$fl = $_POST['FemaleTab'];

  		if ($ml != "" && $fl != "") { 
  			$sqlinsert = "INSERT INTO distric4ps (School, Male, Female, Year, Groups) VALUES ('$schol','$ml','$fl','$yrs', 'Elementary');";
  			$insResult = mysqli_query($conn3, $sqlinsert);
  			if ($insResult) {
		      session_start();
		      $_SESSION['display'] = "Page1";
		      header('location: ../ElemSchoolD.php');
		    }
  		}
  		else{
  			echo '<script>alert("Empty Fields")</script>';
  			header('location: ../ElemSchoolD.php');
  		}
	}
?>