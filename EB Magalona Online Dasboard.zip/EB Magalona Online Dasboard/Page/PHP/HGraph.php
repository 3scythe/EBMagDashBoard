<?php
	include "connect.php";
//gross
	//Bar
	$barDataG = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataGRes = mysqli_query($conn3, $barDataG);
	if (mysqli_num_rows($barDataGRes) > 0) {

		$dataPointsG1 = array();
		while($barDatas = mysqli_fetch_array($barDataGRes)) {   
		  array_push($dataPointsG1, array("y" => $barDatas['m']+$barDatas['f'], "label" => $barDatas['Year']));
		}

		$barDataG2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataGRes2 = mysqli_query($conn3, $barDataG2);

		$dataPointsG2 = array();
		while($barDatas2 = mysqli_fetch_array($barDataGRes2)) {   
		  array_push($dataPointsG2, array("y" => $barDatas2['m'], "label" => $barDatas2['Year']));
		}

		$barDataG3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataGRes3 = mysqli_query($conn3, $barDataG3);

		$dataPointsG3 = array();
		while($barDatas3 = mysqli_fetch_array($barDataGRes3)) {   
		  array_push($dataPointsG3, array("y" => $barDatas3['f'], "label" => $barDatas3['Year']));
		}
	}
	else {
		$dataPointsG1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Pie
	$PieDataG = "SELECT * FROM grossenrollrate WHERE School = '$School' AND Year = '$chosenTime' ";
	$PieDataGRest = mysqli_query($conn3, $PieDataG);

	if (mysqli_num_rows($PieDataGRest) > 0) {

		$PieTotalG = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM grossenrollrate Where Groups = 'Highschool' AND Year = '$chosenTime'";
		$PieTotalGRest = mysqli_query($conn3, $PieTotalG);
		$PieTotalData = mysqli_fetch_assoc($PieTotalGRest);

		$PieTotal = $PieTotalData['tm']+$PieTotalData['tf'];
		
		$PieDataG1 =  mysqli_fetch_assoc($PieDataGRest);
		$dataPointsG1p = array(
			array("label" => $PieDataG1['School'], "y" => (($PieDataG1['Male']+$PieDataG1['Female'])/$PieTotal)*100),
			array("label" => " ", "y" => (($PieTotal-($PieDataG1['Male']+$PieDataG1['Female']))/$PieTotal)*100)
		);

		$dataPointsG1d = array(
			array("label" => "Female", "y" => ($PieDataG1['Female']/($PieDataG1['Female']+$PieDataG1['Male']))*100),
			array("label" => "Male", "y" => ($PieDataG1['Male']/($PieDataG1['Female']+$PieDataG1['Male']))*100));
	}
	else {
		$dataPointsG1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG1d = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Doughnut
//Net
	$barDataN = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataNRes = mysqli_query($conn3, $barDataN);
	if (mysqli_num_rows($barDataNRes) > 0) {

		$dataPointsN1 = array();
		while($barNDatas = mysqli_fetch_array($barDataNRes)) {   
		  array_push($dataPointsN1, array("y" => $barNDatas['m']+$barNDatas['f'], "label" => $barNDatas['Year']));
		}

		$barDataN2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataNRes2 = mysqli_query($conn3, $barDataN2);

		$dataPointsN2 = array();
		while($barNDatas2 = mysqli_fetch_array($barDataNRes2)) {   
		  array_push($dataPointsN2, array("y" => $barNDatas2['m'], "label" => $barNDatas2['Year']));
		}

		$barDataN3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataNRes3 = mysqli_query($conn3, $barDataN3);

		$dataPointsN3 = array();
		while($barNDatas3 = mysqli_fetch_array($barDataNRes3)) {   
		  array_push($dataPointsN3, array("y" => $barNDatas3['f'], "label" => $barNDatas3['Year']));
		}
	}
	else {
		$dataPointsN1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsN2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsN3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Drop
	$barDataD = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataDRes = mysqli_query($conn3, $barDataD);
	if (mysqli_num_rows($barDataDRes) > 0) {

		$dataPointsD1 = array();
		while($barDDatas = mysqli_fetch_array($barDataDRes)) {   
		  array_push($dataPointsD1, array("y" => $barDDatas['m']+$barDDatas['f'], "label" => $barDDatas['Year']));
		}

		$barDataD2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataDRes2 = mysqli_query($conn3, $barDataD2);

		$dataPointsD2 = array();
		while($barDDatas2 = mysqli_fetch_array($barDataDRes2)) {   
		  array_push($dataPointsD2, array("y" => $barDDatas2['m'], "label" => $barDDatas2['Year']));
		}

		$barDataD3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataDRes3 = mysqli_query($conn3, $barDataD3);

		$dataPointsD3 = array();
		while($barDDatas3 = mysqli_fetch_array($barDataDRes3)) {   
		  array_push($dataPointsD3, array("y" => $barDDatas3['f'], "label" => $barDDatas3['Year']));
		}
	}
	else {
		$dataPointsD1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsD2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsD3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Surv
	$barDataS = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataSRes = mysqli_query($conn3, $barDataS);
	if (mysqli_num_rows($barDataSRes) > 0) {

		$dataPointsS1 = array();
		while($barSDatas = mysqli_fetch_array($barDataSRes)) {   
		  array_push($dataPointsS1, array("y" => $barSDatas['m']+$barSDatas['f'], "label" => $barSDatas['Year']));
		}

		$barDataS2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataSRes2 = mysqli_query($conn3, $barDataS2);

		$dataPointsS2 = array();
		while($barSDatas2 = mysqli_fetch_array($barDataSRes2)) {   
		  array_push($dataPointsS2, array("y" => $barSDatas2['m'], "label" => $barSDatas2['Year']));
		}

		$barDataS3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataSRes3 = mysqli_query($conn3, $barDataS3);

		$dataPointsS3 = array();
		while($barSDatas3 = mysqli_fetch_array($barDataSRes3)) {   
		  array_push($dataPointsS3, array("y" => $barSDatas3['f'], "label" => $barSDatas3['Year']));
		}
	}
	else {
		$dataPointsS1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsS2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsS3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Fail
	$barDataF = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataFRes = mysqli_query($conn3, $barDataF);
	if (mysqli_num_rows($barDataFRes) > 0) {

		$dataPointsF1 = array();
		while($barFDatas = mysqli_fetch_array($barDataFRes)) {   
		  array_push($dataPointsF1, array("y" => $barFDatas['m']+$barFDatas['f'], "label" => $barFDatas['Year']));
		}

		$barDataF2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataFRes2 = mysqli_query($conn3, $barDataF2);

		$dataPointsF2 = array();
		while($barFDatas2 = mysqli_fetch_array($barDataFRes2)) {   
		  array_push($dataPointsF2, array("y" => $barFDatas2['m'], "label" => $barFDatas2['Year']));
		}

		$barDataF3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataFRes3 = mysqli_query($conn3, $barDataF3);

		$dataPointsF3 = array();
		while($barFDatas3 = mysqli_fetch_array($barDataFRes3)) {   
		  array_push($dataPointsF3, array("y" => $barFDatas3['f'], "label" => $barFDatas3['Year']));
		}
	}
	else {
		$dataPointsF1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsF2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsF3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Comp
	$barDataC = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataCRes = mysqli_query($conn3, $barDataC);
	if (mysqli_num_rows($barDataCRes) > 0) {

		$dataPointsC1 = array();
		while($barCDatas = mysqli_fetch_array($barDataCRes)) {   
		  array_push($dataPointsC1, array("y" => $barCDatas['m']+$barCDatas['f'], "label" => $barCDatas['Year']));
		}

		$barDataC2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataCRes2 = mysqli_query($conn3, $barDataC2);

		$dataPointsC2 = array();
		while($barCDatas2 = mysqli_fetch_array($barDataCRes2)) {   
		  array_push($dataPointsC2, array("y" => $barCDatas2['m'], "label" => $barCDatas2['Year']));
		}

		$barDataC3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataCRes3 = mysqli_query($conn3, $barDataC3);

		$dataPointsC3 = array();
		while($barCDatas3 = mysqli_fetch_array($barDataCRes3)) {   
		  array_push($dataPointsC3, array("y" => $barCDatas3['f'], "label" => $barCDatas3['Year']));
		}
	}
	else {
		$dataPointsC1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsC2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsC3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Ret
	$barDataRT = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataRTRes = mysqli_query($conn3, $barDataRT);
	if (mysqli_num_rows($barDataRTRes) > 0) {

		$dataPointsRT1 = array();
		while($barRTDatas = mysqli_fetch_array($barDataRTRes)) {   
		  array_push($dataPointsRT1, array("y" => $barRTDatas['m']+$barRTDatas['f'], "label" => $barRTDatas['Year']));
		}

		$barDataRT2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataRTRes2 = mysqli_query($conn3, $barDataRT2);

		$dataPointsRT2 = array();
		while($barRTDatas2 = mysqli_fetch_array($barDataRTRes2)) {   
		  array_push($dataPointsRT2, array("y" => $barRTDatas2['m'], "label" => $barRTDatas2['Year']));
		}

		$barDataRT3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataRTRes3 = mysqli_query($conn3, $barDataRT3);

		$dataPointsRT3 = array();
		while($barRTDatas3 = mysqli_fetch_array($barDataRTRes3)) {   
		  array_push($dataPointsRT3, array("y" => $barRTDatas3['f'], "label" => $barRTDatas3['Year']));
		}
	}
	else {
		$dataPointsRT1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRT2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRT3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Grad
	$barDataGD = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataGDRes = mysqli_query($conn3, $barDataGD);
	if (mysqli_num_rows($barDataGDRes) > 0) {

		$dataPointsGD1 = array();
		while($barGDDatas = mysqli_fetch_array($barDataGDRes)) {   
		  array_push($dataPointsGD1, array("y" => $barGDDatas['m']+$barGDDatas['f'], "label" => $barGDDatas['Year']));
		}

		$barDataGD2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataGDRes2 = mysqli_query($conn3, $barDataGD2);

		$dataPointsGD2 = array();
		while($barGDDatas2 = mysqli_fetch_array($barDataGDRes2)) {   
		  array_push($dataPointsGD2, array("y" => $barGDDatas2['m'], "label" => $barGDDatas2['Year']));
		}

		$barDataGD3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataGDRes3 = mysqli_query($conn3, $barDataGD3);

		$dataPointsGD3 = array();
		while($barGDDatas3 = mysqli_fetch_array($barDataGDRes3)) {   
		  array_push($dataPointsGD3, array("y" => $barGDDatas3['f'], "label" => $barGDDatas3['Year']));
		}
	}
	else {
		$dataPointsGD1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsGD2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsGD3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Pro
	$barDataPR = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataPRRes = mysqli_query($conn3, $barDataPR);
	if (mysqli_num_rows($barDataPRRes) > 0) {

		$dataPointsPR1 = array();
		while($barPRDatas = mysqli_fetch_array($barDataPRRes)) {   
		  array_push($dataPointsPR1, array("y" => $barPRDatas['m']+$barPRDatas['f'], "label" => $barPRDatas['Year']));
		}

		$barDataPR2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataPRRes2 = mysqli_query($conn3, $barDataPR2);

		$dataPointsPR2 = array();
		while($barPRDatas2 = mysqli_fetch_array($barDataPRRes2)) {   
		  array_push($dataPointsPR2, array("y" => $barPRDatas2['m'], "label" => $barPRDatas2['Year']));
		}

		$barDataPR3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataPRRes3 = mysqli_query($conn3, $barDataPR3);

		$dataPointsPR3 = array();
		while($barPRDatas3 = mysqli_fetch_array($barDataPRRes3)) {   
		  array_push($dataPointsPR3, array("y" => $barPRDatas3['f'], "label" => $barPRDatas3['Year']));
		}
	}
	else {
		$dataPointsPR1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsPR2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsPR3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Rep
	$barDataRP = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataRPRes = mysqli_query($conn3, $barDataRP);
	if (mysqli_num_rows($barDataRPRes) > 0) {

		$dataPointsRP1 = array();
		while($barRPDatas = mysqli_fetch_array($barDataRPRes)) {   
		  array_push($dataPointsRP1, array("y" => $barRPDatas['m']+$barRPDatas['f'], "label" => $barRPDatas['Year']));
		}

		$barDataRP2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataRPRes2 = mysqli_query($conn3, $barDataRP2);

		$dataPointsRP2 = array();
		while($barRPDatas2 = mysqli_fetch_array($barDataRPRes2)) {   
		  array_push($dataPointsRP2, array("y" => $barRPDatas2['m'], "label" => $barRPDatas2['Year']));
		}

		$barDataRP3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataRPRes3 = mysqli_query($conn3, $barDataRP3);

		$dataPointsRP3 = array();
		while($barRPDatas3 = mysqli_fetch_array($barDataRPRes3)) {   
		  array_push($dataPointsRP3, array("y" => $barRPDatas3['f'], "label" => $barRPDatas3['Year']));
		}
	}
	else {
		$dataPointsRP1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRP2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRP3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//EO3

 	$EO3Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$EO3DataRest = mysqli_query($conn3, $EO3Data);

	if (mysqli_num_rows($EO3DataRest) > 0) {
		$EO3TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Pre'";
		$EO3TotalDataRest = mysqli_query($conn3, $EO3TotalData);
		$EO3TotalDatas = mysqli_fetch_assoc($EO3TotalDataRest);

		$EO3Totals = $EO3TotalDatas['ertm']+$EO3TotalDatas['ertf'];

		$dataPointsEO3A = array(
			array("label" => "Frustration", "y" => (($EO3TotalDatas['fttm']+$EO3TotalDatas['fttf'])/$EO3Totals)*100),
			array("label" => "Instructional", "y" => (($EO3TotalDatas['ittm']+$EO3TotalDatas['ittf'])/$EO3Totals)*100),
			array("label" => "Idependent", "y" => (($EO3TotalDatas['idtm']+$EO3TotalDatas['idtf'])/$EO3Totals)*100),
			array("label" => "Non-Reader", "y" => (($EO3TotalDatas['nrtm']+$EO3TotalDatas['nrtf'])/$EO3Totals)*100)
		);

		$dataPointsEO3Aa = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas['fttm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas['ittm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas['idtm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas['nrtm']/$EO3TotalDatas['ertm'])*100)
		);

		$dataPointsEO3Ab = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas['fttf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas['ittf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas['idtf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas['nrtf']/$EO3TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsEO3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$EO3Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$EO3DataRest2 = mysqli_query($conn3, $EO3Data2);

	if (mysqli_num_rows($EO3DataRest2) > 0) {
		$EO3TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Post'";
		$EO3TotalDataRest2 = mysqli_query($conn3, $EO3TotalData2);
		$EO3TotalDatas2 = mysqli_fetch_assoc($EO3TotalDataRest2);

		$EO3Totals2 = $EO3TotalDatas2['ertm']+$EO3TotalDatas2['ertf'];

		$dataPointsEO3A2 = array(
			array("label" => "Frustration", "y" => (($EO3TotalDatas2['fttm']+$EO3TotalDatas2['fttf'])/$EO3Totals2)*100),
			array("label" => "Instructional", "y" => (($EO3TotalDatas2['ittm']+$EO3TotalDatas2['ittf'])/$EO3Totals2)*100),
			array("label" => "Idependent", "y" => (($EO3TotalDatas2['idtm']+$EO3TotalDatas2['idtf'])/$EO3Totals2)*100),
			array("label" => "Non-Reader", "y" => (($EO3TotalDatas2['nrtm']+$EO3TotalDatas2['nrtf'])/$EO3Totals2)*100)
		);

		$dataPointsEO3Aa2 = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas2['fttm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas2['ittm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas2['idtm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas2['nrtm']/$EO3TotalDatas2['ertm'])*100)
		);

		$dataPointsEO3Ab2 = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas2['fttf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas2['ittf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas2['idtf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas2['nrtf']/$EO3TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsEO3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//ES3

	$ESData3 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$ESData3Rest = mysqli_query($conn3, $ESData3);

	if (mysqli_num_rows($ESData3Rest) > 0) {
		$ESTotalData3 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Pre'";
		$ESTotalData3Rest = mysqli_query($conn3, $ESTotalData3);
		$ES3PreDatas = mysqli_fetch_assoc($ESTotalData3Rest);

		$ES3TotalDatas = $ES3PreDatas['ertm']+$ES3PreDatas['ertf'];

		if ($ES3TotalDatas > 0) {

			$dataPointsES3A = array(
				array("label" => "Slow", "y" => (($ES3PreDatas['sstm']+$ES3PreDatas['sstf'])/$ES3TotalDatas)*100),
				array("label" => "Average", "y" => (($ES3PreDatas['satm']+$ES3PreDatas['satf'])/$ES3TotalDatas)*100),
				array("label" => "Fast", "y" => (($ES3PreDatas['sftm']+$ES3PreDatas['sftf'])/$ES3TotalDatas)*100)
			);

			$dataPointsES3B = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas['cfttm']+$ES3PreDatas['cfttf'])/$ES3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas['cittm']+$ES3PreDatas['cittf'])/$ES3TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas['cidtm']+$ES3PreDatas['cidtf'])/$ES3TotalDatas)*100)
			);

			$dataPointsES3C = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas['rlfttm']+$ES3PreDatas['rlfttf'])/$ES3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas['rlittm']+$ES3PreDatas['rlittf'])/$ES3TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas['rlidtm']+$ES3PreDatas['rlidtf'])/$ES3TotalDatas)*100)
			);
		}
		else{
			$dataPointsES3A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES3C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES3PreDatas['ertm'] > 0) {

			$dataPointsES3Aa = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['sstm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['satm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['sftm']/$ES3PreDatas['ertm'])*100)
			);

			$dataPointsES3Ba = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['cfttm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['cittm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['cidtm']/$ES3PreDatas['ertm'])*100)
			);

			$dataPointsES3Ca = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['rlfttm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['rlittm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['rlidtm']/$ES3PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsES3Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES3PreDatas['ertf'] > 0) {

			$dataPointsES3Ab = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['sstf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['satf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['sftf']/$ES3PreDatas['ertf'])*100)
			);

			$dataPointsES3Bb = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['cfttf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['cittf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['cidtf']/$ES3PreDatas['ertf'])*100)
			);

			$dataPointsES3Cb = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['rlfttf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['rlittf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['rlidtf']/$ES3PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsES3Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$ESData32 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$ESData3Rest2 = mysqli_query($conn3, $ESData32);

	if (mysqli_num_rows($ESData3Rest2) > 0) {
		$ESTotalData32 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'English' AND pORp = 'Post'";
		$ESTotalData3Rest2 = mysqli_query($conn3, $ESTotalData32);
		$ES3PreDatas2 = mysqli_fetch_assoc($ESTotalData3Rest2);

		$ES3TotalDatas2 = $ES3PreDatas2['ertm']+$ES3PreDatas2['ertf'];

		if ($ES3TotalDatas2 > 0) {

			$dataPointsES3A2 = array(
				array("label" => "Slow", "y" => (($ES3PreDatas2['sstm']+$ES3PreDatas2['sstf'])/$ES3TotalDatas2)*100),
				array("label" => "Average", "y" => (($ES3PreDatas2['satm']+$ES3PreDatas2['satf'])/$ES3TotalDatas2)*100),
				array("label" => "Fast", "y" => (($ES3PreDatas2['sftm']+$ES3PreDatas2['sftf'])/$ES3TotalDatas2)*100)
			);

			$dataPointsES3B2 = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas2['cfttm']+$ES3PreDatas2['cfttf'])/$ES3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas2['cittm']+$ES3PreDatas2['cittf'])/$ES3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas2['cidtm']+$ES3PreDatas2['cidtf'])/$ES3TotalDatas2)*100)
			);

			$dataPointsES3C2 = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas2['rlfttm']+$ES3PreDatas2['rlfttf'])/$ES3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas2['rlittm']+$ES3PreDatas2['rlittf'])/$ES3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas2['rlidtm']+$ES3PreDatas2['rlidtf'])/$ES3TotalDatas2)*100)
			);
		}
		else{
			$dataPointsES3A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES3C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES3PreDatas2['ertm'] > 0) {

			$dataPointsES3Aa2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['sstm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['satm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['sftm']/$ES3PreDatas2['ertm'])*100)
			);

			$dataPointsES3Ba2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['cfttm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['cittm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['cidtm']/$ES3PreDatas2['ertm'])*100)
			);

			$dataPointsES3Ca2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['rlfttm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['rlittm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['rlidtm']/$ES3PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsES3Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES3PreDatas2['ertf'] > 0) {

			$dataPointsES3Ab2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['sstf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['satf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['sftf']/$ES3PreDatas2['ertf'])*100)
			);

			$dataPointsES3Bb2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['cfttf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['cittf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['cidtf']/$ES3PreDatas2['ertf'])*100)
			);

			$dataPointsES3Cb2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['rlfttf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['rlittf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['rlidtf']/$ES3PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsES3Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FO3

 	$FO3Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FO3DataRest = mysqli_query($conn3, $FO3Data);

	if (mysqli_num_rows($FO3DataRest) > 0) {
		$FO3TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FO3TotalDataRest = mysqli_query($conn3, $FO3TotalData);
		$FO3TotalDatas = mysqli_fetch_assoc($FO3TotalDataRest);

		$FO3Totals = $FO3TotalDatas['ertm']+$FO3TotalDatas['ertf'];

		$dataPointsFO3A = array(
			array("label" => "Frustration", "y" => (($FO3TotalDatas['fttm']+$FO3TotalDatas['fttf'])/$FO3Totals)*100),
			array("label" => "Instructional", "y" => (($FO3TotalDatas['ittm']+$FO3TotalDatas['ittf'])/$FO3Totals)*100),
			array("label" => "Idependent", "y" => (($FO3TotalDatas['idtm']+$FO3TotalDatas['idtf'])/$FO3Totals)*100),
			array("label" => "Non-Reader", "y" => (($FO3TotalDatas['nrtm']+$FO3TotalDatas['nrtf'])/$FO3Totals)*100)
		);

		$dataPointsFO3Aa = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas['fttm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas['ittm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas['idtm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas['nrtm']/$FO3TotalDatas['ertm'])*100)
		);

		$dataPointsFO3Ab = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas['fttf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas['ittf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas['idtf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas['nrtf']/$FO3TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsFO3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FO3Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FO3DataRest2 = mysqli_query($conn3, $FO3Data2);

	if (mysqli_num_rows($FO3DataRest2) > 0) {
		$FO3TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Post'";
		$FO3TotalDataRest2 = mysqli_query($conn3, $FO3TotalData2);
		$FO3TotalDatas2 = mysqli_fetch_assoc($FO3TotalDataRest2);

		$FO3Totals2 = $FO3TotalDatas2['ertm']+$FO3TotalDatas2['ertf'];

		$dataPointsFO3A2 = array(
			array("label" => "Frustration", "y" => (($FO3TotalDatas2['fttm']+$FO3TotalDatas2['fttf'])/$FO3Totals2)*100),
			array("label" => "Instructional", "y" => (($FO3TotalDatas2['ittm']+$FO3TotalDatas2['ittf'])/$FO3Totals2)*100),
			array("label" => "Idependent", "y" => (($FO3TotalDatas2['idtm']+$FO3TotalDatas2['idtf'])/$FO3Totals2)*100),
			array("label" => "Non-Reader", "y" => (($FO3TotalDatas2['nrtm']+$FO3TotalDatas2['nrtf'])/$FO3Totals2)*100)
		);

		$dataPointsFO3Aa2 = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas2['fttm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas2['ittm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas2['idtm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas2['nrtm']/$FO3TotalDatas2['ertm'])*100)
		);

		$dataPointsFO3Ab2 = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas2['fttf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas2['ittf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas2['idtf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas2['nrtf']/$FO3TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsFO3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FS3

	$FSData3 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FSData3Rest = mysqli_query($conn3, $FSData3);

	if (mysqli_num_rows($FSData3Rest) > 0) {
		$FSTotalData3 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FSTotalData3Rest = mysqli_query($conn3, $FSTotalData3);
		$FS3PreDatas = mysqli_fetch_assoc($FSTotalData3Rest);

		$FS3TotalDatas = $FS3PreDatas['ertm']+$FS3PreDatas['ertf'];

		if ($FS3TotalDatas > 0) {

			$dataPointsFS3A = array(
				array("label" => "Slow", "y" => (($FS3PreDatas['sstm']+$FS3PreDatas['sstf'])/$FS3TotalDatas)*100),
				array("label" => "Average", "y" => (($FS3PreDatas['satm']+$FS3PreDatas['satf'])/$FS3TotalDatas)*100),
				array("label" => "Fast", "y" => (($FS3PreDatas['sftm']+$FS3PreDatas['sftf'])/$FS3TotalDatas)*100)
			);

			$dataPointsFS3B = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas['cfttm']+$FS3PreDatas['cfttf'])/$FS3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas['cittm']+$FS3PreDatas['cittf'])/$FS3TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas['cidtm']+$FS3PreDatas['cidtf'])/$FS3TotalDatas)*100)
			);

			$dataPointsFS3C = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas['rlfttm']+$FS3PreDatas['rlfttf'])/$FS3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas['rlittm']+$FS3PreDatas['rlittf'])/$FS3TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas['rlidtm']+$FS3PreDatas['rlidtf'])/$FS3TotalDatas)*100)
			);
		}
		else{
			$dataPointsFS3A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS3C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS3PreDatas['ertm'] > 0) {

			$dataPointsFS3Aa = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['sstm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['satm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['sftm']/$FS3PreDatas['ertm'])*100)
			);

			$dataPointsFS3Ba = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['cfttm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['cittm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['cidtm']/$FS3PreDatas['ertm'])*100)
			);

			$dataPointsFS3Ca = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['rlfttm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['rlittm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['rlidtm']/$FS3PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsFS3Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS3PreDatas['ertf'] > 0) {

			$dataPointsFS3Ab = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['sstf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['satf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['sftf']/$FS3PreDatas['ertf'])*100)
			);

			$dataPointsFS3Bb = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['cfttf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['cittf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['cidtf']/$FS3PreDatas['ertf'])*100)
			);

			$dataPointsFS3Cb = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['rlfttf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['rlittf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['rlidtf']/$FS3PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsFS3Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FSData32 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FSData3Rest2 = mysqli_query($conn3, $FSData32);

	if (mysqli_num_rows($FSData3Rest2) > 0) {
		$FSTotalData32 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 7 AND subject = 'Filipino' AND pORp = 'Post'";
		$FSTotalData3Rest2 = mysqli_query($conn3, $FSTotalData32);
		$FS3PreDatas2 = mysqli_fetch_assoc($FSTotalData3Rest2);

		$FS3TotalDatas2 = $FS3PreDatas2['ertm']+$FS3PreDatas2['ertf'];

		if ($FS3TotalDatas2 > 0) {

			$dataPointsFS3A2 = array(
				array("label" => "Slow", "y" => (($FS3PreDatas2['sstm']+$FS3PreDatas2['sstf'])/$FS3TotalDatas2)*100),
				array("label" => "Average", "y" => (($FS3PreDatas2['satm']+$FS3PreDatas2['satf'])/$FS3TotalDatas2)*100),
				array("label" => "Fast", "y" => (($FS3PreDatas2['sftm']+$FS3PreDatas2['sftf'])/$FS3TotalDatas2)*100)
			);

			$dataPointsFS3B2 = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas2['cfttm']+$FS3PreDatas2['cfttf'])/$FS3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas2['cittm']+$FS3PreDatas2['cittf'])/$FS3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas2['cidtm']+$FS3PreDatas2['cidtf'])/$FS3TotalDatas2)*100)
			);

			$dataPointsFS3C2 = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas2['rlfttm']+$FS3PreDatas2['rlfttf'])/$FS3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas2['rlittm']+$FS3PreDatas2['rlittf'])/$FS3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas2['rlidtm']+$FS3PreDatas2['rlidtf'])/$FS3TotalDatas2)*100)
			);
		}
		else{
			$dataPointsFS3A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS3C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS3PreDatas2['ertm'] > 0) {

			$dataPointsFS3Aa2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['sstm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['satm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['sftm']/$FS3PreDatas2['ertm'])*100)
			);

			$dataPointsFS3Ba2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['cfttm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['cittm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['cidtm']/$FS3PreDatas2['ertm'])*100)
			);

			$dataPointsFS3Ca2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['rlfttm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['rlittm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['rlidtm']/$FS3PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsFS3Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS3PreDatas2['ertf'] > 0) {

			$dataPointsFS3Ab2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['sstf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['satf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['sftf']/$FS3PreDatas2['ertf'])*100)
			);

			$dataPointsFS3Bb2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['cfttf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['cittf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['cidtf']/$FS3PreDatas2['ertf'])*100)
			);

			$dataPointsFS3Cb2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['rlfttf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['rlittf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['rlidtf']/$FS3PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsFS3Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//4p
	//Bar
	$barData4P = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School' AND Year <= '$chosenTime4' GROUP BY Year";
	$barData4PRes = mysqli_query($conn3, $barData4P);
	if (mysqli_num_rows($barData4PRes) > 0) {

		$dataPoints4P1 = array();
		while($bar4PDatas = mysqli_fetch_array($barData4PRes)) {   
		  array_push($dataPoints4P1, array("y" => $bar4PDatas['m']+$bar4PDatas['f'], "label" => $bar4PDatas['Year']));
		}

		$barData4P2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School' AND Year <= '$chosenTime4' GROUP BY Year";
		$barData4PRes2 = mysqli_query($conn3, $barData4P2);

		$dataPoints4P2 = array();
		while($bar4PDatas2 = mysqli_fetch_array($barData4PRes2)) {   
		  array_push($dataPoints4P2, array("y" => $bar4PDatas2['m'], "label" => $bar4PDatas2['Year']));
		}

		$barData4P3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School'AND Year <= '$chosenTime4'  GROUP BY Year";
		$barData4PRes3 = mysqli_query($conn3, $barData4P3);

		$dataPoints4P3 = array();
		while($bar4PDatas3 = mysqli_fetch_array($barData4PRes3)) {   
		  array_push($dataPoints4P3, array("y" => $bar4PDatas3['f'], "label" => $bar4PDatas3['Year']));
		}
	}
	else {
		$dataPoints4P1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Pie
	$PieData4P = "SELECT * FROM distric4ps WHERE School = '$School' AND Year = '$chosenTime4' ";
	$PieData4PRest = mysqli_query($conn3, $PieData4P);

	if (mysqli_num_rows($PieData4PRest) > 0) {

		$PieTotal4P = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM distric4ps Where Groups = 'Highschool' AND Year = '$chosenTime4'";
		$PieTotal4PRest = mysqli_query($conn3, $PieTotal4P);
		$PieTotal4PData = mysqli_fetch_assoc($PieTotal4PRest);

		$Pie4PTotal = $PieTotal4PData['tm']+$PieTotal4PData['tf'];
		
		$PieData4P1 =  mysqli_fetch_assoc($PieData4PRest);
		$dataPoints4P1p = array(
			array("label" => $PieData4P1['School'], "y" => (($PieData4P1['Male']+$PieData4P1['Female'])/$Pie4PTotal)*100),
			array("label" => " ", "y" => (($Pie4PTotal-($PieData4P1['Male']+$PieData4P1['Female']))/$Pie4PTotal)*100)
		);

		$dataPoints4P1d = array(
			array("label" => "Female", "y" => ($PieData4P1['Female']/($PieData4P1['Female']+$PieData4P1['Male']))*100),
			array("label" => "Male", "y" => ($PieData4P1['Male']/($PieData4P1['Female']+$PieData4P1['Male']))*100));
	}
	else {
		$dataPoints4P1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P1d = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Doughnut
?>