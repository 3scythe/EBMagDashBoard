<?php
	$ntschooln1 = "SELECT COUNT(School) AS nschl FROM nutritionstatus WHERE Groups = '$group' AND School = '$School' And Year <= '$chosenTime3' ";
	$ntschoolrest = mysqli_query($conn3, $ntschooln1);
	$ntschlsrow = mysqli_fetch_array($ntschoolrest);

	$tnr = mysqli_num_rows($ntschoolrest);

	$ntschool = "SELECT * FROM nutritionstatus WHERE Groups = '$group' AND School = '$School' And Year <= '$chosenTime3' ORDER BY Year";
	$ntschoolres = mysqli_query($conn3, $ntschool);

	  echo "<table id=\"myTableNS\" class=\"Intables\">
			    <tr>
			        <td rowspan=\"3\" colspan=\"2\">School</td>
			        <td rowspan=\"2\" colspan=\"2\">Enrollment</td>
			        <td rowspan=\"2\" colspan=\"2\">Pupil Weighed</td>
			        <td colspan=\"10\">Body Mass Index (BMI)</td>
			        <td colspan=\"8\">HIEGHT-FOR-AGE (HFA)</td>
			        <td rowspan=\"2\" colspan=\"2\">Pupil Height Taken</td>
			    </tr>
			    <tr>
			        <td colspan=\"2\">Severely Wasted</td>
			        <td colspan=\"2\">Wasted</td>
			        <td colspan=\"2\">Normal</td>
			        <td colspan=\"2\">Overweight</td>
			        <td colspan=\"2\">Obese</td>
			        <td colspan=\"2\">Severely Stunted</td>
			        <td colspan=\"2\">Stunted</td>
			        <td colspan=\"2\">Normal</td>
			        <td colspan=\"2\">Tall</td>
			    </tr>
			    <tr>
			        <td>Gender</td>
			        <td>Enrollee</td>
			        <td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td>
			        <td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td><td>No.</td><td>%</td>
			    </tr>";
	  if ($tnr > 0) {
	  	for ($i=0; $i < $ntschlsrow['nschl']; $i++) { 
			$ntschlsrows = mysqli_fetch_array($ntschoolres);
			      
		  echo "<tr>
			        <td colspan=\"2\" rowspan=\"3\">".$ntschlsrows['Year']+$i."</td>
			    	<td>Male</td><td>".$ntschlsrows['enmale']."</td>
			    	<td>".$ntschlsrows['pwmale']."</td>
			    	<td>".round(($ntschlsrows['pwmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiswmale']."</td>
			    	<td>".round(($ntschlsrows['bmiswmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiwmale']."</td>
			    	<td>".round(($ntschlsrows['bmiwmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bminmale']."</td>
			    	<td>".round(($ntschlsrows['bminmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiowmale']."</td>
			    	<td>".round(($ntschlsrows['bmiowmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiomale']."</td>
			    	<td>".round(($ntschlsrows['bmiomale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfassmale']."</td>
			    	<td>".round(($ntschlsrows['hfassmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfasmale']."</td>
			    	<td>".round(($ntschlsrows['hfasmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfanmale']."</td>
			    	<td>".round(($ntschlsrows['hfanmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfatmale']."</td>
			    	<td>".round(($ntschlsrows['hfatmale']/$ntschlsrows['enmale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['pthmale']."</td>
			    	<td>".round(($ntschlsrows['pthmale']/$ntschlsrows['enmale'])*100,2)."%</td>
				</tr>
				<tr>
			    	<td>Female</td><td>".$ntschlsrows['enfemale']."</td>
			    	<td>".$ntschlsrows['pwfemale']."</td>
			    	<td>".round(($ntschlsrows['pwfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiswfemale']."</td>
			    	<td>".round(($ntschlsrows['bmiswfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiwfemale']."</td>
			    	<td>".round(($ntschlsrows['bmiwfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bminfemale']."</td>
			    	<td>".round(($ntschlsrows['bminfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiowfemale']."</td>
			    	<td>".round(($ntschlsrows['bmiowfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['bmiofemale']."</td>
			    	<td>".round(($ntschlsrows['bmiofemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfassfemale']."</td>
			    	<td>".round(($ntschlsrows['hfassfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfasfemale']."</td>
			    	<td>".round(($ntschlsrows['hfasfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfanfemale']."</td>
			    	<td>".round(($ntschlsrows['hfanfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['hfatfemale']."</td>
			    	<td>".round(($ntschlsrows['hfatfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
			    	<td>".$ntschlsrows['pthfemale']."</td>
			    	<td>".round(($ntschlsrows['pthfemale']/$ntschlsrows['enfemale'])*100,2)."%</td>
				</tr>
				<tr>
			        <td>Total</td><td>".$ntschlsrows['enmale']+$ntschlsrows['enfemale']."</td>
			        <td>".$ntschlsrows['pwmale']+$ntschlsrows['pwfemale']."</td>
			        <td>".round(($ntschlsrows['pwmale']+$ntschlsrows['pwfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['bmiswmale']+$ntschlsrows['bmiswfemale']."</td>
			        <td>".round(($ntschlsrows['bmiswmale']+$ntschlsrows['bmiswfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['bmiwmale']+$ntschlsrows['bmiwfemale']."</td>
			        <td>".round(($ntschlsrows['bmiwmale']+$ntschlsrows['bmiwfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['bminmale']+$ntschlsrows['bminfemale']."</td>
			        <td>".round(($ntschlsrows['bminmale']+$ntschlsrows['bminfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['bmiowmale']+$ntschlsrows['bmiowfemale']."</td>
			        <td>".round(($ntschlsrows['bmiowmale']+$ntschlsrows['bmiowfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['bmiomale']+$ntschlsrows['bmiofemale']."</td>
			        <td>".round(($ntschlsrows['bmiomale']+$ntschlsrows['bmiofemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['hfassmale']+$ntschlsrows['hfassfemale']."</td>
			        <td>".round(($ntschlsrows['hfassmale']+$ntschlsrows['hfassfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['hfasmale']+$ntschlsrows['hfasfemale']."</td>
			        <td>".round(($ntschlsrows['hfasmale']+$ntschlsrows['hfasfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['hfanmale']+$ntschlsrows['hfanfemale']."</td>
			        <td>".round(($ntschlsrows['hfanmale']+$ntschlsrows['hfanfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['hfatmale']+$ntschlsrows['hfatfemale']."</td>
			        <td>".round(($ntschlsrows['hfatmale']+$ntschlsrows['hfatfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			        <td>".$ntschlsrows['pthmale']+$ntschlsrows['pthfemale']."</td>
			        <td>".round(($ntschlsrows['pthmale']+$ntschlsrows['pthfemale'])/($ntschlsrows['enmale']+$ntschlsrows['enfemale'])*100,2)."%</td>
			    </tr>";
		}
	}
	echo "</table>";
?>