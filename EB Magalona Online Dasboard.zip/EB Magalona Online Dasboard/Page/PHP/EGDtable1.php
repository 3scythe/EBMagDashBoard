<?php
	$grostable = "SELECT * FROM graduationrate WHERE Groups = '$group' AND School = '$School' And Year <= '$chosenTime' ORDER BY Year";
	$getRest = mysqli_query($conn3, $grostable);
	$tnr = mysqli_num_rows($getRest);

	  echo "<table id=\"myTableEGD\" class=\"Intables\">
				<tr>
					<td colspan=\"4\"> Date </td>
					<td colspan=\"2\"> Male </td>
					<td colspan=\"2\"> Female </td>
					<td colspan=\"3\">Total</td>
				</tr>";
	  if ($tnr > 0) {
	  	for ($i=0; $i < $tnr; $i++) { 
	  		
	  		$tdata = mysqli_fetch_array($getRest);
	  		echo"<tr>
	  				<td colspan=\"4\">".$tdata['Year']."</td>
	  				<td colspan=\"2\">".$tdata['Male']."</td>
	  				<td colspan=\"2\">".$tdata['Female']."</td>
	  				<td colspan=\"3\">".$tdata['Male']+$tdata['Female']."</td>
	  			 </tr>";
	  	}
	  }
	  echo "</table>";
?>