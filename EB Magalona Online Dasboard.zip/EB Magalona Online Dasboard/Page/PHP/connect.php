<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "ebnetwokadmin";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if(!$conn){
	die("connection failed: ".mysqli_connect_error());
}

$dbServername2 = "localhost";
$dbUsername2 = "root";
$dbPassword2 = "";
$dbName2 = "ebschooladmin";

$conn2 = mysqli_connect($dbServername2, $dbUsername2, $dbPassword2, $dbName2);

if(!$conn2){
	die("connection failed: ".mysqli_connect_error());
}

$dbServername3 = "localhost";
$dbUsername3 = "root";
$dbPassword3 = "";
$dbName3 = "ebperformindicators";

$conn3 = mysqli_connect($dbServername3, $dbUsername3, $dbPassword3, $dbName3);

if(!$conn3){
	die("connection failed: ".mysqli_connect_error());
}