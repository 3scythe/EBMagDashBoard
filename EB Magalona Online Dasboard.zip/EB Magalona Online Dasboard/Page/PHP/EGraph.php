<?php
	include "connect.php";
//gross
	//Bar
	$barDataG = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataGRes = mysqli_query($conn3, $barDataG);
	if (mysqli_num_rows($barDataGRes) > 0) {

		$dataPointsG1 = array();
		while($barDatas = mysqli_fetch_array($barDataGRes)) {   
		  array_push($dataPointsG1, array("y" => $barDatas['m']+$barDatas['f'], "label" => $barDatas['Year']));
		}

		$barDataG2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataGRes2 = mysqli_query($conn3, $barDataG2);

		$dataPointsG2 = array();
		while($barDatas2 = mysqli_fetch_array($barDataGRes2)) {   
		  array_push($dataPointsG2, array("y" => $barDatas2['m'], "label" => $barDatas2['Year']));
		}

		$barDataG3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM grossenrollrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataGRes3 = mysqli_query($conn3, $barDataG3);

		$dataPointsG3 = array();
		while($barDatas3 = mysqli_fetch_array($barDataGRes3)) {   
		  array_push($dataPointsG3, array("y" => $barDatas3['f'], "label" => $barDatas3['Year']));
		}
	}
	else {
		$dataPointsG1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Pie
	$PieDataG = "SELECT * FROM grossenrollrate WHERE School = '$School' AND Year = '$chosenTime' ";
	$PieDataGRest = mysqli_query($conn3, $PieDataG);

	if (mysqli_num_rows($PieDataGRest) > 0) {

		$PieTotalG = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM grossenrollrate Where Groups = 'Elementary' AND Year = '$chosenTime'";
		$PieTotalGRest = mysqli_query($conn3, $PieTotalG);
		$PieTotalData = mysqli_fetch_assoc($PieTotalGRest);

		$PieTotal = $PieTotalData['tm']+$PieTotalData['tf'];
		
		$PieDataG1 =  mysqli_fetch_assoc($PieDataGRest);
		$dataPointsG1p = array(
			array("label" => $PieDataG1['School'], "y" => (($PieDataG1['Male']+$PieDataG1['Female'])/$PieTotal)*100),
			array("label" => " ", "y" => (($PieTotal-($PieDataG1['Male']+$PieDataG1['Female']))/$PieTotal)*100)
		);

		$dataPointsG1d = array(
			array("label" => "Female", "y" => ($PieDataG1['Female']/($PieDataG1['Female']+$PieDataG1['Male']))*100),
			array("label" => "Male", "y" => ($PieDataG1['Male']/($PieDataG1['Female']+$PieDataG1['Male']))*100));
	}
	else {
		$dataPointsG1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsG1d = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Doughnut
//Net
	$barDataN = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataNRes = mysqli_query($conn3, $barDataN);
	if (mysqli_num_rows($barDataNRes) > 0) {

		$dataPointsN1 = array();
		while($barNDatas = mysqli_fetch_array($barDataNRes)) {   
		  array_push($dataPointsN1, array("y" => $barNDatas['m']+$barNDatas['f'], "label" => $barNDatas['Year']));
		}

		$barDataN2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataNRes2 = mysqli_query($conn3, $barDataN2);

		$dataPointsN2 = array();
		while($barNDatas2 = mysqli_fetch_array($barDataNRes2)) {   
		  array_push($dataPointsN2, array("y" => $barNDatas2['m'], "label" => $barNDatas2['Year']));
		}

		$barDataN3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM netenrollrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataNRes3 = mysqli_query($conn3, $barDataN3);

		$dataPointsN3 = array();
		while($barNDatas3 = mysqli_fetch_array($barDataNRes3)) {   
		  array_push($dataPointsN3, array("y" => $barNDatas3['f'], "label" => $barNDatas3['Year']));
		}
	}
	else {
		$dataPointsN1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsN2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsN3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Drop
	$barDataD = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataDRes = mysqli_query($conn3, $barDataD);
	if (mysqli_num_rows($barDataDRes) > 0) {

		$dataPointsD1 = array();
		while($barDDatas = mysqli_fetch_array($barDataDRes)) {   
		  array_push($dataPointsD1, array("y" => $barDDatas['m']+$barDDatas['f'], "label" => $barDDatas['Year']));
		}

		$barDataD2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataDRes2 = mysqli_query($conn3, $barDataD2);

		$dataPointsD2 = array();
		while($barDDatas2 = mysqli_fetch_array($barDataDRes2)) {   
		  array_push($dataPointsD2, array("y" => $barDDatas2['m'], "label" => $barDDatas2['Year']));
		}

		$barDataD3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM droprate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataDRes3 = mysqli_query($conn3, $barDataD3);

		$dataPointsD3 = array();
		while($barDDatas3 = mysqli_fetch_array($barDataDRes3)) {   
		  array_push($dataPointsD3, array("y" => $barDDatas3['f'], "label" => $barDDatas3['Year']));
		}
	}
	else {
		$dataPointsD1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsD2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsD3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Surv
	$barDataS = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataSRes = mysqli_query($conn3, $barDataS);
	if (mysqli_num_rows($barDataSRes) > 0) {

		$dataPointsS1 = array();
		while($barSDatas = mysqli_fetch_array($barDataSRes)) {   
		  array_push($dataPointsS1, array("y" => $barSDatas['m']+$barSDatas['f'], "label" => $barSDatas['Year']));
		}

		$barDataS2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataSRes2 = mysqli_query($conn3, $barDataS2);

		$dataPointsS2 = array();
		while($barSDatas2 = mysqli_fetch_array($barDataSRes2)) {   
		  array_push($dataPointsS2, array("y" => $barSDatas2['m'], "label" => $barSDatas2['Year']));
		}

		$barDataS3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM survivalrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataSRes3 = mysqli_query($conn3, $barDataS3);

		$dataPointsS3 = array();
		while($barSDatas3 = mysqli_fetch_array($barDataSRes3)) {   
		  array_push($dataPointsS3, array("y" => $barSDatas3['f'], "label" => $barSDatas3['Year']));
		}
	}
	else {
		$dataPointsS1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsS2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsS3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Fail
	$barDataF = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataFRes = mysqli_query($conn3, $barDataF);
	if (mysqli_num_rows($barDataFRes) > 0) {

		$dataPointsF1 = array();
		while($barFDatas = mysqli_fetch_array($barDataFRes)) {   
		  array_push($dataPointsF1, array("y" => $barFDatas['m']+$barFDatas['f'], "label" => $barFDatas['Year']));
		}

		$barDataF2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataFRes2 = mysqli_query($conn3, $barDataF2);

		$dataPointsF2 = array();
		while($barFDatas2 = mysqli_fetch_array($barDataFRes2)) {   
		  array_push($dataPointsF2, array("y" => $barFDatas2['m'], "label" => $barFDatas2['Year']));
		}

		$barDataF3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM failurerate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataFRes3 = mysqli_query($conn3, $barDataF3);

		$dataPointsF3 = array();
		while($barFDatas3 = mysqli_fetch_array($barDataFRes3)) {   
		  array_push($dataPointsF3, array("y" => $barFDatas3['f'], "label" => $barFDatas3['Year']));
		}
	}
	else {
		$dataPointsF1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsF2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsF3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Comp
	$barDataC = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataCRes = mysqli_query($conn3, $barDataC);
	if (mysqli_num_rows($barDataCRes) > 0) {

		$dataPointsC1 = array();
		while($barCDatas = mysqli_fetch_array($barDataCRes)) {   
		  array_push($dataPointsC1, array("y" => $barCDatas['m']+$barCDatas['f'], "label" => $barCDatas['Year']));
		}

		$barDataC2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataCRes2 = mysqli_query($conn3, $barDataC2);

		$dataPointsC2 = array();
		while($barCDatas2 = mysqli_fetch_array($barDataCRes2)) {   
		  array_push($dataPointsC2, array("y" => $barCDatas2['m'], "label" => $barCDatas2['Year']));
		}

		$barDataC3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM completionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataCRes3 = mysqli_query($conn3, $barDataC3);

		$dataPointsC3 = array();
		while($barCDatas3 = mysqli_fetch_array($barDataCRes3)) {   
		  array_push($dataPointsC3, array("y" => $barCDatas3['f'], "label" => $barCDatas3['Year']));
		}
	}
	else {
		$dataPointsC1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsC2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsC3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Ret
	$barDataRT = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataRTRes = mysqli_query($conn3, $barDataRT);
	if (mysqli_num_rows($barDataRTRes) > 0) {

		$dataPointsRT1 = array();
		while($barRTDatas = mysqli_fetch_array($barDataRTRes)) {   
		  array_push($dataPointsRT1, array("y" => $barRTDatas['m']+$barRTDatas['f'], "label" => $barRTDatas['Year']));
		}

		$barDataRT2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataRTRes2 = mysqli_query($conn3, $barDataRT2);

		$dataPointsRT2 = array();
		while($barRTDatas2 = mysqli_fetch_array($barDataRTRes2)) {   
		  array_push($dataPointsRT2, array("y" => $barRTDatas2['m'], "label" => $barRTDatas2['Year']));
		}

		$barDataRT3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM retentionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataRTRes3 = mysqli_query($conn3, $barDataRT3);

		$dataPointsRT3 = array();
		while($barRTDatas3 = mysqli_fetch_array($barDataRTRes3)) {   
		  array_push($dataPointsRT3, array("y" => $barRTDatas3['f'], "label" => $barRTDatas3['Year']));
		}
	}
	else {
		$dataPointsRT1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRT2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRT3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Grad
	$barDataGD = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataGDRes = mysqli_query($conn3, $barDataGD);
	if (mysqli_num_rows($barDataGDRes) > 0) {

		$dataPointsGD1 = array();
		while($barGDDatas = mysqli_fetch_array($barDataGDRes)) {   
		  array_push($dataPointsGD1, array("y" => $barGDDatas['m']+$barGDDatas['f'], "label" => $barGDDatas['Year']));
		}

		$barDataGD2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataGDRes2 = mysqli_query($conn3, $barDataGD2);

		$dataPointsGD2 = array();
		while($barGDDatas2 = mysqli_fetch_array($barDataGDRes2)) {   
		  array_push($dataPointsGD2, array("y" => $barGDDatas2['m'], "label" => $barGDDatas2['Year']));
		}

		$barDataGD3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM graduationrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataGDRes3 = mysqli_query($conn3, $barDataGD3);

		$dataPointsGD3 = array();
		while($barGDDatas3 = mysqli_fetch_array($barDataGDRes3)) {   
		  array_push($dataPointsGD3, array("y" => $barGDDatas3['f'], "label" => $barGDDatas3['Year']));
		}
	}
	else {
		$dataPointsGD1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsGD2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsGD3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Pro
	$barDataPR = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataPRRes = mysqli_query($conn3, $barDataPR);
	if (mysqli_num_rows($barDataPRRes) > 0) {

		$dataPointsPR1 = array();
		while($barPRDatas = mysqli_fetch_array($barDataPRRes)) {   
		  array_push($dataPointsPR1, array("y" => $barPRDatas['m']+$barPRDatas['f'], "label" => $barPRDatas['Year']));
		}

		$barDataPR2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataPRRes2 = mysqli_query($conn3, $barDataPR2);

		$dataPointsPR2 = array();
		while($barPRDatas2 = mysqli_fetch_array($barDataPRRes2)) {   
		  array_push($dataPointsPR2, array("y" => $barPRDatas2['m'], "label" => $barPRDatas2['Year']));
		}

		$barDataPR3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM promotionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataPRRes3 = mysqli_query($conn3, $barDataPR3);

		$dataPointsPR3 = array();
		while($barPRDatas3 = mysqli_fetch_array($barDataPRRes3)) {   
		  array_push($dataPointsPR3, array("y" => $barPRDatas3['f'], "label" => $barPRDatas3['Year']));
		}
	}
	else {
		$dataPointsPR1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsPR2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsPR3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Rep
	$barDataRP = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
	$barDataRPRes = mysqli_query($conn3, $barDataRP);
	if (mysqli_num_rows($barDataRPRes) > 0) {

		$dataPointsRP1 = array();
		while($barRPDatas = mysqli_fetch_array($barDataRPRes)) {   
		  array_push($dataPointsRP1, array("y" => $barRPDatas['m']+$barRPDatas['f'], "label" => $barRPDatas['Year']));
		}

		$barDataRP2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School' AND Year <= '$chosenTime' GROUP BY Year";
		$barDataRPRes2 = mysqli_query($conn3, $barDataRP2);

		$dataPointsRP2 = array();
		while($barRPDatas2 = mysqli_fetch_array($barDataRPRes2)) {   
		  array_push($dataPointsRP2, array("y" => $barRPDatas2['m'], "label" => $barRPDatas2['Year']));
		}

		$barDataRP3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM repeatitionrate Where School = '$School'AND Year <= '$chosenTime'  GROUP BY Year";
		$barDataRPRes3 = mysqli_query($conn3, $barDataRP3);

		$dataPointsRP3 = array();
		while($barRPDatas3 = mysqli_fetch_array($barDataRPRes3)) {   
		  array_push($dataPointsRP3, array("y" => $barRPDatas3['f'], "label" => $barRPDatas3['Year']));
		}
	}
	else {
		$dataPointsRP1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRP2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsRP3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//EO3

 	$EO3Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$EO3DataRest = mysqli_query($conn3, $EO3Data);

	if (mysqli_num_rows($EO3DataRest) > 0) {
		$EO3TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Pre'";
		$EO3TotalDataRest = mysqli_query($conn3, $EO3TotalData);
		$EO3TotalDatas = mysqli_fetch_assoc($EO3TotalDataRest);

		$EO3Totals = $EO3TotalDatas['ertm']+$EO3TotalDatas['ertf'];

		$dataPointsEO3A = array(
			array("label" => "Frustration", "y" => (($EO3TotalDatas['fttm']+$EO3TotalDatas['fttf'])/$EO3Totals)*100),
			array("label" => "Instructional", "y" => (($EO3TotalDatas['ittm']+$EO3TotalDatas['ittf'])/$EO3Totals)*100),
			array("label" => "Idependent", "y" => (($EO3TotalDatas['idtm']+$EO3TotalDatas['idtf'])/$EO3Totals)*100),
			array("label" => "Non-Reader", "y" => (($EO3TotalDatas['nrtm']+$EO3TotalDatas['nrtf'])/$EO3Totals)*100)
		);

		$dataPointsEO3Aa = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas['fttm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas['ittm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas['idtm']/$EO3TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas['nrtm']/$EO3TotalDatas['ertm'])*100)
		);

		$dataPointsEO3Ab = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas['fttf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas['ittf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas['idtf']/$EO3TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas['nrtf']/$EO3TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsEO3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$EO3Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$EO3DataRest2 = mysqli_query($conn3, $EO3Data2);

	if (mysqli_num_rows($EO3DataRest2) > 0) {
		$EO3TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Post'";
		$EO3TotalDataRest2 = mysqli_query($conn3, $EO3TotalData2);
		$EO3TotalDatas2 = mysqli_fetch_assoc($EO3TotalDataRest2);

		$EO3Totals2 = $EO3TotalDatas2['ertm']+$EO3TotalDatas2['ertf'];

		$dataPointsEO3A2 = array(
			array("label" => "Frustration", "y" => (($EO3TotalDatas2['fttm']+$EO3TotalDatas2['fttf'])/$EO3Totals2)*100),
			array("label" => "Instructional", "y" => (($EO3TotalDatas2['ittm']+$EO3TotalDatas2['ittf'])/$EO3Totals2)*100),
			array("label" => "Idependent", "y" => (($EO3TotalDatas2['idtm']+$EO3TotalDatas2['idtf'])/$EO3Totals2)*100),
			array("label" => "Non-Reader", "y" => (($EO3TotalDatas2['nrtm']+$EO3TotalDatas2['nrtf'])/$EO3Totals2)*100)
		);

		$dataPointsEO3Aa2 = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas2['fttm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas2['ittm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas2['idtm']/$EO3TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas2['nrtm']/$EO3TotalDatas2['ertm'])*100)
		);

		$dataPointsEO3Ab2 = array(
			array("label" => "Frustration", "y" => ($EO3TotalDatas2['fttf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO3TotalDatas2['ittf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO3TotalDatas2['idtf']/$EO3TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO3TotalDatas2['nrtf']/$EO3TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsEO3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//EO4

 	$EO4Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$EO4DataRest = mysqli_query($conn3, $EO4Data);

	if (mysqli_num_rows($EO4DataRest) > 0) {
		$EO4TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Pre'";
		$EO4TotalDataRest = mysqli_query($conn3, $EO4TotalData);
		$EO4TotalDatas = mysqli_fetch_assoc($EO4TotalDataRest);

		$EO4Totals = $EO4TotalDatas['ertm']+$EO4TotalDatas['ertf'];

		$dataPointsEO4A = array(
			array("label" => "Frustration", "y" => (($EO4TotalDatas['fttm']+$EO4TotalDatas['fttf'])/$EO4Totals)*100),
			array("label" => "Instructional", "y" => (($EO4TotalDatas['ittm']+$EO4TotalDatas['ittf'])/$EO4Totals)*100),
			array("label" => "Idependent", "y" => (($EO4TotalDatas['idtm']+$EO4TotalDatas['idtf'])/$EO4Totals)*100),
			array("label" => "Non-Reader", "y" => (($EO4TotalDatas['nrtm']+$EO4TotalDatas['nrtf'])/$EO4Totals)*100)
		);

		$dataPointsEO4Aa = array(
			array("label" => "Frustration", "y" => ($EO4TotalDatas['fttm']/$EO4TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO4TotalDatas['ittm']/$EO4TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO4TotalDatas['idtm']/$EO4TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO4TotalDatas['nrtm']/$EO4TotalDatas['ertm'])*100)
		);

		$dataPointsEO4Ab = array(
			array("label" => "Frustration", "y" => ($EO4TotalDatas['fttf']/$EO4TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO4TotalDatas['ittf']/$EO4TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO4TotalDatas['idtf']/$EO4TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO4TotalDatas['nrtf']/$EO4TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsEO4A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO4Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO4Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$EO4Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$EO4DataRest2 = mysqli_query($conn3, $EO4Data2);

	if (mysqli_num_rows($EO4DataRest2) > 0) {
		$EO4TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Post'";
		$EO4TotalDataRest2 = mysqli_query($conn3, $EO4TotalData2);
		$EO4TotalDatas2 = mysqli_fetch_assoc($EO4TotalDataRest2);

		$EO4Totals2 = $EO4TotalDatas2['ertm']+$EO4TotalDatas2['ertf'];

		$dataPointsEO4A2 = array(
			array("label" => "Frustration", "y" => (($EO4TotalDatas2['fttm']+$EO4TotalDatas2['fttf'])/$EO4Totals2)*100),
			array("label" => "Instructional", "y" => (($EO4TotalDatas2['ittm']+$EO4TotalDatas2['ittf'])/$EO4Totals2)*100),
			array("label" => "Idependent", "y" => (($EO4TotalDatas2['idtm']+$EO4TotalDatas2['idtf'])/$EO4Totals2)*100),
			array("label" => "Non-Reader", "y" => (($EO4TotalDatas2['nrtm']+$EO4TotalDatas2['nrtf'])/$EO4Totals2)*100)
		);

		$dataPointsEO4Aa2 = array(
			array("label" => "Frustration", "y" => ($EO4TotalDatas2['fttm']/$EO4TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO4TotalDatas2['ittm']/$EO4TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO4TotalDatas2['idtm']/$EO4TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO4TotalDatas2['nrtm']/$EO4TotalDatas2['ertm'])*100)
		);

		$dataPointsEO4Ab2 = array(
			array("label" => "Frustration", "y" => ($EO4TotalDatas2['fttf']/$EO4TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO4TotalDatas2['ittf']/$EO4TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO4TotalDatas2['idtf']/$EO4TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO4TotalDatas2['nrtf']/$EO4TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsEO4A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO4Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO4Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//EO5

 	$EO5Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$EO5DataRest = mysqli_query($conn3, $EO5Data);

	if (mysqli_num_rows($EO5DataRest) > 0) {
		$EO5TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Pre'";
		$EO5TotalDataRest = mysqli_query($conn3, $EO5TotalData);
		$EO5TotalDatas = mysqli_fetch_assoc($EO5TotalDataRest);

		$EO5Totals = $EO5TotalDatas['ertm']+$EO5TotalDatas['ertf'];

		$dataPointsEO5A = array(
			array("label" => "Frustration", "y" => (($EO5TotalDatas['fttm']+$EO5TotalDatas['fttf'])/$EO5Totals)*100),
			array("label" => "Instructional", "y" => (($EO5TotalDatas['ittm']+$EO5TotalDatas['ittf'])/$EO5Totals)*100),
			array("label" => "Idependent", "y" => (($EO5TotalDatas['idtm']+$EO5TotalDatas['idtf'])/$EO5Totals)*100),
			array("label" => "Non-Reader", "y" => (($EO5TotalDatas['nrtm']+$EO5TotalDatas['nrtf'])/$EO5Totals)*100)
		);

		$dataPointsEO5Aa = array(
			array("label" => "Frustration", "y" => ($EO5TotalDatas['fttm']/$EO5TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO5TotalDatas['ittm']/$EO5TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO5TotalDatas['idtm']/$EO5TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO5TotalDatas['nrtm']/$EO5TotalDatas['ertm'])*100)
		);

		$dataPointsEO5Ab = array(
			array("label" => "Frustration", "y" => ($EO5TotalDatas['fttf']/$EO5TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO5TotalDatas['ittf']/$EO5TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO5TotalDatas['idtf']/$EO5TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO5TotalDatas['nrtf']/$EO5TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsEO5A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO5Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO5Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$EO5Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$EO5DataRest2 = mysqli_query($conn3, $EO5Data2);

	if (mysqli_num_rows($EO5DataRest2) > 0) {
		$EO5TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Post'";
		$EO5TotalDataRest2 = mysqli_query($conn3, $EO5TotalData2);
		$EO5TotalDatas2 = mysqli_fetch_assoc($EO5TotalDataRest2);

		$EO5Totals2 = $EO5TotalDatas2['ertm']+$EO5TotalDatas2['ertf'];

		$dataPointsEO5A2 = array(
			array("label" => "Frustration", "y" => (($EO5TotalDatas2['fttm']+$EO5TotalDatas2['fttf'])/$EO5Totals2)*100),
			array("label" => "Instructional", "y" => (($EO5TotalDatas2['ittm']+$EO5TotalDatas2['ittf'])/$EO5Totals2)*100),
			array("label" => "Idependent", "y" => (($EO5TotalDatas2['idtm']+$EO5TotalDatas2['idtf'])/$EO5Totals2)*100),
			array("label" => "Non-Reader", "y" => (($EO5TotalDatas2['nrtm']+$EO5TotalDatas2['nrtf'])/$EO5Totals2)*100)
		);

		$dataPointsEO5Aa2 = array(
			array("label" => "Frustration", "y" => ($EO5TotalDatas2['fttm']/$EO5TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO5TotalDatas2['ittm']/$EO5TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO5TotalDatas2['idtm']/$EO5TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO5TotalDatas2['nrtm']/$EO5TotalDatas2['ertm'])*100)
		);

		$dataPointsEO5Ab2 = array(
			array("label" => "Frustration", "y" => ($EO5TotalDatas2['fttf']/$EO5TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO5TotalDatas2['ittf']/$EO5TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO5TotalDatas2['idtf']/$EO5TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO5TotalDatas2['nrtf']/$EO5TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsEO5A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO5Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO5Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//EO6

 	$EO6Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$EO6DataRest = mysqli_query($conn3, $EO6Data);

	if (mysqli_num_rows($EO6DataRest) > 0) {
		$EO6TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Pre'";
		$EO6TotalDataRest = mysqli_query($conn3, $EO6TotalData);
		$EO6TotalDatas = mysqli_fetch_assoc($EO6TotalDataRest);

		$EO6Totals = $EO6TotalDatas['ertm']+$EO6TotalDatas['ertf'];

		$dataPointsEO6A = array(
			array("label" => "Frustration", "y" => (($EO6TotalDatas['fttm']+$EO6TotalDatas['fttf'])/$EO6Totals)*100),
			array("label" => "Instructional", "y" => (($EO6TotalDatas['ittm']+$EO6TotalDatas['ittf'])/$EO6Totals)*100),
			array("label" => "Idependent", "y" => (($EO6TotalDatas['idtm']+$EO6TotalDatas['idtf'])/$EO6Totals)*100),
			array("label" => "Non-Reader", "y" => (($EO6TotalDatas['nrtm']+$EO6TotalDatas['nrtf'])/$EO6Totals)*100)
		);

		$dataPointsEO6Aa = array(
			array("label" => "Frustration", "y" => ($EO6TotalDatas['fttm']/$EO6TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO6TotalDatas['ittm']/$EO6TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO6TotalDatas['idtm']/$EO6TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO6TotalDatas['nrtm']/$EO6TotalDatas['ertm'])*100)
		);

		$dataPointsEO6Ab = array(
			array("label" => "Frustration", "y" => ($EO6TotalDatas['fttf']/$EO6TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO6TotalDatas['ittf']/$EO6TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO6TotalDatas['idtf']/$EO6TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO6TotalDatas['nrtf']/$EO6TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsEO6A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO6Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO6Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$EO6Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$EO6DataRest2 = mysqli_query($conn3, $EO6Data2);

	if (mysqli_num_rows($EO6DataRest2) > 0) {
		$EO6TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Post'";
		$EO6TotalDataRest2 = mysqli_query($conn3, $EO6TotalData2);
		$EO6TotalDatas2 = mysqli_fetch_assoc($EO6TotalDataRest2);

		$EO6Totals2 = $EO6TotalDatas2['ertm']+$EO6TotalDatas2['ertf'];

		$dataPointsEO6A2 = array(
			array("label" => "Frustration", "y" => (($EO6TotalDatas2['fttm']+$EO6TotalDatas2['fttf'])/$EO6Totals2)*100),
			array("label" => "Instructional", "y" => (($EO6TotalDatas2['ittm']+$EO6TotalDatas2['ittf'])/$EO6Totals2)*100),
			array("label" => "Idependent", "y" => (($EO6TotalDatas2['idtm']+$EO6TotalDatas2['idtf'])/$EO6Totals2)*100),
			array("label" => "Non-Reader", "y" => (($EO6TotalDatas2['nrtm']+$EO6TotalDatas2['nrtf'])/$EO6Totals2)*100)
		);

		$dataPointsEO6Aa2 = array(
			array("label" => "Frustration", "y" => ($EO6TotalDatas2['fttm']/$EO6TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($EO6TotalDatas2['ittm']/$EO6TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($EO6TotalDatas2['idtm']/$EO6TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($EO6TotalDatas2['nrtm']/$EO6TotalDatas2['ertm'])*100)
		);

		$dataPointsEO6Ab2 = array(
			array("label" => "Frustration", "y" => ($EO6TotalDatas2['fttf']/$EO6TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($EO6TotalDatas2['ittf']/$EO6TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($EO6TotalDatas2['idtf']/$EO6TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($EO6TotalDatas2['nrtf']/$EO6TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsEO6A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO6Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsEO6Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//ES3

	$ESData3 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$ESData3Rest = mysqli_query($conn3, $ESData3);

	if (mysqli_num_rows($ESData3Rest) > 0) {
		$ESTotalData3 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Pre'";
		$ESTotalData3Rest = mysqli_query($conn3, $ESTotalData3);
		$ES3PreDatas = mysqli_fetch_assoc($ESTotalData3Rest);

		$ES3TotalDatas = $ES3PreDatas['ertm']+$ES3PreDatas['ertf'];

		if ($ES3TotalDatas > 0) {

			$dataPointsES3A = array(
				array("label" => "Slow", "y" => (($ES3PreDatas['sstm']+$ES3PreDatas['sstf'])/$ES3TotalDatas)*100),
				array("label" => "Average", "y" => (($ES3PreDatas['satm']+$ES3PreDatas['satf'])/$ES3TotalDatas)*100),
				array("label" => "Fast", "y" => (($ES3PreDatas['sftm']+$ES3PreDatas['sftf'])/$ES3TotalDatas)*100)
			);

			$dataPointsES3B = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas['cfttm']+$ES3PreDatas['cfttf'])/$ES3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas['cittm']+$ES3PreDatas['cittf'])/$ES3TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas['cidtm']+$ES3PreDatas['cidtf'])/$ES3TotalDatas)*100)
			);

			$dataPointsES3C = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas['rlfttm']+$ES3PreDatas['rlfttf'])/$ES3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas['rlittm']+$ES3PreDatas['rlittf'])/$ES3TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas['rlidtm']+$ES3PreDatas['rlidtf'])/$ES3TotalDatas)*100)
			);
		}
		else{
			$dataPointsES3A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES3C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES3PreDatas['ertm'] > 0) {

			$dataPointsES3Aa = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['sstm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['satm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['sftm']/$ES3PreDatas['ertm'])*100)
			);

			$dataPointsES3Ba = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['cfttm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['cittm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['cidtm']/$ES3PreDatas['ertm'])*100)
			);

			$dataPointsES3Ca = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['rlfttm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['rlittm']/$ES3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['rlidtm']/$ES3PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsES3Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES3PreDatas['ertf'] > 0) {

			$dataPointsES3Ab = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['sstf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['satf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['sftf']/$ES3PreDatas['ertf'])*100)
			);

			$dataPointsES3Bb = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['cfttf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['cittf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['cidtf']/$ES3PreDatas['ertf'])*100)
			);

			$dataPointsES3Cb = array(
				array("label" => "Slow", "y" => ($ES3PreDatas['rlfttf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas['rlittf']/$ES3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas['rlidtf']/$ES3PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsES3Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$ESData32 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$ESData3Rest2 = mysqli_query($conn3, $ESData32);

	if (mysqli_num_rows($ESData3Rest2) > 0) {
		$ESTotalData32 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'English' AND pORp = 'Post'";
		$ESTotalData3Rest2 = mysqli_query($conn3, $ESTotalData32);
		$ES3PreDatas2 = mysqli_fetch_assoc($ESTotalData3Rest2);

		$ES3TotalDatas2 = $ES3PreDatas2['ertm']+$ES3PreDatas2['ertf'];

		if ($ES3TotalDatas2 > 0) {

			$dataPointsES3A2 = array(
				array("label" => "Slow", "y" => (($ES3PreDatas2['sstm']+$ES3PreDatas2['sstf'])/$ES3TotalDatas2)*100),
				array("label" => "Average", "y" => (($ES3PreDatas2['satm']+$ES3PreDatas2['satf'])/$ES3TotalDatas2)*100),
				array("label" => "Fast", "y" => (($ES3PreDatas2['sftm']+$ES3PreDatas2['sftf'])/$ES3TotalDatas2)*100)
			);

			$dataPointsES3B2 = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas2['cfttm']+$ES3PreDatas2['cfttf'])/$ES3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas2['cittm']+$ES3PreDatas2['cittf'])/$ES3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas2['cidtm']+$ES3PreDatas2['cidtf'])/$ES3TotalDatas2)*100)
			);

			$dataPointsES3C2 = array(
				array("label" => "Frustration", "y" => (($ES3PreDatas2['rlfttm']+$ES3PreDatas2['rlfttf'])/$ES3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES3PreDatas2['rlittm']+$ES3PreDatas2['rlittf'])/$ES3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES3PreDatas2['rlidtm']+$ES3PreDatas2['rlidtf'])/$ES3TotalDatas2)*100)
			);
		}
		else{
			$dataPointsES3A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES3C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES3PreDatas2['ertm'] > 0) {

			$dataPointsES3Aa2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['sstm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['satm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['sftm']/$ES3PreDatas2['ertm'])*100)
			);

			$dataPointsES3Ba2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['cfttm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['cittm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['cidtm']/$ES3PreDatas2['ertm'])*100)
			);

			$dataPointsES3Ca2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['rlfttm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['rlittm']/$ES3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['rlidtm']/$ES3PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsES3Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES3PreDatas2['ertf'] > 0) {

			$dataPointsES3Ab2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['sstf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['satf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['sftf']/$ES3PreDatas2['ertf'])*100)
			);

			$dataPointsES3Bb2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['cfttf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['cittf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['cidtf']/$ES3PreDatas2['ertf'])*100)
			);

			$dataPointsES3Cb2 = array(
				array("label" => "Slow", "y" => ($ES3PreDatas2['rlfttf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES3PreDatas2['rlittf']/$ES3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES3PreDatas2['rlidtf']/$ES3PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsES3Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES3Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES3Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//ES4

	$ESData4 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$ESData4Rest = mysqli_query($conn3, $ESData4);

	if (mysqli_num_rows($ESData4Rest) > 0) {
		$ESTotalData4 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Pre'";
		$ESTotalData4Rest = mysqli_query($conn3, $ESTotalData4);
		$ES4PreDatas = mysqli_fetch_assoc($ESTotalData4Rest);

		$ES4TotalDatas = $ES4PreDatas['ertm']+$ES4PreDatas['ertf'];

		if ($ES4TotalDatas > 0) {

			$dataPointsES4A = array(
				array("label" => "Slow", "y" => (($ES4PreDatas['sstm']+$ES4PreDatas['sstf'])/$ES4TotalDatas)*100),
				array("label" => "Average", "y" => (($ES4PreDatas['satm']+$ES4PreDatas['satf'])/$ES4TotalDatas)*100),
				array("label" => "Fast", "y" => (($ES4PreDatas['sftm']+$ES4PreDatas['sftf'])/$ES4TotalDatas)*100)
			);

			$dataPointsES4B = array(
				array("label" => "Frustration", "y" => (($ES4PreDatas['cfttm']+$ES4PreDatas['cfttf'])/$ES4TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES4PreDatas['cittm']+$ES4PreDatas['cittf'])/$ES4TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES4PreDatas['cidtm']+$ES4PreDatas['cidtf'])/$ES4TotalDatas)*100)
			);

			$dataPointsES4C = array(
				array("label" => "Frustration", "y" => (($ES4PreDatas['rlfttm']+$ES4PreDatas['rlfttf'])/$ES4TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES4PreDatas['rlittm']+$ES4PreDatas['rlittf'])/$ES4TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES4PreDatas['rlidtm']+$ES4PreDatas['rlidtf'])/$ES4TotalDatas)*100)
			);
		}
		else{
			$dataPointsES4A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES4C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES4PreDatas['ertm'] > 0) {

			$dataPointsES4Aa = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['sstm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['satm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['sftm']/$ES4PreDatas['ertm'])*100)
			);

			$dataPointsES4Ba = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['cfttm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['cittm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['cidtm']/$ES4PreDatas['ertm'])*100)
			);

			$dataPointsES4Ca = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['rlfttm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['rlittm']/$ES4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['rlidtm']/$ES4PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsES4Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES4PreDatas['ertf'] > 0) {

			$dataPointsES4Ab = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['sstf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['satf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['sftf']/$ES4PreDatas['ertf'])*100)
			);

			$dataPointsES4Bb = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['cfttf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['cittf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['cidtf']/$ES4PreDatas['ertf'])*100)
			);

			$dataPointsES4Cb = array(
				array("label" => "Slow", "y" => ($ES4PreDatas['rlfttf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas['rlittf']/$ES4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas['rlidtf']/$ES4PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsES4Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES4A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$ESData42 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$ESData4Rest2 = mysqli_query($conn3, $ESData42);

	if (mysqli_num_rows($ESData4Rest2) > 0) {
		$ESTotalData42 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'English' AND pORp = 'Post'";
		$ESTotalData4Rest2 = mysqli_query($conn3, $ESTotalData42);
		$ES4PreDatas2 = mysqli_fetch_assoc($ESTotalData4Rest2);

		$ES4TotalDatas2 = $ES4PreDatas2['ertm']+$ES4PreDatas2['ertf'];

		if ($ES4TotalDatas2 > 0) {

			$dataPointsES4A2 = array(
				array("label" => "Slow", "y" => (($ES4PreDatas2['sstm']+$ES4PreDatas2['sstf'])/$ES4TotalDatas2)*100),
				array("label" => "Average", "y" => (($ES4PreDatas2['satm']+$ES4PreDatas2['satf'])/$ES4TotalDatas2)*100),
				array("label" => "Fast", "y" => (($ES4PreDatas2['sftm']+$ES4PreDatas2['sftf'])/$ES4TotalDatas2)*100)
			);

			$dataPointsES4B2 = array(
				array("label" => "Frustration", "y" => (($ES4PreDatas2['cfttm']+$ES4PreDatas2['cfttf'])/$ES4TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES4PreDatas2['cittm']+$ES4PreDatas2['cittf'])/$ES4TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES4PreDatas2['cidtm']+$ES4PreDatas2['cidtf'])/$ES4TotalDatas2)*100)
			);

			$dataPointsES4C2 = array(
				array("label" => "Frustration", "y" => (($ES4PreDatas2['rlfttm']+$ES4PreDatas2['rlfttf'])/$ES4TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES4PreDatas2['rlittm']+$ES4PreDatas2['rlittf'])/$ES4TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES4PreDatas2['rlidtm']+$ES4PreDatas2['rlidtf'])/$ES4TotalDatas2)*100)
			);
		}
		else{
			$dataPointsES4A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES4C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES4PreDatas2['ertm'] > 0) {

			$dataPointsES4Aa2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['sstm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['satm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['sftm']/$ES4PreDatas2['ertm'])*100)
			);

			$dataPointsES4Ba2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['cfttm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['cittm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['cidtm']/$ES4PreDatas2['ertm'])*100)
			);

			$dataPointsES4Ca2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['rlfttm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['rlittm']/$ES4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['rlidtm']/$ES4PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsES4Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES4PreDatas2['ertf'] > 0) {

			$dataPointsES4Ab2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['sstf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['satf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['sftf']/$ES4PreDatas2['ertf'])*100)
			);

			$dataPointsES4Bb2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['cfttf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['cittf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['cidtf']/$ES4PreDatas2['ertf'])*100)
			);

			$dataPointsES4Cb2 = array(
				array("label" => "Slow", "y" => ($ES4PreDatas2['rlfttf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES4PreDatas2['rlittf']/$ES4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES4PreDatas2['rlidtf']/$ES4PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsES4Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES4Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES4A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES4Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//ES5

	$ESData5 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$ESData5Rest = mysqli_query($conn3, $ESData5);

	if (mysqli_num_rows($ESData5Rest) > 0) {
		$ESTotalData5 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Pre'";
		$ESTotalData5Rest = mysqli_query($conn3, $ESTotalData5);
		$ES5PreDatas = mysqli_fetch_assoc($ESTotalData5Rest);

		$ES5TotalDatas = $ES5PreDatas['ertm']+$ES5PreDatas['ertf'];

		if ($ES5TotalDatas > 0) {

			$dataPointsES5A = array(
				array("label" => "Slow", "y" => (($ES5PreDatas['sstm']+$ES5PreDatas['sstf'])/$ES5TotalDatas)*100),
				array("label" => "Average", "y" => (($ES5PreDatas['satm']+$ES5PreDatas['satf'])/$ES5TotalDatas)*100),
				array("label" => "Fast", "y" => (($ES5PreDatas['sftm']+$ES5PreDatas['sftf'])/$ES5TotalDatas)*100)
			);

			$dataPointsES5B = array(
				array("label" => "Frustration", "y" => (($ES5PreDatas['cfttm']+$ES5PreDatas['cfttf'])/$ES5TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES5PreDatas['cittm']+$ES5PreDatas['cittf'])/$ES5TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES5PreDatas['cidtm']+$ES5PreDatas['cidtf'])/$ES5TotalDatas)*100)
			);

			$dataPointsES5C = array(
				array("label" => "Frustration", "y" => (($ES5PreDatas['rlfttm']+$ES5PreDatas['rlfttf'])/$ES5TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES5PreDatas['rlittm']+$ES5PreDatas['rlittf'])/$ES5TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES5PreDatas['rlidtm']+$ES5PreDatas['rlidtf'])/$ES5TotalDatas)*100)
			);
		}
		else{
			$dataPointsES5A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES5C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES5PreDatas['ertm'] > 0) {

			$dataPointsES5Aa = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['sstm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['satm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['sftm']/$ES5PreDatas['ertm'])*100)
			);

			$dataPointsES5Ba = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['cfttm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['cittm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['cidtm']/$ES5PreDatas['ertm'])*100)
			);

			$dataPointsES5Ca = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['rlfttm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['rlittm']/$ES5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['rlidtm']/$ES5PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsES5Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES5PreDatas['ertf'] > 0) {

			$dataPointsES5Ab = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['sstf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['satf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['sftf']/$ES5PreDatas['ertf'])*100)
			);

			$dataPointsES5Bb = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['cfttf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['cittf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['cidtf']/$ES5PreDatas['ertf'])*100)
			);

			$dataPointsES5Cb = array(
				array("label" => "Slow", "y" => ($ES5PreDatas['rlfttf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas['rlittf']/$ES5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas['rlidtf']/$ES5PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsES5Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES5A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$ESData52 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$ESData5Rest2 = mysqli_query($conn3, $ESData52);

	if (mysqli_num_rows($ESData5Rest2) > 0) {
		$ESTotalData52 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'English' AND pORp = 'Post'";
		$ESTotalData5Rest2 = mysqli_query($conn3, $ESTotalData52);
		$ES5PreDatas2 = mysqli_fetch_assoc($ESTotalData5Rest2);

		$ES5TotalDatas2 = $ES5PreDatas2['ertm']+$ES5PreDatas2['ertf'];

		if ($ES5TotalDatas2 > 0) {

			$dataPointsES5A2 = array(
				array("label" => "Slow", "y" => (($ES5PreDatas2['sstm']+$ES5PreDatas2['sstf'])/$ES5TotalDatas2)*100),
				array("label" => "Average", "y" => (($ES5PreDatas2['satm']+$ES5PreDatas2['satf'])/$ES5TotalDatas2)*100),
				array("label" => "Fast", "y" => (($ES5PreDatas2['sftm']+$ES5PreDatas2['sftf'])/$ES5TotalDatas2)*100)
			);

			$dataPointsES5B2 = array(
				array("label" => "Frustration", "y" => (($ES5PreDatas2['cfttm']+$ES5PreDatas2['cfttf'])/$ES5TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES5PreDatas2['cittm']+$ES5PreDatas2['cittf'])/$ES5TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES5PreDatas2['cidtm']+$ES5PreDatas2['cidtf'])/$ES5TotalDatas2)*100)
			);

			$dataPointsES5C2 = array(
				array("label" => "Frustration", "y" => (($ES5PreDatas2['rlfttm']+$ES5PreDatas2['rlfttf'])/$ES5TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES5PreDatas2['rlittm']+$ES5PreDatas2['rlittf'])/$ES5TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES5PreDatas2['rlidtm']+$ES5PreDatas2['rlidtf'])/$ES5TotalDatas2)*100)
			);
		}
		else{
			$dataPointsES5A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES5C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES5PreDatas2['ertm'] > 0) {

			$dataPointsES5Aa2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['sstm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['satm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['sftm']/$ES5PreDatas2['ertm'])*100)
			);

			$dataPointsES5Ba2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['cfttm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['cittm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['cidtm']/$ES5PreDatas2['ertm'])*100)
			);

			$dataPointsES5Ca2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['rlfttm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['rlittm']/$ES5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['rlidtm']/$ES5PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsES5Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES5PreDatas2['ertf'] > 0) {

			$dataPointsES5Ab2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['sstf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['satf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['sftf']/$ES5PreDatas2['ertf'])*100)
			);

			$dataPointsES5Bb2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['cfttf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['cittf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['cidtf']/$ES5PreDatas2['ertf'])*100)
			);

			$dataPointsES5Cb2 = array(
				array("label" => "Slow", "y" => ($ES5PreDatas2['rlfttf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES5PreDatas2['rlittf']/$ES5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES5PreDatas2['rlidtf']/$ES5PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsES5Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES5Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES5A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES5Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//ES6
	$ESData6 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Pre' ORDER BY Year";
	$ESData6Rest = mysqli_query($conn3, $ESData6);

	if (mysqli_num_rows($ESData6Rest) > 0) {
		$ESTotalData6 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Pre'";
		$ESTotalData6Rest = mysqli_query($conn3, $ESTotalData6);
		$ES6PreDatas = mysqli_fetch_assoc($ESTotalData6Rest);

		$ES6TotalDatas = $ES6PreDatas['ertm']+$ES6PreDatas['ertf'];

		if ($ES6TotalDatas > 0) {

			$dataPointsES6A = array(
				array("label" => "Slow", "y" => (($ES6PreDatas['sstm']+$ES6PreDatas['sstf'])/$ES6TotalDatas)*100),
				array("label" => "Average", "y" => (($ES6PreDatas['satm']+$ES6PreDatas['satf'])/$ES6TotalDatas)*100),
				array("label" => "Fast", "y" => (($ES6PreDatas['sftm']+$ES6PreDatas['sftf'])/$ES6TotalDatas)*100)
			);

			$dataPointsES6B = array(
				array("label" => "Frustration", "y" => (($ES6PreDatas['cfttm']+$ES6PreDatas['cfttf'])/$ES6TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES6PreDatas['cittm']+$ES6PreDatas['cittf'])/$ES6TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES6PreDatas['cidtm']+$ES6PreDatas['cidtf'])/$ES6TotalDatas)*100)
			);

			$dataPointsES6C = array(
				array("label" => "Frustration", "y" => (($ES6PreDatas['rlfttm']+$ES6PreDatas['rlfttf'])/$ES6TotalDatas)*100),
				array("label" => "Instructional", "y" => (($ES6PreDatas['rlittm']+$ES6PreDatas['rlittf'])/$ES6TotalDatas)*100),
				array("label" => "Independent", "y" => (($ES6PreDatas['rlidtm']+$ES6PreDatas['rlidtf'])/$ES6TotalDatas)*100)
			);
		}
		else{
			$dataPointsES6A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES6C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES6PreDatas['ertm'] > 0) {

			$dataPointsES6Aa = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['sstm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['satm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['sftm']/$ES6PreDatas['ertm'])*100)
			);

			$dataPointsES6Ba = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['cfttm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['cittm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['cidtm']/$ES6PreDatas['ertm'])*100)
			);

			$dataPointsES6Ca = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['rlfttm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['rlittm']/$ES6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['rlidtm']/$ES6PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsES6Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES6PreDatas['ertf'] > 0) {

			$dataPointsES6Ab = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['sstf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['satf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['sftf']/$ES6PreDatas['ertf'])*100)
			);

			$dataPointsES6Bb = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['cfttf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['cittf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['cidtf']/$ES6PreDatas['ertf'])*100)
			);

			$dataPointsES6Cb = array(
				array("label" => "Slow", "y" => ($ES6PreDatas['rlfttf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas['rlittf']/$ES6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas['rlidtf']/$ES6PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsES6Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES6A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$ESData62 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Post' ORDER BY Year";
	$ESData6Rest2 = mysqli_query($conn3, $ESData62);

	if (mysqli_num_rows($ESData6Rest2) > 0) {
		$ESTotalData62 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'English' AND pORp = 'Post'";
		$ESTotalData6Rest2 = mysqli_query($conn3, $ESTotalData62);
		$ES6PreDatas2 = mysqli_fetch_assoc($ESTotalData6Rest2);

		$ES6TotalDatas2 = $ES6PreDatas2['ertm']+$ES6PreDatas2['ertf'];

		if ($ES6TotalDatas2 > 0) {

			$dataPointsES6A2 = array(
				array("label" => "Slow", "y" => (($ES6PreDatas2['sstm']+$ES6PreDatas2['sstf'])/$ES6TotalDatas2)*100),
				array("label" => "Average", "y" => (($ES6PreDatas2['satm']+$ES6PreDatas2['satf'])/$ES6TotalDatas2)*100),
				array("label" => "Fast", "y" => (($ES6PreDatas2['sftm']+$ES6PreDatas2['sftf'])/$ES6TotalDatas2)*100)
			);

			$dataPointsES6B2 = array(
				array("label" => "Frustration", "y" => (($ES6PreDatas2['cfttm']+$ES6PreDatas2['cfttf'])/$ES6TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES6PreDatas2['cittm']+$ES6PreDatas2['cittf'])/$ES6TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES6PreDatas2['cidtm']+$ES6PreDatas2['cidtf'])/$ES6TotalDatas2)*100)
			);

			$dataPointsES6C2 = array(
				array("label" => "Frustration", "y" => (($ES6PreDatas2['rlfttm']+$ES6PreDatas2['rlfttf'])/$ES6TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($ES6PreDatas2['rlittm']+$ES6PreDatas2['rlittf'])/$ES6TotalDatas2)*100),
				array("label" => "Independent", "y" => (($ES6PreDatas2['rlidtm']+$ES6PreDatas2['rlidtf'])/$ES6TotalDatas2)*100)
			);
		}
		else{
			$dataPointsES6A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsES6C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($ES6PreDatas2['ertm'] > 0) {

			$dataPointsES6Aa2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['sstm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['satm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['sftm']/$ES6PreDatas2['ertm'])*100)
			);

			$dataPointsES6Ba2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['cfttm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['cittm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['cidtm']/$ES6PreDatas2['ertm'])*100)
			);

			$dataPointsES6Ca2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['rlfttm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['rlittm']/$ES6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['rlidtm']/$ES6PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsES6Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($ES6PreDatas2['ertf'] > 0) {

			$dataPointsES6Ab2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['sstf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['satf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['sftf']/$ES6PreDatas2['ertf'])*100)
			);

			$dataPointsES6Bb2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['cfttf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['cittf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['cidtf']/$ES6PreDatas2['ertf'])*100)
			);

			$dataPointsES6Cb2 = array(
				array("label" => "Slow", "y" => ($ES6PreDatas2['rlfttf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($ES6PreDatas2['rlittf']/$ES6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($ES6PreDatas2['rlidtf']/$ES6PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsES6Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsES6Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsES6A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsES6Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FO3

 	$FO3Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FO3DataRest = mysqli_query($conn3, $FO3Data);

	if (mysqli_num_rows($FO3DataRest) > 0) {
		$FO3TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FO3TotalDataRest = mysqli_query($conn3, $FO3TotalData);
		$FO3TotalDatas = mysqli_fetch_assoc($FO3TotalDataRest);

		$FO3Totals = $FO3TotalDatas['ertm']+$FO3TotalDatas['ertf'];

		$dataPointsFO3A = array(
			array("label" => "Frustration", "y" => (($FO3TotalDatas['fttm']+$FO3TotalDatas['fttf'])/$FO3Totals)*100),
			array("label" => "Instructional", "y" => (($FO3TotalDatas['ittm']+$FO3TotalDatas['ittf'])/$FO3Totals)*100),
			array("label" => "Idependent", "y" => (($FO3TotalDatas['idtm']+$FO3TotalDatas['idtf'])/$FO3Totals)*100),
			array("label" => "Non-Reader", "y" => (($FO3TotalDatas['nrtm']+$FO3TotalDatas['nrtf'])/$FO3Totals)*100)
		);

		$dataPointsFO3Aa = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas['fttm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas['ittm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas['idtm']/$FO3TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas['nrtm']/$FO3TotalDatas['ertm'])*100)
		);

		$dataPointsFO3Ab = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas['fttf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas['ittf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas['idtf']/$FO3TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas['nrtf']/$FO3TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsFO3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FO3Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FO3DataRest2 = mysqli_query($conn3, $FO3Data2);

	if (mysqli_num_rows($FO3DataRest2) > 0) {
		$FO3TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post'";
		$FO3TotalDataRest2 = mysqli_query($conn3, $FO3TotalData2);
		$FO3TotalDatas2 = mysqli_fetch_assoc($FO3TotalDataRest2);

		$FO3Totals2 = $FO3TotalDatas2['ertm']+$FO3TotalDatas2['ertf'];

		$dataPointsFO3A2 = array(
			array("label" => "Frustration", "y" => (($FO3TotalDatas2['fttm']+$FO3TotalDatas2['fttf'])/$FO3Totals2)*100),
			array("label" => "Instructional", "y" => (($FO3TotalDatas2['ittm']+$FO3TotalDatas2['ittf'])/$FO3Totals2)*100),
			array("label" => "Idependent", "y" => (($FO3TotalDatas2['idtm']+$FO3TotalDatas2['idtf'])/$FO3Totals2)*100),
			array("label" => "Non-Reader", "y" => (($FO3TotalDatas2['nrtm']+$FO3TotalDatas2['nrtf'])/$FO3Totals2)*100)
		);

		$dataPointsFO3Aa2 = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas2['fttm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas2['ittm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas2['idtm']/$FO3TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas2['nrtm']/$FO3TotalDatas2['ertm'])*100)
		);

		$dataPointsFO3Ab2 = array(
			array("label" => "Frustration", "y" => ($FO3TotalDatas2['fttf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO3TotalDatas2['ittf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO3TotalDatas2['idtf']/$FO3TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO3TotalDatas2['nrtf']/$FO3TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsFO3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FO4

 	$FO4Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FO4DataRest = mysqli_query($conn3, $FO4Data);

	if (mysqli_num_rows($FO4DataRest) > 0) {
		$FO4TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FO4TotalDataRest = mysqli_query($conn3, $FO4TotalData);
		$FO4TotalDatas = mysqli_fetch_assoc($FO4TotalDataRest);

		$FO4Totals = $FO4TotalDatas['ertm']+$FO4TotalDatas['ertf'];

		$dataPointsFO4A = array(
			array("label" => "Frustration", "y" => (($FO4TotalDatas['fttm']+$FO4TotalDatas['fttf'])/$FO4Totals)*100),
			array("label" => "Instructional", "y" => (($FO4TotalDatas['ittm']+$FO4TotalDatas['ittf'])/$FO4Totals)*100),
			array("label" => "Idependent", "y" => (($FO4TotalDatas['idtm']+$FO4TotalDatas['idtf'])/$FO4Totals)*100),
			array("label" => "Non-Reader", "y" => (($FO4TotalDatas['nrtm']+$FO4TotalDatas['nrtf'])/$FO4Totals)*100)
		);

		$dataPointsFO4Aa = array(
			array("label" => "Frustration", "y" => ($FO4TotalDatas['fttm']/$FO4TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO4TotalDatas['ittm']/$FO4TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO4TotalDatas['idtm']/$FO4TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO4TotalDatas['nrtm']/$FO4TotalDatas['ertm'])*100)
		);

		$dataPointsFO4Ab = array(
			array("label" => "Frustration", "y" => ($FO4TotalDatas['fttf']/$FO4TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO4TotalDatas['ittf']/$FO4TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO4TotalDatas['idtf']/$FO4TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO4TotalDatas['nrtf']/$FO4TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsFO4A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO4Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO4Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FO4Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FO4DataRest2 = mysqli_query($conn3, $FO4Data2);

	if (mysqli_num_rows($FO4DataRest2) > 0) {
		$FO4TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Post'";
		$FO4TotalDataRest2 = mysqli_query($conn3, $FO4TotalData2);
		$FO4TotalDatas2 = mysqli_fetch_assoc($FO4TotalDataRest2);

		$FO4Totals2 = $FO4TotalDatas2['ertm']+$FO4TotalDatas2['ertf'];

		$dataPointsFO4A2 = array(
			array("label" => "Frustration", "y" => (($FO4TotalDatas2['fttm']+$FO4TotalDatas2['fttf'])/$FO4Totals2)*100),
			array("label" => "Instructional", "y" => (($FO4TotalDatas2['ittm']+$FO4TotalDatas2['ittf'])/$FO4Totals2)*100),
			array("label" => "Idependent", "y" => (($FO4TotalDatas2['idtm']+$FO4TotalDatas2['idtf'])/$FO4Totals2)*100),
			array("label" => "Non-Reader", "y" => (($FO4TotalDatas2['nrtm']+$FO4TotalDatas2['nrtf'])/$FO4Totals2)*100)
		);

		$dataPointsFO4Aa2 = array(
			array("label" => "Frustration", "y" => ($FO4TotalDatas2['fttm']/$FO4TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO4TotalDatas2['ittm']/$FO4TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO4TotalDatas2['idtm']/$FO4TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO4TotalDatas2['nrtm']/$FO4TotalDatas2['ertm'])*100)
		);

		$dataPointsFO4Ab2 = array(
			array("label" => "Frustration", "y" => ($FO4TotalDatas2['fttf']/$FO4TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO4TotalDatas2['ittf']/$FO4TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO4TotalDatas2['idtf']/$FO4TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO4TotalDatas2['nrtf']/$FO4TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsFO4A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO4Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO4Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FO5

 	$FO5Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FO5DataRest = mysqli_query($conn3, $FO5Data);

	if (mysqli_num_rows($FO5DataRest) > 0) {
		$FO5TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FO5TotalDataRest = mysqli_query($conn3, $FO5TotalData);
		$FO5TotalDatas = mysqli_fetch_assoc($FO5TotalDataRest);

		$FO5Totals = $FO5TotalDatas['ertm']+$FO5TotalDatas['ertf'];

		$dataPointsFO5A = array(
			array("label" => "Frustration", "y" => (($FO5TotalDatas['fttm']+$FO5TotalDatas['fttf'])/$FO5Totals)*100),
			array("label" => "Instructional", "y" => (($FO5TotalDatas['ittm']+$FO5TotalDatas['ittf'])/$FO5Totals)*100),
			array("label" => "Idependent", "y" => (($FO5TotalDatas['idtm']+$FO5TotalDatas['idtf'])/$FO5Totals)*100),
			array("label" => "Non-Reader", "y" => (($FO5TotalDatas['nrtm']+$FO5TotalDatas['nrtf'])/$FO5Totals)*100)
		);

		$dataPointsFO5Aa = array(
			array("label" => "Frustration", "y" => ($FO5TotalDatas['fttm']/$FO5TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO5TotalDatas['ittm']/$FO5TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO5TotalDatas['idtm']/$FO5TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO5TotalDatas['nrtm']/$FO5TotalDatas['ertm'])*100)
		);

		$dataPointsFO5Ab = array(
			array("label" => "Frustration", "y" => ($FO5TotalDatas['fttf']/$FO5TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO5TotalDatas['ittf']/$FO5TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO5TotalDatas['idtf']/$FO5TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO5TotalDatas['nrtf']/$FO5TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsFO5A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO5Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO5Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FO5Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FO5DataRest2 = mysqli_query($conn3, $FO5Data2);

	if (mysqli_num_rows($FO5DataRest2) > 0) {
		$FO5TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Post'";
		$FO5TotalDataRest2 = mysqli_query($conn3, $FO5TotalData2);
		$FO5TotalDatas2 = mysqli_fetch_assoc($FO5TotalDataRest2);

		$FO5Totals2 = $FO5TotalDatas2['ertm']+$FO5TotalDatas2['ertf'];

		$dataPointsFO5A2 = array(
			array("label" => "Frustration", "y" => (($FO5TotalDatas2['fttm']+$FO5TotalDatas2['fttf'])/$FO5Totals2)*100),
			array("label" => "Instructional", "y" => (($FO5TotalDatas2['ittm']+$FO5TotalDatas2['ittf'])/$FO5Totals2)*100),
			array("label" => "Idependent", "y" => (($FO5TotalDatas2['idtm']+$FO5TotalDatas2['idtf'])/$FO5Totals2)*100),
			array("label" => "Non-Reader", "y" => (($FO5TotalDatas2['nrtm']+$FO5TotalDatas2['nrtf'])/$FO5Totals2)*100)
		);

		$dataPointsFO5Aa2 = array(
			array("label" => "Frustration", "y" => ($FO5TotalDatas2['fttm']/$FO5TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO5TotalDatas2['ittm']/$FO5TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO5TotalDatas2['idtm']/$FO5TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO5TotalDatas2['nrtm']/$FO5TotalDatas2['ertm'])*100)
		);

		$dataPointsFO5Ab2 = array(
			array("label" => "Frustration", "y" => ($FO5TotalDatas2['fttf']/$FO5TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO5TotalDatas2['ittf']/$FO5TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO5TotalDatas2['idtf']/$FO5TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO5TotalDatas2['nrtf']/$FO5TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsFO5A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO5Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO5Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FO6

 	$FO6Data = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FO6DataRest = mysqli_query($conn3, $FO6Data);

	if (mysqli_num_rows($FO6DataRest) > 0) {
		$FO6TotalData = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FO6TotalDataRest = mysqli_query($conn3, $FO6TotalData);
		$FO6TotalDatas = mysqli_fetch_assoc($FO6TotalDataRest);

		$FO6Totals = $FO6TotalDatas['ertm']+$FO6TotalDatas['ertf'];

		$dataPointsFO6A = array(
			array("label" => "Frustration", "y" => (($FO6TotalDatas['fttm']+$FO6TotalDatas['fttf'])/$FO6Totals)*100),
			array("label" => "Instructional", "y" => (($FO6TotalDatas['ittm']+$FO6TotalDatas['ittf'])/$FO6Totals)*100),
			array("label" => "Idependent", "y" => (($FO6TotalDatas['idtm']+$FO6TotalDatas['idtf'])/$FO6Totals)*100),
			array("label" => "Non-Reader", "y" => (($FO6TotalDatas['nrtm']+$FO6TotalDatas['nrtf'])/$FO6Totals)*100)
		);

		$dataPointsFO6Aa = array(
			array("label" => "Frustration", "y" => ($FO6TotalDatas['fttm']/$FO6TotalDatas['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO6TotalDatas['ittm']/$FO6TotalDatas['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO6TotalDatas['idtm']/$FO6TotalDatas['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO6TotalDatas['nrtm']/$FO6TotalDatas['ertm'])*100)
		);

		$dataPointsFO6Ab = array(
			array("label" => "Frustration", "y" => ($FO6TotalDatas['fttf']/$FO6TotalDatas['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO6TotalDatas['ittf']/$FO6TotalDatas['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO6TotalDatas['idtf']/$FO6TotalDatas['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO6TotalDatas['nrtf']/$FO6TotalDatas['ertf'])*100)
		);
	}
	else{
		$dataPointsFO6A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO6Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO6Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FO6Data2 = "SELECT  * FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FO6DataRest2 = mysqli_query($conn3, $FO6Data2);

	if (mysqli_num_rows($FO6DataRest2) > 0) {
		$FO6TotalData2 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',
		SUM(ftmale) AS 'fttm', 
		SUM(ftfemale) AS 'fttf', 
		SUM(itmale) AS 'ittm', 
		SUM(itfemale) AS 'ittf', 
		SUM(idmale) AS 'idtm', 
		SUM(idfemale) AS 'idtf', 
		SUM(nrmale) AS 'nrtm', 
		SUM(nrfemale) AS 'nrtf'  
		FROM philirioral WHERE School = '$School' AND Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Post'";
		$FO6TotalDataRest2 = mysqli_query($conn3, $FO6TotalData2);
		$FO6TotalDatas2 = mysqli_fetch_assoc($FO6TotalDataRest2);

		$FO6Totals2 = $FO6TotalDatas2['ertm']+$FO6TotalDatas2['ertf'];

		$dataPointsFO6A2 = array(
			array("label" => "Frustration", "y" => (($FO6TotalDatas2['fttm']+$FO6TotalDatas2['fttf'])/$FO6Totals2)*100),
			array("label" => "Instructional", "y" => (($FO6TotalDatas2['ittm']+$FO6TotalDatas2['ittf'])/$FO6Totals2)*100),
			array("label" => "Idependent", "y" => (($FO6TotalDatas2['idtm']+$FO6TotalDatas2['idtf'])/$FO6Totals2)*100),
			array("label" => "Non-Reader", "y" => (($FO6TotalDatas2['nrtm']+$FO6TotalDatas2['nrtf'])/$FO6Totals2)*100)
		);

		$dataPointsFO6Aa2 = array(
			array("label" => "Frustration", "y" => ($FO6TotalDatas2['fttm']/$FO6TotalDatas2['ertm'])*100),
			array("label" => "Instructional", "y" => ($FO6TotalDatas2['ittm']/$FO6TotalDatas2['ertm'])*100),
			array("label" => "Idependent", "y" => ($FO6TotalDatas2['idtm']/$FO6TotalDatas2['ertm'])*100),
			array("label" => "Non-Reader", "y" => ($FO6TotalDatas2['nrtm']/$FO6TotalDatas2['ertm'])*100)
		);

		$dataPointsFO6Ab2 = array(
			array("label" => "Frustration", "y" => ($FO6TotalDatas2['fttf']/$FO6TotalDatas2['ertf'])*100),
			array("label" => "Instructional", "y" => ($FO6TotalDatas2['ittf']/$FO6TotalDatas2['ertf'])*100),
			array("label" => "Idependent", "y" => ($FO6TotalDatas2['idtf']/$FO6TotalDatas2['ertf'])*100),
			array("label" => "Non-Reader", "y" => ($FO6TotalDatas2['nrtf']/$FO6TotalDatas2['ertf'])*100)
		);
	}
	else{
		$dataPointsFO6A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO6Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFO6Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FS3

	$FSData3 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FSData3Rest = mysqli_query($conn3, $FSData3);

	if (mysqli_num_rows($FSData3Rest) > 0) {
		$FSTotalData3 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FSTotalData3Rest = mysqli_query($conn3, $FSTotalData3);
		$FS3PreDatas = mysqli_fetch_assoc($FSTotalData3Rest);

		$FS3TotalDatas = $FS3PreDatas['ertm']+$FS3PreDatas['ertf'];

		if ($FS3TotalDatas > 0) {

			$dataPointsFS3A = array(
				array("label" => "Slow", "y" => (($FS3PreDatas['sstm']+$FS3PreDatas['sstf'])/$FS3TotalDatas)*100),
				array("label" => "Average", "y" => (($FS3PreDatas['satm']+$FS3PreDatas['satf'])/$FS3TotalDatas)*100),
				array("label" => "Fast", "y" => (($FS3PreDatas['sftm']+$FS3PreDatas['sftf'])/$FS3TotalDatas)*100)
			);

			$dataPointsFS3B = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas['cfttm']+$FS3PreDatas['cfttf'])/$FS3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas['cittm']+$FS3PreDatas['cittf'])/$FS3TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas['cidtm']+$FS3PreDatas['cidtf'])/$FS3TotalDatas)*100)
			);

			$dataPointsFS3C = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas['rlfttm']+$FS3PreDatas['rlfttf'])/$FS3TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas['rlittm']+$FS3PreDatas['rlittf'])/$FS3TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas['rlidtm']+$FS3PreDatas['rlidtf'])/$FS3TotalDatas)*100)
			);
		}
		else{
			$dataPointsFS3A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS3C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS3PreDatas['ertm'] > 0) {

			$dataPointsFS3Aa = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['sstm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['satm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['sftm']/$FS3PreDatas['ertm'])*100)
			);

			$dataPointsFS3Ba = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['cfttm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['cittm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['cidtm']/$FS3PreDatas['ertm'])*100)
			);

			$dataPointsFS3Ca = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['rlfttm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['rlittm']/$FS3PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['rlidtm']/$FS3PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsFS3Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS3PreDatas['ertf'] > 0) {

			$dataPointsFS3Ab = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['sstf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['satf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['sftf']/$FS3PreDatas['ertf'])*100)
			);

			$dataPointsFS3Bb = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['cfttf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['cittf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['cidtf']/$FS3PreDatas['ertf'])*100)
			);

			$dataPointsFS3Cb = array(
				array("label" => "Slow", "y" => ($FS3PreDatas['rlfttf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas['rlittf']/$FS3PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas['rlidtf']/$FS3PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsFS3Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS3A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FSData32 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FSData3Rest2 = mysqli_query($conn3, $FSData32);

	if (mysqli_num_rows($FSData3Rest2) > 0) {
		$FSTotalData32 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post'";
		$FSTotalData3Rest2 = mysqli_query($conn3, $FSTotalData32);
		$FS3PreDatas2 = mysqli_fetch_assoc($FSTotalData3Rest2);

		$FS3TotalDatas2 = $FS3PreDatas2['ertm']+$FS3PreDatas2['ertf'];

		if ($FS3TotalDatas2 > 0) {

			$dataPointsFS3A2 = array(
				array("label" => "Slow", "y" => (($FS3PreDatas2['sstm']+$FS3PreDatas2['sstf'])/$FS3TotalDatas2)*100),
				array("label" => "Average", "y" => (($FS3PreDatas2['satm']+$FS3PreDatas2['satf'])/$FS3TotalDatas2)*100),
				array("label" => "Fast", "y" => (($FS3PreDatas2['sftm']+$FS3PreDatas2['sftf'])/$FS3TotalDatas2)*100)
			);

			$dataPointsFS3B2 = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas2['cfttm']+$FS3PreDatas2['cfttf'])/$FS3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas2['cittm']+$FS3PreDatas2['cittf'])/$FS3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas2['cidtm']+$FS3PreDatas2['cidtf'])/$FS3TotalDatas2)*100)
			);

			$dataPointsFS3C2 = array(
				array("label" => "Frustration", "y" => (($FS3PreDatas2['rlfttm']+$FS3PreDatas2['rlfttf'])/$FS3TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS3PreDatas2['rlittm']+$FS3PreDatas2['rlittf'])/$FS3TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS3PreDatas2['rlidtm']+$FS3PreDatas2['rlidtf'])/$FS3TotalDatas2)*100)
			);
		}
		else{
			$dataPointsFS3A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS3C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS3PreDatas2['ertm'] > 0) {

			$dataPointsFS3Aa2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['sstm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['satm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['sftm']/$FS3PreDatas2['ertm'])*100)
			);

			$dataPointsFS3Ba2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['cfttm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['cittm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['cidtm']/$FS3PreDatas2['ertm'])*100)
			);

			$dataPointsFS3Ca2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['rlfttm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['rlittm']/$FS3PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['rlidtm']/$FS3PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsFS3Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS3PreDatas2['ertf'] > 0) {

			$dataPointsFS3Ab2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['sstf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['satf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['sftf']/$FS3PreDatas2['ertf'])*100)
			);

			$dataPointsFS3Bb2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['cfttf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['cittf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['cidtf']/$FS3PreDatas2['ertf'])*100)
			);

			$dataPointsFS3Cb2 = array(
				array("label" => "Slow", "y" => ($FS3PreDatas2['rlfttf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS3PreDatas2['rlittf']/$FS3PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS3PreDatas2['rlidtf']/$FS3PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsFS3Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS3Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS3A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS3Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FS3

	$FSData4 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FSData4Rest = mysqli_query($conn3, $FSData4);

	if (mysqli_num_rows($FSData4Rest) > 0) {
		$FSTotalData4 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FSTotalData4Rest = mysqli_query($conn3, $FSTotalData4);
		$FS4PreDatas = mysqli_fetch_assoc($FSTotalData4Rest);

		$FS4TotalDatas = $FS4PreDatas['ertm']+$FS4PreDatas['ertf'];

		if ($FS4TotalDatas > 0) {

			$dataPointsFS4A = array(
				array("label" => "Slow", "y" => (($FS4PreDatas['sstm']+$FS4PreDatas['sstf'])/$FS4TotalDatas)*100),
				array("label" => "Average", "y" => (($FS4PreDatas['satm']+$FS4PreDatas['satf'])/$FS4TotalDatas)*100),
				array("label" => "Fast", "y" => (($FS4PreDatas['sftm']+$FS4PreDatas['sftf'])/$FS4TotalDatas)*100)
			);

			$dataPointsFS4B = array(
				array("label" => "Frustration", "y" => (($FS4PreDatas['cfttm']+$FS4PreDatas['cfttf'])/$FS4TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS4PreDatas['cittm']+$FS4PreDatas['cittf'])/$FS4TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS4PreDatas['cidtm']+$FS4PreDatas['cidtf'])/$FS4TotalDatas)*100)
			);

			$dataPointsFS4C = array(
				array("label" => "Frustration", "y" => (($FS4PreDatas['rlfttm']+$FS4PreDatas['rlfttf'])/$FS4TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS4PreDatas['rlittm']+$FS4PreDatas['rlittf'])/$FS4TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS4PreDatas['rlidtm']+$FS4PreDatas['rlidtf'])/$FS4TotalDatas)*100)
			);
		}
		else{
			$dataPointsFS4A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS4C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS4PreDatas['ertm'] > 0) {

			$dataPointsFS4Aa = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['sstm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['satm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['sftm']/$FS4PreDatas['ertm'])*100)
			);

			$dataPointsFS4Ba = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['cfttm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['cittm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['cidtm']/$FS4PreDatas['ertm'])*100)
			);

			$dataPointsFS4Ca = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['rlfttm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['rlittm']/$FS4PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['rlidtm']/$FS4PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsFS4Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS4PreDatas['ertf'] > 0) {

			$dataPointsFS4Ab = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['sstf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['satf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['sftf']/$FS4PreDatas['ertf'])*100)
			);

			$dataPointsFS4Bb = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['cfttf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['cittf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['cidtf']/$FS4PreDatas['ertf'])*100)
			);

			$dataPointsFS4Cb = array(
				array("label" => "Slow", "y" => ($FS4PreDatas['rlfttf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas['rlittf']/$FS4PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas['rlidtf']/$FS4PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsFS4Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS4A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FSData42 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 4 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FSData4Rest2 = mysqli_query($conn3, $FSData42);

	if (mysqli_num_rows($FSData4Rest2) > 0) {
		$FSTotalData42 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post'";
		$FSTotalData4Rest2 = mysqli_query($conn3, $FSTotalData42);
		$FS4PreDatas2 = mysqli_fetch_assoc($FSTotalData4Rest2);

		$FS4TotalDatas2 = $FS4PreDatas2['ertm']+$FS4PreDatas2['ertf'];

		if ($FS4TotalDatas2 > 0) {

			$dataPointsFS4A2 = array(
				array("label" => "Slow", "y" => (($FS4PreDatas2['sstm']+$FS4PreDatas2['sstf'])/$FS4TotalDatas2)*100),
				array("label" => "Average", "y" => (($FS4PreDatas2['satm']+$FS4PreDatas2['satf'])/$FS4TotalDatas2)*100),
				array("label" => "Fast", "y" => (($FS4PreDatas2['sftm']+$FS4PreDatas2['sftf'])/$FS4TotalDatas2)*100)
			);

			$dataPointsFS4B2 = array(
				array("label" => "Frustration", "y" => (($FS4PreDatas2['cfttm']+$FS4PreDatas2['cfttf'])/$FS4TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS4PreDatas2['cittm']+$FS4PreDatas2['cittf'])/$FS4TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS4PreDatas2['cidtm']+$FS4PreDatas2['cidtf'])/$FS4TotalDatas2)*100)
			);

			$dataPointsFS4C2 = array(
				array("label" => "Frustration", "y" => (($FS4PreDatas2['rlfttm']+$FS4PreDatas2['rlfttf'])/$FS4TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS4PreDatas2['rlittm']+$FS4PreDatas2['rlittf'])/$FS4TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS4PreDatas2['rlidtm']+$FS4PreDatas2['rlidtf'])/$FS4TotalDatas2)*100)
			);
		}
		else{
			$dataPointsFS4A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS4C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS4PreDatas2['ertm'] > 0) {

			$dataPointsFS4Aa2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['sstm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['satm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['sftm']/$FS4PreDatas2['ertm'])*100)
			);

			$dataPointsFS4Ba2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['cfttm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['cittm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['cidtm']/$FS4PreDatas2['ertm'])*100)
			);

			$dataPointsFS4Ca2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['rlfttm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['rlittm']/$FS4PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['rlidtm']/$FS4PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsFS4Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS4PreDatas2['ertf'] > 0) {

			$dataPointsFS4Ab2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['sstf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['satf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['sftf']/$FS4PreDatas2['ertf'])*100)
			);

			$dataPointsFS4Bb2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['cfttf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['cittf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['cidtf']/$FS4PreDatas2['ertf'])*100)
			);

			$dataPointsFS4Cb2 = array(
				array("label" => "Slow", "y" => ($FS4PreDatas2['rlfttf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS4PreDatas2['rlittf']/$FS4PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS4PreDatas2['rlidtf']/$FS4PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsFS4Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS4Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS4A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS4Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FS5

	$FSData5 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FSData5Rest = mysqli_query($conn3, $FSData5);

	if (mysqli_num_rows($FSData5Rest) > 0) {
		$FSTotalData5 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FSTotalData5Rest = mysqli_query($conn3, $FSTotalData5);
		$FS5PreDatas = mysqli_fetch_assoc($FSTotalData5Rest);

		$FS5TotalDatas = $FS5PreDatas['ertm']+$FS5PreDatas['ertf'];

		if ($FS5TotalDatas > 0) {

			$dataPointsFS5A = array(
				array("label" => "Slow", "y" => (($FS5PreDatas['sstm']+$FS5PreDatas['sstf'])/$FS5TotalDatas)*100),
				array("label" => "Average", "y" => (($FS5PreDatas['satm']+$FS5PreDatas['satf'])/$FS5TotalDatas)*100),
				array("label" => "Fast", "y" => (($FS5PreDatas['sftm']+$FS5PreDatas['sftf'])/$FS5TotalDatas)*100)
			);

			$dataPointsFS5B = array(
				array("label" => "Frustration", "y" => (($FS5PreDatas['cfttm']+$FS5PreDatas['cfttf'])/$FS5TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS5PreDatas['cittm']+$FS5PreDatas['cittf'])/$FS5TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS5PreDatas['cidtm']+$FS5PreDatas['cidtf'])/$FS5TotalDatas)*100)
			);

			$dataPointsFS5C = array(
				array("label" => "Frustration", "y" => (($FS5PreDatas['rlfttm']+$FS5PreDatas['rlfttf'])/$FS5TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS5PreDatas['rlittm']+$FS5PreDatas['rlittf'])/$FS5TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS5PreDatas['rlidtm']+$FS5PreDatas['rlidtf'])/$FS5TotalDatas)*100)
			);
		}
		else{
			$dataPointsFS5A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS5C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS5PreDatas['ertm'] > 0) {

			$dataPointsFS5Aa = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['sstm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['satm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['sftm']/$FS5PreDatas['ertm'])*100)
			);

			$dataPointsFS5Ba = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['cfttm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['cittm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['cidtm']/$FS5PreDatas['ertm'])*100)
			);

			$dataPointsFS5Ca = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['rlfttm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['rlittm']/$FS5PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['rlidtm']/$FS5PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsFS5Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS5PreDatas['ertf'] > 0) {

			$dataPointsFS5Ab = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['sstf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['satf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['sftf']/$FS5PreDatas['ertf'])*100)
			);

			$dataPointsFS5Bb = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['cfttf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['cittf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['cidtf']/$FS5PreDatas['ertf'])*100)
			);

			$dataPointsFS5Cb = array(
				array("label" => "Slow", "y" => ($FS5PreDatas['rlfttf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas['rlittf']/$FS5PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas['rlidtf']/$FS5PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsFS5Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS5A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FSData52 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 5 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FSData5Rest2 = mysqli_query($conn3, $FSData52);

	if (mysqli_num_rows($FSData5Rest2) > 0) {
		$FSTotalData52 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post'";
		$FSTotalData5Rest2 = mysqli_query($conn3, $FSTotalData52);
		$FS5PreDatas2 = mysqli_fetch_assoc($FSTotalData5Rest2);

		$FS5TotalDatas2 = $FS5PreDatas2['ertm']+$FS5PreDatas2['ertf'];

		if ($FS5TotalDatas2 > 0) {

			$dataPointsFS5A2 = array(
				array("label" => "Slow", "y" => (($FS5PreDatas2['sstm']+$FS5PreDatas2['sstf'])/$FS5TotalDatas2)*100),
				array("label" => "Average", "y" => (($FS5PreDatas2['satm']+$FS5PreDatas2['satf'])/$FS5TotalDatas2)*100),
				array("label" => "Fast", "y" => (($FS5PreDatas2['sftm']+$FS5PreDatas2['sftf'])/$FS5TotalDatas2)*100)
			);

			$dataPointsFS5B2 = array(
				array("label" => "Frustration", "y" => (($FS5PreDatas2['cfttm']+$FS5PreDatas2['cfttf'])/$FS5TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS5PreDatas2['cittm']+$FS5PreDatas2['cittf'])/$FS5TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS5PreDatas2['cidtm']+$FS5PreDatas2['cidtf'])/$FS5TotalDatas2)*100)
			);

			$dataPointsFS5C2 = array(
				array("label" => "Frustration", "y" => (($FS5PreDatas2['rlfttm']+$FS5PreDatas2['rlfttf'])/$FS5TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS5PreDatas2['rlittm']+$FS5PreDatas2['rlittf'])/$FS5TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS5PreDatas2['rlidtm']+$FS5PreDatas2['rlidtf'])/$FS5TotalDatas2)*100)
			);
		}
		else{
			$dataPointsFS5A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS5C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS5PreDatas2['ertm'] > 0) {

			$dataPointsFS5Aa2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['sstm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['satm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['sftm']/$FS5PreDatas2['ertm'])*100)
			);

			$dataPointsFS5Ba2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['cfttm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['cittm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['cidtm']/$FS5PreDatas2['ertm'])*100)
			);

			$dataPointsFS5Ca2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['rlfttm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['rlittm']/$FS5PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['rlidtm']/$FS5PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsFS5Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS5PreDatas2['ertf'] > 0) {

			$dataPointsFS5Ab2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['sstf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['satf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['sftf']/$FS5PreDatas2['ertf'])*100)
			);

			$dataPointsFS5Bb2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['cfttf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['cittf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['cidtf']/$FS5PreDatas2['ertf'])*100)
			);

			$dataPointsFS5Cb2 = array(
				array("label" => "Slow", "y" => ($FS5PreDatas2['rlfttf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS5PreDatas2['rlittf']/$FS5PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS5PreDatas2['rlidtf']/$FS5PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsFS5Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS5Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS5A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS5Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//FS6

	$FSData6 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Pre' ORDER BY Year";
	$FSData6Rest = mysqli_query($conn3, $FSData6);

	if (mysqli_num_rows($FSData6Rest) > 0) {
		$FSTotalData6 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Pre'";
		$FSTotalData6Rest = mysqli_query($conn3, $FSTotalData6);
		$FS6PreDatas = mysqli_fetch_assoc($FSTotalData6Rest);

		$FS6TotalDatas = $FS6PreDatas['ertm']+$FS6PreDatas['ertf'];

		if ($FS6TotalDatas > 0) {

			$dataPointsFS6A = array(
				array("label" => "Slow", "y" => (($FS6PreDatas['sstm']+$FS6PreDatas['sstf'])/$FS6TotalDatas)*100),
				array("label" => "Average", "y" => (($FS6PreDatas['satm']+$FS6PreDatas['satf'])/$FS6TotalDatas)*100),
				array("label" => "Fast", "y" => (($FS6PreDatas['sftm']+$FS6PreDatas['sftf'])/$FS6TotalDatas)*100)
			);

			$dataPointsFS6B = array(
				array("label" => "Frustration", "y" => (($FS6PreDatas['cfttm']+$FS6PreDatas['cfttf'])/$FS6TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS6PreDatas['cittm']+$FS6PreDatas['cittf'])/$FS6TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS6PreDatas['cidtm']+$FS6PreDatas['cidtf'])/$FS6TotalDatas)*100)
			);

			$dataPointsFS6C = array(
				array("label" => "Frustration", "y" => (($FS6PreDatas['rlfttm']+$FS6PreDatas['rlfttf'])/$FS6TotalDatas)*100),
				array("label" => "Instructional", "y" => (($FS6PreDatas['rlittm']+$FS6PreDatas['rlittf'])/$FS6TotalDatas)*100),
				array("label" => "Independent", "y" => (($FS6PreDatas['rlidtm']+$FS6PreDatas['rlidtf'])/$FS6TotalDatas)*100)
			);
		}
		else{
			$dataPointsFS6A = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6B = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS6C = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS6PreDatas['ertm'] > 0) {

			$dataPointsFS6Aa = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['sstm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['satm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['sftm']/$FS6PreDatas['ertm'])*100)
			);

			$dataPointsFS6Ba = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['cfttm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['cittm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['cidtm']/$FS6PreDatas['ertm'])*100)
			);

			$dataPointsFS6Ca = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['rlfttm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['rlittm']/$FS6PreDatas['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['rlidtm']/$FS6PreDatas['ertm'])*100)
			);
		}
		else{
			$dataPointsFS6Aa = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Ba = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Ca = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS6PreDatas['ertf'] > 0) {

			$dataPointsFS6Ab = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['sstf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['satf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['sftf']/$FS6PreDatas['ertf'])*100)
			);

			$dataPointsFS6Bb = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['cfttf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['cittf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['cidtf']/$FS6PreDatas['ertf'])*100)
			);

			$dataPointsFS6Cb = array(
				array("label" => "Slow", "y" => ($FS6PreDatas['rlfttf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas['rlittf']/$FS6PreDatas['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas['rlidtf']/$FS6PreDatas['ertf'])*100)
			);
		}
		else{
			$dataPointsFS6Ab = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Bb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Cb = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS6A = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Aa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ab = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6B = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ba = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Bb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6C = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ca = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Cb = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}

	$FSData62 = "SELECT  * FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 6 AND subject = 'Filipino' AND pORp = 'Post' ORDER BY Year";
	$FSData6Rest2 = mysqli_query($conn3, $FSData62);

	if (mysqli_num_rows($FSData6Rest2) > 0) {
		$FSTotalData62 = "SELECT 
		SUM(ermale) AS 'ertm', 
		SUM(erfemale) AS 'ertf',
		SUM(ptmale) AS 'pttm', 
		SUM(ptfemale) AS 'pttf',

		SUM(ssmale) AS 'sstm',
		SUM(ssfemale) AS 'sstf',
		SUM(samale) AS 'satm',
		SUM(safemale) AS 'satf',
		SUM(sfmale) AS 'sftm',
		SUM(sffemale) AS 'sftf',

		SUM(cftmale) AS 'cfttm',
		SUM(cftfemale) AS 'cfttf',
		SUM(citmale) AS 'cittm',
		SUM(citfemale) AS 'cittf',
		SUM(cidmale) AS 'cidtm',
		SUM(cidfemale) AS 'cidtf',

		SUM(rlftmale) AS 'rlfttm',
		SUM(rlftfemale) AS 'rlfttf',
		SUM(rlitmale) AS 'rlittm',
		SUM(rlitfemale) AS 'rlittf',
		SUM(rlidmale) AS 'rlidtm',
		SUM(rlidfemale) AS 'rlidtf'

		FROM philirisilent WHERE School = '$School' And Year = '$chosenTime2' AND Grade = 3 AND subject = 'Filipino' AND pORp = 'Post'";
		$FSTotalData6Rest2 = mysqli_query($conn3, $FSTotalData62);
		$FS6PreDatas2 = mysqli_fetch_assoc($FSTotalData6Rest2);

		$FS6TotalDatas2 = $FS6PreDatas2['ertm']+$FS6PreDatas2['ertf'];

		if ($FS6TotalDatas2 > 0) {

			$dataPointsFS6A2 = array(
				array("label" => "Slow", "y" => (($FS6PreDatas2['sstm']+$FS6PreDatas2['sstf'])/$FS6TotalDatas2)*100),
				array("label" => "Average", "y" => (($FS6PreDatas2['satm']+$FS6PreDatas2['satf'])/$FS6TotalDatas2)*100),
				array("label" => "Fast", "y" => (($FS6PreDatas2['sftm']+$FS6PreDatas2['sftf'])/$FS6TotalDatas2)*100)
			);

			$dataPointsFS6B2 = array(
				array("label" => "Frustration", "y" => (($FS6PreDatas2['cfttm']+$FS6PreDatas2['cfttf'])/$FS6TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS6PreDatas2['cittm']+$FS6PreDatas2['cittf'])/$FS6TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS6PreDatas2['cidtm']+$FS6PreDatas2['cidtf'])/$FS6TotalDatas2)*100)
			);

			$dataPointsFS6C2 = array(
				array("label" => "Frustration", "y" => (($FS6PreDatas2['rlfttm']+$FS6PreDatas2['rlfttf'])/$FS6TotalDatas2)*100),
				array("label" => "Instructional", "y" => (($FS6PreDatas2['rlittm']+$FS6PreDatas2['rlittf'])/$FS6TotalDatas2)*100),
				array("label" => "Independent", "y" => (($FS6PreDatas2['rlidtm']+$FS6PreDatas2['rlidtf'])/$FS6TotalDatas2)*100)
			);
		}
		else{
			$dataPointsFS6A2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6B2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);

			$dataPointsFS6C2 = array(
				array("label" => "Frustration", "y" => 0),
				array("label" => "Instructional", "y" => 0),
				array("label" => "Independent", "y" => 0)
			);
		}

		if ($FS6PreDatas2['ertm'] > 0) {

			$dataPointsFS6Aa2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['sstm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['satm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['sftm']/$FS6PreDatas2['ertm'])*100)
			);

			$dataPointsFS6Ba2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['cfttm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['cittm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['cidtm']/$FS6PreDatas2['ertm'])*100)
			);

			$dataPointsFS6Ca2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['rlfttm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['rlittm']/$FS6PreDatas2['ertm'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['rlidtm']/$FS6PreDatas2['ertm'])*100)
			);
		}
		else{
			$dataPointsFS6Aa2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Ba2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Ca2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}

		if ($FS6PreDatas2['ertf'] > 0) {

			$dataPointsFS6Ab2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['sstf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['satf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['sftf']/$FS6PreDatas2['ertf'])*100)
			);

			$dataPointsFS6Bb2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['cfttf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['cittf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['cidtf']/$FS6PreDatas2['ertf'])*100)
			);

			$dataPointsFS6Cb2 = array(
				array("label" => "Slow", "y" => ($FS6PreDatas2['rlfttf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Average", "y" => ($FS6PreDatas2['rlittf']/$FS6PreDatas2['ertf'])*100),
				array("label" => "Fast", "y" => ($FS6PreDatas2['rlidtf']/$FS6PreDatas2['ertf'])*100)
			);
		}
		else{
			$dataPointsFS6Ab2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Bb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);

			$dataPointsFS6Cb2 = array(
				array("label" => "Slow", "y" => 0),
				array("label" => "Average", "y" => 0),
				array("label" => "Fast", "y" => 0)
			);
		}			
	}
	else {
		$dataPointsFS6A2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Aa2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ab2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6B2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ba2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Bb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6C2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Ca2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsFS6Cb2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//Nutri
	$NutriData = "SELECT * FROM nutritionstatus WHERE School = '$School' AND Year = '$chosenTime3' ORDER BY Year";
	$NutriDataRest = mysqli_query($conn3, $NutriData);

	if (mysqli_num_rows($NutriDataRest) > 0) {
		$TotalNutriData = "SELECT 
		SUM(enmale) AS 'tm', 
		SUM(enfemale) AS 'tf', 

		SUM(pwmale) AS 'pwtm', 
		SUM(pwfemale) AS 'pwtf', 
		SUM(bmiswmale) AS 'bmiswtm', 
		SUM(bmiswfemale) AS 'bmiswtf',
		SUM(bmiwmale) AS 'bmiwtm', 
		SUM(bmiwfemale) AS 'bmiwtf',
		SUM(bminmale) AS 'bmintm', 
		SUM(bminfemale) AS 'bmintf',
		SUM(bmiowmale) AS 'bmiowtm', 
		SUM(bmiowfemale) AS 'bmiowtf',
		SUM(bmiomale) AS 'bmiotm', 
		SUM(bmiofemale) AS 'bmiotf',

		SUM(hfassmale) AS 'hfasstm',
		SUM(hfassfemale) AS 'hfasstf',
		SUM(hfasmale) AS 'hfastm',
		SUM(hfasfemale) AS 'hfastf',
		SUM(hfanmale) AS 'hfantm',
		SUM(hfanfemale) AS 'hfantf',
		SUM(hfatmale) AS 'hfattm',
		SUM(hfatfemale) AS 'hfattf',
		SUM(pthmale) AS 'pthtm',
		SUM(pthfemale) AS 'pthtf'
		
		FROM nutritionstatus Where School = '$School' AND Year = '$chosenTime3'";
		$TotalNutriDataRest = mysqli_query($conn3, $TotalNutriData);
		$TotalNutriDatas = mysqli_fetch_assoc($TotalNutriDataRest);

		$NutriTotals = $TotalNutriDatas['tm']+$TotalNutriDatas['tf'];

		$dataPointsNutriA = array(
			array("label" => "Severely Wasted", "y" => (($TotalNutriDatas['bmiswtm']+$TotalNutriDatas['bmiswtf'])/$NutriTotals)*100),
			array("label" => "Wasted", "y" => (($TotalNutriDatas['bmiwtm']+$TotalNutriDatas['bmiwtf'])/$NutriTotals)*100),
			array("label" => "Normal", "y" => (($TotalNutriDatas['bmintm']+$TotalNutriDatas['bmintf'])/$NutriTotals)*100),
			array("label" => "Overweight", "y" => (($TotalNutriDatas['bmiowtm']+$TotalNutriDatas['bmiowtf'])/$NutriTotals)*100),
			array("label" => "Obese", "y" => (($TotalNutriDatas['bmiotm']+$TotalNutriDatas['bmiotf'])/$NutriTotals)*100)
		);

		$dataPointsNutriAa = array(
			array("label" => "Severely Wasted", "y" => ($TotalNutriDatas['bmiswtm']/$TotalNutriDatas['pwtm'])*100),
			array("label" => "Wasted", "y" => ($TotalNutriDatas['bmiwtm']/$TotalNutriDatas['pwtm'])*100),
			array("label" => "Normal", "y" => ($TotalNutriDatas['bmintm']/$TotalNutriDatas['pwtm'])*100),
			array("label" => "Overweight", "y" => ($TotalNutriDatas['bmiowtm']/$TotalNutriDatas['pwtm'])*100),
			array("label" => "Obese", "y" => ($TotalNutriDatas['bmiotm']/$TotalNutriDatas['pwtm'])*100)
		);	
		$dataPointsNutriAb = array(
			array("label" => "Severely Wasted", "y" => ($TotalNutriDatas['bmiswtf']/$TotalNutriDatas['pwtf'])*100),
			array("label" => "Wasted", "y" => ($TotalNutriDatas['bmiwtf']/$TotalNutriDatas['pwtf'])*100),
			array("label" => "Normal", "y" => ($TotalNutriDatas['bmintf']/$TotalNutriDatas['pwtf'])*100),
			array("label" => "Overweight", "y" => ($TotalNutriDatas['bmiowtf']/$TotalNutriDatas['pwtf'])*100),
			array("label" => "Obese", "y" => ($TotalNutriDatas['bmiotf']/$TotalNutriDatas['pwtf'])*100)
		);

		$dataPointsNutriAc = array(
			array("label" => "Male Weighted", "y" => ($TotalNutriDatas['pwtm']/$TotalNutriDatas['tm'])*100)
		);

		$dataPointsNutriAd = array(
			array("label" => "Female Weighted", "y" => ($TotalNutriDatas['pwtf']/$TotalNutriDatas['tf'])*100)
		);

		$dataPointsNutriA2 = array(
			array("label" => "Severely Stunted", "y" => (($TotalNutriDatas['hfasstm']+$TotalNutriDatas['hfasstf'])/$NutriTotals)*100),
			array("label" => "Stunted", "y" => (($TotalNutriDatas['hfastm']+$TotalNutriDatas['hfastf'])/$NutriTotals)*100),
			array("label" => "Normal", "y" => (($TotalNutriDatas['hfantm']+$TotalNutriDatas['hfantf'])/$NutriTotals)*100),
			array("label" => "Tall", "y" => (($TotalNutriDatas['hfattm']+$TotalNutriDatas['hfattf'])/$NutriTotals)*100)
		);	

		$dataPointsNutriA2a = array(
			array("label" => "Severely Stunted", "y" => ($TotalNutriDatas['hfasstm']/$TotalNutriDatas['pthtm'])*100),
			array("label" => "Stunted", "y" => ($TotalNutriDatas['hfastm']/$TotalNutriDatas['pthtm'])*100),
			array("label" => "Normal", "y" => ($TotalNutriDatas['hfantm']/$TotalNutriDatas['pthtm'])*100),
			array("label" => "Tall", "y" => ($TotalNutriDatas['hfattm']/$TotalNutriDatas['pthtm'])*100)
		);	
		$dataPointsNutriA2b = array(
			array("label" => "Severely Stunted", "y" => ($TotalNutriDatas['hfasstf']/$TotalNutriDatas['pthtf'])*100),
			array("label" => "Stunted", "y" => ($TotalNutriDatas['hfastf']/$TotalNutriDatas['pthtf'])*100),
			array("label" => "Normal", "y" => ($TotalNutriDatas['hfantf']/$TotalNutriDatas['pthtf'])*100),
			array("label" => "Tall", "y" => ($TotalNutriDatas['hfattf']/$TotalNutriDatas['pthtf'])*100)
		);	
		$dataPointsNutriA2c = array(
			array("label" => "Male Height Taken", "y" => ($TotalNutriDatas['pthtm']/$TotalNutriDatas['tm'])*100)
		);	
		$dataPointsNutriA2d = array(
			array("label" => "Female Hieght Taken", "y" => ($TotalNutriDatas['pthtf']/$TotalNutriDatas['tf'])*100)
		);	
	}
	else{
		$dataPointsNutriA = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriAa = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriAb = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriAc = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriAd = array( 
			array("label" => "No Data", "y" => 0 )
		);

		$dataPointsNutriA2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriA2a = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriA2b = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriA2c = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPointsNutriA2d = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
//4p
	//Bar
	$barData4P = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School' AND Year <= '$chosenTime4' GROUP BY Year";
	$barData4PRes = mysqli_query($conn3, $barData4P);
	if (mysqli_num_rows($barData4PRes) > 0) {

		$dataPoints4P1 = array();
		while($bar4PDatas = mysqli_fetch_array($barData4PRes)) {   
		  array_push($dataPoints4P1, array("y" => $bar4PDatas['m']+$bar4PDatas['f'], "label" => $bar4PDatas['Year']));
		}

		$barData4P2 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School' AND Year <= '$chosenTime4' GROUP BY Year";
		$barData4PRes2 = mysqli_query($conn3, $barData4P2);

		$dataPoints4P2 = array();
		while($bar4PDatas2 = mysqli_fetch_array($barData4PRes2)) {   
		  array_push($dataPoints4P2, array("y" => $bar4PDatas2['m'], "label" => $bar4PDatas2['Year']));
		}

		$barData4P3 = "SELECT SUM(Male) as m, SUM(Female) as f, Year FROM distric4ps Where School = '$School'AND Year <= '$chosenTime4'  GROUP BY Year";
		$barData4PRes3 = mysqli_query($conn3, $barData4P3);

		$dataPoints4P3 = array();
		while($bar4PDatas3 = mysqli_fetch_array($barData4PRes3)) {   
		  array_push($dataPoints4P3, array("y" => $bar4PDatas3['f'], "label" => $bar4PDatas3['Year']));
		}
	}
	else {
		$dataPoints4P1 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P2 = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P3 = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Pie
	$PieData4P = "SELECT * FROM distric4ps WHERE School = '$School' AND Year = '$chosenTime4' ";
	$PieData4PRest = mysqli_query($conn3, $PieData4P);

	if (mysqli_num_rows($PieData4PRest) > 0) {

		$PieTotal4P = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM distric4ps Where Groups = 'Elementary' AND Year = '$chosenTime4'";
		$PieTotal4PRest = mysqli_query($conn3, $PieTotal4P);
		$PieTotal4PData = mysqli_fetch_assoc($PieTotal4PRest);

		$Pie4PTotal = $PieTotal4PData['tm']+$PieTotal4PData['tf'];
		
		$PieData4P1 =  mysqli_fetch_assoc($PieData4PRest);
		$dataPoints4P1p = array(
			array("label" => $PieData4P1['School'], "y" => (($PieData4P1['Male']+$PieData4P1['Female'])/$Pie4PTotal)*100),
			array("label" => " ", "y" => (($Pie4PTotal-($PieData4P1['Male']+$PieData4P1['Female']))/$Pie4PTotal)*100)
		);

		$dataPoints4P1d = array(
			array("label" => "Female", "y" => ($PieData4P1['Female']/($PieData4P1['Female']+$PieData4P1['Male']))*100),
			array("label" => "Male", "y" => ($PieData4P1['Male']/($PieData4P1['Female']+$PieData4P1['Male']))*100));
	}
	else {
		$dataPoints4P1p = array( 
			array("label" => "No Data", "y" => 0 )
		);
		$dataPoints4P1d = array( 
			array("label" => "No Data", "y" => 0 )
		);
	}
	//Doughnut
?>