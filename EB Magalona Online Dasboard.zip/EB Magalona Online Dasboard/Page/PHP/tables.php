<?php
//gross
	$es = "Elementary";

	//Elementary

	$maxx = "SELECT * FROM `{$tabName}` WhERE Groups = '$es' And Year >= '$chosenTime'-6 And Year <= '$chosenTime' ORDER BY Year DESC LIMIT 1;";
	$result2 = mysqli_query($conn3, $maxx);
	$rows2 = mysqli_fetch_array($result2);

	$minn = "SELECT * FROM `{$tabName}` WhERE Groups = '$es' And Year >= '$chosenTime'-6 And Year <= '$chosenTime' ORDER BY Year LIMIT 1;";
	$result1 = mysqli_query($conn3, $minn);
	$rows1 = mysqli_fetch_array($result1);

	if (mysqli_num_rows($result2) > 0) {
		$max = $rows2['Year'];
		$min = $rows1['Year'];
	}
	else{
		$max = " ";
		$min = " ";
	}

	$gros = "SELECT * FROM `{$tabName}` WhERE Groups = '$es' GROUP BY School ORDER BY School ASC";
	$gros1 = "SELECT * FROM `{$tabName}` WhERE Groups = '$es' ORDER BY School";
	$results = mysqli_query($conn3, $gros);
	$results1 = mysqli_query($conn3, $gros1);
	$ttalgrs = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` WhERE Groups = '$es' GROUP BY Year";
	$ttresult = mysqli_query($conn3, $ttalgrs);

	//HighSchool

	$hs = "Highschool";

	$maxxh = "SELECT * FROM `{$tabName}` WhERE Groups = '$hs' And Year >= '$chosenTime2'-6 And Year <= '$chosenTime2' ORDER BY Year DESC LIMIT 1;";
	$result2h = mysqli_query($conn3, $maxxh);
	$rows2h = mysqli_fetch_array($result2h);

	$minnh = "SELECT * FROM `{$tabName}` WhERE Groups = '$hs' And Year >= '$chosenTime2'-6 And Year <= '$chosenTime2' ORDER BY Year LIMIT 1;";
	$result1h = mysqli_query($conn3, $minnh);
	$rows1h = mysqli_fetch_array($result1h);

	if (mysqli_num_rows($result2h) > 0) {
		$maxh = $rows2h['Year'];
		$minh = $rows1h['Year'];
	}
	else{
		$maxh = " ";
		$minh = " ";
	}

	$grosh = "SELECT * FROM `{$tabName}` WhERE Groups = '$hs' GROUP BY School ORDER BY School ASC";
	$gros1h = "SELECT * FROM `{$tabName}` WhERE Groups = '$hs' ORDER BY School";
	$resultsh = mysqli_query($conn3, $grosh);
	$results1h = mysqli_query($conn3, $gros1h);
	$ttalgrsh = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` WhERE Groups = '$hs' GROUP BY Year";
	$ttresulth = mysqli_query($conn3, $ttalgrsh);

	//Private

	$ps = "Private";

	$maxxp = "SELECT * FROM `{$tabName}` WhERE Groups = '$ps' And Year >= '$chosenTime3'-6 And Year <= '$chosenTime3' ORDER BY Year DESC LIMIT 1;";
	$result2p = mysqli_query($conn3, $maxxp);
	$rows2p = mysqli_fetch_array($result2p);

	$minnp = "SELECT * FROM `{$tabName}` WhERE Groups = '$ps' And Year >= '$chosenTime3'-6 And Year <= '$chosenTime3' ORDER BY Year LIMIT 1;";
	$result1p = mysqli_query($conn3, $minnp);
	$rows1p = mysqli_fetch_array($result1p);

	if (mysqli_num_rows($result2p) > 0) {
		$maxp = $rows2p['Year'];
		$minp = $rows1p['Year'];
	}
	else{
		$maxp = " ";
		$minp = " ";
	}

	$grosp = "SELECT * FROM `{$tabName}` WhERE Groups = '$ps' GROUP BY School ORDER BY School ASC";
	$gros1p = "SELECT * FROM `{$tabName}` WhERE Groups = '$ps' ORDER BY School ASC";
	$resultsp = mysqli_query($conn3, $grosp);
	$results1p = mysqli_query($conn3, $gros1p);
	$ttalgrsp = "SELECT SUM(Male) AS 'tm', SUM(Female) AS 'tf' FROM `{$tabName}` WhERE Groups = '$ps' GROUP BY Year";
	$ttresultp = mysqli_query($conn3, $ttalgrsp);

?>