<?php
session_start();
include "PHP/connect.php";

if (!isset($_SESSION["usename"])) {
	header('Location: ../index.php?error=InvalidEntry');
}

$getschool1 = "SELECT * FROM elemAdmin ORDER BY school ASC";
$getQuery1 = mysqli_query($conn2, $getschool1);
$getRow1 = mysqli_num_rows($getQuery1);

$getschool2 = "SELECT * FROM highAdmin ORDER BY school ASC";
$getQuery2 = mysqli_query($conn2, $getschool2);
$getRow2 = mysqli_num_rows($getQuery2);

$getschool3 = "SELECT * FROM privateAdmin ORDER BY school ASC";
$getQuery3 = mysqli_query($conn2, $getschool3);
$getRow3 = mysqli_num_rows($getQuery3);

?>

<!DOCTYPE html>
<html>
<title>EB Magalona Dashboard</title>
<head>
	<link rel="stylesheet" href="CSS/headercss.css" type="text/css">
	<link rel="stylesheet" href="CSS/diffPages.css" type="text/css">
	<link rel="stylesheet" href="CSS/IndiPage.css" type="text/css">
	<script type="text/javascript" src="Script/jquery-3.6.0.js"></script>
  	<script type="text/javascript" src="Script/headerScript.js"></script>
  	<script type="text/javascript" src="Script/headerQuery.js"></script>
  	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
  	<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
  	<script src="https://kit.fontawesome.com/9b2509c5e6.js" crossorigin="anonymous"></script>
</head>
<body> 

<div class="NavBar">
	<div class="NavBarCon1">
		<img src="Images/icon.jpg" class="icon">

		<div class="user">
			<div class="imgCon">
				<img src="Images/AdminImages/user.png" class="useicon" id="iconHide">
				<img src="Images/AdminImages/user.png" class="useicon" id="iconOut" style="display: none;">
				<div class="usedrop">
					<div class="profileHold">
						<img class="useicon2" src="Images/AdminImages/user.png">
						<h3>Admin <?php echo $_SESSION['fname']." ".$_SESSION['midname'].". ".$_SESSION['lastname'] ?></h3>
					</div>
					<form class="buttonHold" action="PHP/transfer.php" method="POST">
						<button type="Submit" name="useSet">User Settings</button>
						<button type="Submit" name="secSet">Security Settings</button>
						<button class="outbut" type="button">Logout</button>
					</form>
				</div>
			</div>
			<div class="usen">
				<h2>Welcome <?php if($_SESSION['mygender'] = "Male"){echo "Mr. ";}else{echo "Ms. ";} echo $_SESSION['fname']; ?></h2>
				<h3><?php echo "School ".$_SESSION['myposition']; ?></h3>
			</div>
		</div>
	</div>

	<div class="NavBarCon2">
		<ul class="nabList">
		  <li>
		  	<button class="tablinks4" onclick="changeE4(event, 'Grade3')" style="border-left: 1px solid #bbb;"> Performance Indicators</button>
		  </li>
		  
		  <li>
		  	<button class="tablinks4" onclick="changeE4(event, 'Grade4')">District Phil-Iri</button>
		  </li>

		  <li>
		  	<button Class="tablinks4" onclick="changeE4(event, 'Grade5')">Nutritional Status</i></button>
		  </li>

		  <li>
		  	<button Class="tablinks4" onclick="changeE4(event, 'Grade6')">District 4P's Benificiaries</i></button>
		  </li>
		</ul>

	<div id="logoutModal">
		<span class="close">&times;</span>
		<div class="logouttab">
			<h1>Logout?</h1>
			<form action="PHP/transfer.php" method="POST">
				<button type="Submit" name="logout" style="margin-right: 5%;">Yes</button>
				<button class="No" type="button" style="margin-left: 5%;">No</button>
			</form>
		</div>
	</div>
</div>

<script>
// Get the modal
var modal = document.getElementById("logoutModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>