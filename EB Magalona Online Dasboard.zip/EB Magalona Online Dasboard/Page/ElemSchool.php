<?php

include "Header.php";

$School = $_SESSION['School'];
$Display = $_SESSION['display'];
$Display2 = $_SESSION['display2'];

if ($_SESSION['timeMaxG'] != "None") {
	$grossmin = $_SESSION['timeMinG'];
	$grossmax = $_SESSION['timeMaxG'];
}
else{
	$grossmin = date('Y');
	$grossmax = date('Y');
}

if ($_SESSION['timeMinEO'] != "None" && $_SESSION['timeMinEO'] <= $_SESSION['timeMinFO'] 
	&& $_SESSION['timeMinEO'] <= $_SESSION['timeMinES'] && $_SESSION['timeMinEO'] <= $_SESSION['timeMinFS']) {
	$PIEOMin = $_SESSION['timeMinEO'];
}
elseif ($_SESSION['timeMinES'] != "None" && $_SESSION['timeMinES'] <= $_SESSION['timeMinEO'] 
	&& $_SESSION['timeMinES'] <= $_SESSION['timeMinFO'] && $_SESSION['timeMinES'] <= $_SESSION['timeMinFS']) {
	$PIEOMin = $_SESSION['timeMinES'];
}
elseif ($_SESSION['timeMinFO'] != "None" && $_SESSION['timeMinFO'] <= $_SESSION['timeMinEO'] 
	&& $_SESSION['timeMinFO'] <= $_SESSION['timeMinES'] && $_SESSION['timeMinFO'] <= $_SESSION['timeMinFS']) {
	$PIEOMin = $_SESSION['timeMinFO'];
}
elseif ($_SESSION['timeMinFS'] != "None" && $_SESSION['timeMinFS'] <= $_SESSION['timeMinEO'] 
	&& $_SESSION['timeMinFS'] <= $_SESSION['timeMinES'] && $_SESSION['timeMinFS'] <= $_SESSION['timeMinFO']) {
	$PIEOMin = $_SESSION['timeMinFS'];
}
else{
	$PIEOMin = 2015;
}

$PIMin = $PIEOMin;

if ($_SESSION['timeMaxEO'] != "None" && $_SESSION['timeMaxEO'] >= $_SESSION['timeMaxFO'] 
	&& $_SESSION['timeMaxEO'] >= $_SESSION['timeMaxES'] && $_SESSION['timeMaxEO'] >= $_SESSION['timeMaxFS']) {
	$PIEOMax = $_SESSION['timeMaxEO'];
}
elseif ($_SESSION['timeMaxES'] != "None" && $_SESSION['timeMaxES'] >= $_SESSION['timeMaxEO'] 
	&& $_SESSION['timeMaxES'] >= $_SESSION['timeMaxFO'] && $_SESSION['timeMaxES'] >= $_SESSION['timeMaxFS']) {
	$PIEOMax = $_SESSION['timeMaxES'];
}
elseif ($_SESSION['timeMaxFO'] != "None" && $_SESSION['timeMaxFO'] >= $_SESSION['timeMaxEO'] 
	&& $_SESSION['timeMaxFO'] >= $_SESSION['timeMaxES'] && $_SESSION['timeMaxFO'] >= $_SESSION['timeMaxFS']) {
	$PIEOMax = $_SESSION['timeMaxFO'];
}
elseif ($_SESSION['timeMaxFS'] != "None" && $_SESSION['timeMaxFS'] >= $_SESSION['timeMaxEO'] 
	&& $_SESSION['timeMaxFS'] >= $_SESSION['timeMaxES'] && $_SESSION['timeMaxFS'] >= $_SESSION['timeMaxFO']) {
	$PIEOMax = $_SESSION['timeMaxFS'];
}
else{
	$PIEOMax = date('Y');
}

$PIMax = $PIEOMax;

if ($_SESSION['timeMaxNS'] != "None") {
	$grossminNS = $_SESSION['timeMinNS'];
	$grossmaxNS = $_SESSION['timeMaxNS'];
}
else{
	$grossminNS = date('Y');
	$grossmaxNS = date('Y');
}

if ($_SESSION['timeMax4p'] != "None") {
	$grossmin4p = $_SESSION['timeMin4p'];
	$grossmax4p = $_SESSION['timeMax4p'];
}
else{
	$grossmin4p = date('Y');
	$grossmax4p = date('Y');
}

if(isset($_SESSION['theTime']))
{
    $chosenTime = $_SESSION['theTime'];
}
else{
	$chosenTime = $grossmax;
}

if(isset($_SESSION['theTime2']))
{
    $chosenTime2 = $_SESSION['theTime2'];
}
else{
	$chosenTime2 = $PIMax;
}

if(isset($_SESSION['theTime3']))
{
    $chosenTime3 = $_SESSION['theTime3'];
}
else{
	$chosenTime3 = $grossmaxNS;
}

if(isset($_SESSION['theTime4']))
{
    $chosenTime4 = $_SESSION['theTime4'];
}
else{
	$chosenTime4 = $grossmax4p;
}

$group = "Elementary";

include "PHP/EGraph.php";

$TitleG = $School." Gross Enrolment Rate (".$grossmax.")";
$TitleG2 = $School." Gross Enrolment Overal Distric Percentage (".$grossmax.")";
$TitleG3 = $School." Gross Enrolment Male to Female Ratio (".$grossmax.")";

$Title4P2 = $School." 4Ps Benificiaries Overal Distric Percentage (".$grossmax4p.")";
$Title4P3 = $School." 4Ps Benificiaries Male to Female Ratio (".$grossmax4p.")";
$Title4P = $School." 4Ps Benificiaries (".$grossmax4p.")";
$label = "Number of students";

//pre
	$TitleEO3 = $School." Phil-Iri English Oral Grade 3 Pre Results(".$PIMax.")";
	$TitleEO3a = $School." Phil-Iri English Oral Grade 3 Male Pre Results(".$PIMax.")";
	$TitleEO3b = $School." Phil-Iri English Oral Grade 3 Female Pre Results(".$PIMax.")";
	$TitleEO4 = $School." Phil-Iri English Oral Grade 4 Results(".$PIMax.")";
	$TitleEO4a = $School." Phil-Iri English Oral Grade 4 Male Pre Results(".$PIMax.")";
	$TitleEO4b = $School." Phil-Iri English Oral Grade 4 Female Pre Results(".$PIMax.")";
	$TitleEO5 = $School." Phil-Iri English Oral Grade 5 Results(".$PIMax.")";
	$TitleEO5a = $School." Phil-Iri English Oral Grade 5 Male Pre Results(".$PIMax.")";
	$TitleEO5b = $School." Phil-Iri English Oral Grade 5 Female Pre Results(".$PIMax.")";
	$TitleEO6 = $School." Phil-Iri English Oral Grade 6 Results(".$PIMax.")";
	$TitleEO6a = $School." Phil-Iri English Oral Grade 6 Male Pre Results(".$PIMax.")";
	$TitleEO6b = $School." Phil-Iri English Oral Grade 6 Female Pre Results(".$PIMax.")";
	$TitleFO3 = $School." Phil-Iri Filipino Oral Grade 3 Pre Results(".$PIMax.")";
	$TitleFO3a = $School." Phil-Iri Filipino Oral Grade 3 Male Pre Results(".$PIMax.")";
	$TitleFO3b = $School." Phil-Iri Filipino Oral Grade 3 Female Pre Results(".$PIMax.")";
	$TitleFO4 = $School." Phil-Iri Filipino Oral Grade 4 Results(".$PIMax.")";
	$TitleFO4a = $School." Phil-Iri Filipino Oral Grade 4 Male Pre Results(".$PIMax.")";
	$TitleFO4b = $School." Phil-Iri Filipino Oral Grade 4 Female Pre Results(".$PIMax.")";
	$TitleFO5 = $School." Phil-Iri Filipino Oral Grade 5 Pre Results(".$PIMax.")";
	$TitleFO5a = $School." Phil-Iri Filipino Oral Grade 5 Male Pre Results(".$PIMax.")";
	$TitleFO5b = $School." Phil-Iri Filipino Oral Grade 5 Female Pre Results(".$PIMax.")";
	$TitleFO6 = $School." Phil-Iri Filipino Oral Grade 6 Pre Results(".$PIMax.")";
	$TitleFO6a = $School." Phil-Iri Filipino Oral Grade 6 Male Pre Results(".$PIMax.")";
	$TitleFO6b = $School." Phil-Iri Filipino Oral Grade 6 Female Pre Results(".$PIMax.")";
//post
	$TitleEO32 = $School." Phil-Iri English Oral Grade 3 Post Results(".$PIMax.")";
	$TitleEO32a = $School." Phil-Iri English Oral Grade 3 Male Post Results(".$PIMax.")";
	$TitleEO32b = $School." Phil-Iri English Oral Grade 3 Female Post Results(".$PIMax.")";
	$TitleEO42 = $School." Phil-Iri English Oral Grade 4 Results(".$PIMax.")";
	$TitleEO42a = $School." Phil-Iri English Oral Grade 4 Male Post Results(".$PIMax.")";
	$TitleEO42b = $School." Phil-Iri English Oral Grade 4 Female Post Results(".$PIMax.")";
	$TitleEO52 = $School." Phil-Iri English Oral Grade 5 Results(".$PIMax.")";
	$TitleEO52a = $School." Phil-Iri English Oral Grade 5 Male Post Results(".$PIMax.")";
	$TitleEO52b = $School." Phil-Iri English Oral Grade 5 Female Post Results(".$PIMax.")";
	$TitleEO62 = $School." Phil-Iri English Oral Grade 6 Results(".$PIMax.")";
	$TitleEO62a = $School." Phil-Iri English Oral Grade 6 Male Post Results(".$PIMax.")";
	$TitleEO62b = $School." Phil-Iri English Oral Grade 6 Female Post Results(".$PIMax.")";
	
	$TitleFO32 = $School." Phil-Iri Filipino Oral Grade 3 Post Results(".$PIMax.")";
	$TitleFO32a = $School." Phil-Iri Filipino Oral Grade 3 Male Post Results(".$PIMax.")";
	$TitleFO32b = $School." Phil-Iri Filipino Oral Grade 3 Female Post Results(".$PIMax.")";
	$TitleFO42 = $School." Phil-Iri Filipino Oral Grade 4 Results(".$PIMax.")";
	$TitleFO42a = $School." Phil-Iri Filipino Oral Grade 4 Male Post Results(".$PIMax.")";
	$TitleFO42b = $School." Phil-Iri Filipino Oral Grade 4 Female Post Results(".$PIMax.")";
	$TitleFO52 = $School." Phil-Iri Filipino Oral Grade 5 Post Results(".$PIMax.")";
	$TitleFO52a = $School." Phil-Iri Filipino Oral Grade 5 Male Post Results(".$PIMax.")";
	$TitleFO52b = $School." Phil-Iri Filipino Oral Grade 5 Female Post Results(".$PIMax.")";
	$TitleFO62 = $School." Phil-Iri Filipino Oral Grade 6 Post Results(".$PIMax.")";
	$TitleFO62a = $School." Phil-Iri Filipino Oral Grade 6 Male Post Results(".$PIMax.")";
	$TitleFO62b = $School." Phil-Iri Filipino Oral Grade 6 Female Post Results(".$PIMax.")";

$TitleNS1 = $School." Nutirtional Status ".$grossmaxNS." (BMI)";
$TitleNS1a = $School." Male BMI Results (".$grossmaxNS.")";
$TitleNS1b = $School." Female BMI Results (".$grossmaxNS.")";
$TitleNS2 = $School." Nutirtional Status ".$grossmaxNS." (HFA)";
$TitleNS2a = $School." Male HFA Results (".$grossmaxNS.")";
$TitleNS2b = $School." Female HFA Results (".$grossmaxNS.")";

$TitleN = $School." Net Enrollment Rate (".$grossmax.")";
$TitleD = $School." Drop Rate (".$grossmax.")";
$TitleS = $School." Survival Rate (".$grossmax.")";
$TitleF = $School." Failure Rate (".$grossmax.")";
$TitleC = $School." Completion Rate (".$grossmax.")";
$TitleRT = $School." Retention Rate (".$grossmax.")";
$TitleGD = $School." Graduation Rate (".$grossmax.")";
$TitlePR = $School." Promotion Rate (".$grossmax.")";
$TitleRP = $School." Repeatition Rate (".$grossmax.")";
$labelx = "Students Percentage";
?>

<script>	
window.onload = function() {

	CanvasJS.addColorSet("dataColors",
	[//colorSet Array
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#0086b3",
        "#40ff00",
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90"                
    ]);

    CanvasJS.addColorSet("dataColors2",
	[//colorSet Array
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#ffff00",
        "#0086b3",
        "#40ff00",
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d"              
    ]);

    CanvasJS.addColorSet("dataColors3",
	[//colorSet Array
        "#8a8a5c",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#669999",
        "#3CB371",
        "#90EE90",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#00b3b3",
        "#804000",
        "#cc0099",
        "#0086b3",
        "#40ff00"                
    ]);

     CanvasJS.addColorSet("dataColors4",
	[//colorSet Array
		"#cc0099",
        "#3CB371",
        "#ff0000",
        "#0000ff",
        "#00b300",
        "#cccc00",
        "#6600ff",
        "#993399",
        "#90EE90",
        "#003399",
        "#00994d",
        "#ffff00",
        "#2E8B57",
        "#00ff00",
        "#cca300",
        "#0000b3",
        "#b30047",
        "#e62e00",
        "#008080",
        "#6666ff",
        "#8a8a5c",
        "#669999",
        "#00b3b3",
        "#804000",
        "#0086b3",
        "#40ff00"                
    ]);


//gross
	//bar
	var chartG1 = new CanvasJS.Chart("chartContainerG1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleG."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$label."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartG2 = new CanvasJS.Chart("chartContainerG2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleG."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$label."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsG3, JSON_NUMERIC_CHECK); ?>
        }]
    });
    //Pie
    var chartG1p = new CanvasJS.Chart("chartContainerG1p", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$TitleG2."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsG1p, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartG2p = new CanvasJS.Chart("chartContainerG2p", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$TitleG2."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "white",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsG1p, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//doughnut
	var chartG1d = new CanvasJS.Chart("chartContainerG1d", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$TitleG3."'"; ?>
	  },
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsG1d, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartG2d = new CanvasJS.Chart("chartContainerG2d", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$TitleG3."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "white",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsG1d, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//net
	var chartN1 = new CanvasJS.Chart("chartContainerN1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleN."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartN2 = new CanvasJS.Chart("chartContainerN2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleN."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsN3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//drop
	var chartD1 = new CanvasJS.Chart("chartContainerD1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleD."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartD2 = new CanvasJS.Chart("chartContainerD2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleD."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsD3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//surv
	var chartS1 = new CanvasJS.Chart("chartContainerS1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleS."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartS2 = new CanvasJS.Chart("chartContainerS2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleS."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsS3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//fail
	var chartF1 = new CanvasJS.Chart("chartContainerF1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleF."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartF2 = new CanvasJS.Chart("chartContainerF2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleF."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsF3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//com
	var chartC1 = new CanvasJS.Chart("chartContainerC1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleC."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartC2 = new CanvasJS.Chart("chartContainerC2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleC."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsC3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//ret
	var chartRT1 = new CanvasJS.Chart("chartContainerRT1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleRT."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartRT2 = new CanvasJS.Chart("chartContainerRT2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleRT."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRT3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//grad
	var chartGD1 = new CanvasJS.Chart("chartContainerGD1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleGD."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartGD2 = new CanvasJS.Chart("chartContainerGD2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleGD."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsGD3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//pro
	var chartPR1 = new CanvasJS.Chart("chartContainerPR1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitlePR."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartPR2 = new CanvasJS.Chart("chartContainerPR2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitlePR."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsPR3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//rep
	var chartRP1 = new CanvasJS.Chart("chartContainerRP1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$TitleRP."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chartRP2 = new CanvasJS.Chart("chartContainerRP2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$TitleRP."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$labelx."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPointsRP3, JSON_NUMERIC_CHECK); ?>
        }]
    });
//EO3
	var chartEO3A = new CanvasJS.Chart("chartContainerEO3A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO3."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO3A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3As = new CanvasJS.Chart("chartContainerEO3As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO3."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3Aa = new CanvasJS.Chart("chartContainerEO3Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO3a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3Ab = new CanvasJS.Chart("chartContainerEO3Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleEO3b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartEO3B = new CanvasJS.Chart("chartContainerEO3A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO32."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO3A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3Bs = new CanvasJS.Chart("chartContainerEO3A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO32."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3Ba = new CanvasJS.Chart("chartContainerEO3A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO32a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO3Bb = new CanvasJS.Chart("chartContainerEO3A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO3Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//EO4
	var chartEO4A = new CanvasJS.Chart("chartContainerEO4A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO4."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO4A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4As = new CanvasJS.Chart("chartContainerEO4As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO4."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4Aa = new CanvasJS.Chart("chartContainerEO4Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO4a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4Ab = new CanvasJS.Chart("chartContainerEO4Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleEO4b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartEO4B = new CanvasJS.Chart("chartContainerEO4A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO42."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO4A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4Bs = new CanvasJS.Chart("chartContainerEO4A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO42."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4Ba = new CanvasJS.Chart("chartContainerEO4A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO42a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO4Bb = new CanvasJS.Chart("chartContainerEO4A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO4Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//EO5
	var chartEO5A = new CanvasJS.Chart("chartContainerEO5A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO5."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO5A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5As = new CanvasJS.Chart("chartContainerEO5As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO5."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5Aa = new CanvasJS.Chart("chartContainerEO5Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO5a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5Ab = new CanvasJS.Chart("chartContainerEO5Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleEO5b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartEO5B = new CanvasJS.Chart("chartContainerEO5A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO52."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO5A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5Bs = new CanvasJS.Chart("chartContainerEO5A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO52."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5Ba = new CanvasJS.Chart("chartContainerEO5A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO52a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO5Bb = new CanvasJS.Chart("chartContainerEO5A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO5Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//EO6
	var chartEO6A = new CanvasJS.Chart("chartContainerEO6A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO6."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO6A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6As = new CanvasJS.Chart("chartContainerEO6As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO6."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6Aa = new CanvasJS.Chart("chartContainerEO6Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO6a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6Ab = new CanvasJS.Chart("chartContainerEO6Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleEO6b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartEO6B = new CanvasJS.Chart("chartContainerEO6A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleEO62."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsEO6A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6Bs = new CanvasJS.Chart("chartContainerEO6A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleEO62."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6Ba = new CanvasJS.Chart("chartContainerEO6A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleEO62a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartEO6Bb = new CanvasJS.Chart("chartContainerEO6A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsEO6Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//ES3
	//pre
		//speed lvl
		var chartES3A = new CanvasJS.Chart("chartContainerES3A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3As = new CanvasJS.Chart("chartContainerES3As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Aa = new CanvasJS.Chart("chartContainerES3Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Ab = new CanvasJS.Chart("chartContainerES3Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES3B = new CanvasJS.Chart("chartContainerES3B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Bs = new CanvasJS.Chart("chartContainerES3Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Ba = new CanvasJS.Chart("chartContainerES3Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Bb = new CanvasJS.Chart("chartContainerES3Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES3C = new CanvasJS.Chart("chartContainerES3C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Cs = new CanvasJS.Chart("chartContainerES3Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Ca = new CanvasJS.Chart("chartContainerES3Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3Cb = new CanvasJS.Chart("chartContainerES3Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartES3A2 = new CanvasJS.Chart("chartContainerES3A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3A2s = new CanvasJS.Chart("chartContainerES3A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3A2a = new CanvasJS.Chart("chartContainerES3A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3A2b = new CanvasJS.Chart("chartContainerES3A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES3B2 = new CanvasJS.Chart("chartContainerES3B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3B2s = new CanvasJS.Chart("chartContainerES3B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3B2a = new CanvasJS.Chart("chartContainerES3B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3B2b = new CanvasJS.Chart("chartContainerES4B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES3C2 = new CanvasJS.Chart("chartContainerES3C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3C2s = new CanvasJS.Chart("chartContainerES3C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3C2a = new CanvasJS.Chart("chartContainerES3C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES3C2b = new CanvasJS.Chart("chartContainerES3C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//ES4
	//pre
		//speed lvl
		var chartES4A = new CanvasJS.Chart("chartContainerES4A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4As = new CanvasJS.Chart("chartContainerES4As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Aa = new CanvasJS.Chart("chartContainerES4Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Ab = new CanvasJS.Chart("chartContainerES4Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES4B = new CanvasJS.Chart("chartContainerES4B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Bs = new CanvasJS.Chart("chartContainerES4Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Ba = new CanvasJS.Chart("chartContainerES4Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Bb = new CanvasJS.Chart("chartContainerES4Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES4C = new CanvasJS.Chart("chartContainerES4C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Cs = new CanvasJS.Chart("chartContainerES4Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Ca = new CanvasJS.Chart("chartContainerES4Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4Cb = new CanvasJS.Chart("chartContainerES4Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartES4A2 = new CanvasJS.Chart("chartContainerES4A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4A2s = new CanvasJS.Chart("chartContainerES4A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4A2a = new CanvasJS.Chart("chartContainerES4A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4A2b = new CanvasJS.Chart("chartContainerES4A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES4B2 = new CanvasJS.Chart("chartContainerES4B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4B2s = new CanvasJS.Chart("chartContainerES4B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4B2a = new CanvasJS.Chart("chartContainerES4B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4B2b = new CanvasJS.Chart("chartContainerES4B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES4C2 = new CanvasJS.Chart("chartContainerES4C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4C2s = new CanvasJS.Chart("chartContainerES4C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4C2a = new CanvasJS.Chart("chartContainerES4C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES4C2b = new CanvasJS.Chart("chartContainerES4C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES4Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//ES5
	//pre
		//speed lvl
		var chartES5A = new CanvasJS.Chart("chartContainerES5A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5As = new CanvasJS.Chart("chartContainerES5As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Aa = new CanvasJS.Chart("chartContainerES5Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Ab = new CanvasJS.Chart("chartContainerES5Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES5B = new CanvasJS.Chart("chartContainerES5B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Bs = new CanvasJS.Chart("chartContainerES5Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Ba = new CanvasJS.Chart("chartContainerES5Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Bb = new CanvasJS.Chart("chartContainerES5Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES5C = new CanvasJS.Chart("chartContainerES5C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Cs = new CanvasJS.Chart("chartContainerES5Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Ca = new CanvasJS.Chart("chartContainerES5Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5Cb = new CanvasJS.Chart("chartContainerES5Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartES5A2 = new CanvasJS.Chart("chartContainerES5A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5A2s = new CanvasJS.Chart("chartContainerES5A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5A2a = new CanvasJS.Chart("chartContainerES5A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5A2b = new CanvasJS.Chart("chartContainerES5A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES5B2 = new CanvasJS.Chart("chartContainerES5B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5B2s = new CanvasJS.Chart("chartContainerES5B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5B2a = new CanvasJS.Chart("chartContainerES5B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5B2b = new CanvasJS.Chart("chartContainerES5B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES5C2 = new CanvasJS.Chart("chartContainerES5C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5C2s = new CanvasJS.Chart("chartContainerES5C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5C2a = new CanvasJS.Chart("chartContainerES5C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES5C2b = new CanvasJS.Chart("chartContainerES5C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES5Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//ES6
	//pre
		//speed lvl
		var chartES6A = new CanvasJS.Chart("chartContainerES6A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6As = new CanvasJS.Chart("chartContainerES6As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Aa = new CanvasJS.Chart("chartContainerES6Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Ab = new CanvasJS.Chart("chartContainerES6Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES6B = new CanvasJS.Chart("chartContainerES6B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Bs = new CanvasJS.Chart("chartContainerES6Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Ba = new CanvasJS.Chart("chartContainerES6Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Bb = new CanvasJS.Chart("chartContainerES6Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES6C = new CanvasJS.Chart("chartContainerES6C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Cs = new CanvasJS.Chart("chartContainerES6Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Ca = new CanvasJS.Chart("chartContainerES6Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6Cb = new CanvasJS.Chart("chartContainerES6Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartES6A2 = new CanvasJS.Chart("chartContainerES6A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6A2s = new CanvasJS.Chart("chartContainerES6A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6A2a = new CanvasJS.Chart("chartContainerES6A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6A2b = new CanvasJS.Chart("chartContainerES6A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartES6B2 = new CanvasJS.Chart("chartContainerES6B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6B2s = new CanvasJS.Chart("chartContainerES6B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6B2a = new CanvasJS.Chart("chartContainerES6B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6B2b = new CanvasJS.Chart("chartContainerES6B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartES6C2 = new CanvasJS.Chart("chartContainerES6C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsES6C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6C2s = new CanvasJS.Chart("chartContainerES6C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6C2a = new CanvasJS.Chart("chartContainerES6C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartES6C2b = new CanvasJS.Chart("chartContainerES6C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES6Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//FO3
	var chartFO3A = new CanvasJS.Chart("chartContainerFO3A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO3."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO3A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3As = new CanvasJS.Chart("chartContainerFO3As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO3."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3Aa = new CanvasJS.Chart("chartContainerFO3Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO3a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3Ab = new CanvasJS.Chart("chartContainerFO3Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleFO3b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartFO3B = new CanvasJS.Chart("chartContainerFO3A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO32."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO3A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3Bs = new CanvasJS.Chart("chartContainerFO3A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO32."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3Ba = new CanvasJS.Chart("chartContainerFO3A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO32a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO3Bb = new CanvasJS.Chart("chartContainerFO3A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO3Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//FO4
	var chartFO4A = new CanvasJS.Chart("chartContainerFO4A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO4."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO4A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4As = new CanvasJS.Chart("chartContainerFO4As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO4."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4Aa = new CanvasJS.Chart("chartContainerFO4Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO4a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4Ab = new CanvasJS.Chart("chartContainerFO4Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleFO4b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartFO4B = new CanvasJS.Chart("chartContainerFO4A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO42."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO4A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4Bs = new CanvasJS.Chart("chartContainerFO4A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO42."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4Ba = new CanvasJS.Chart("chartContainerFO4A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO42a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO4Bb = new CanvasJS.Chart("chartContainerFO4A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO4Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//FO5
	var chartFO5A = new CanvasJS.Chart("chartContainerFO5A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO5."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO5A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5As = new CanvasJS.Chart("chartContainerFO5As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO5."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5Aa = new CanvasJS.Chart("chartContainerFO5Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO5a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5Ab = new CanvasJS.Chart("chartContainerFO5Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleFO5b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartFO5B = new CanvasJS.Chart("chartContainerFO5A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO52."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO5A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5Bs = new CanvasJS.Chart("chartContainerFO5A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO52."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5Ba = new CanvasJS.Chart("chartContainerFO5A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO52a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO5Bb = new CanvasJS.Chart("chartContainerFO5A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO5Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//FO4
	var chartFO6A = new CanvasJS.Chart("chartContainerFO6A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO6."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO6A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6As = new CanvasJS.Chart("chartContainerFO6As", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO6."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6A, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6Aa = new CanvasJS.Chart("chartContainerFO6Aa", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO6a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6Aa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6Ab = new CanvasJS.Chart("chartContainerFO6Ab", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleFO6b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6Ab, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartFO6B = new CanvasJS.Chart("chartContainerFO6A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleFO62."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsFO6A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6Bs = new CanvasJS.Chart("chartContainerFO6A2s", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleFO62."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6A2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6Ba = new CanvasJS.Chart("chartContainerFO6A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleFO62a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6Aa2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartFO6Bb = new CanvasJS.Chart("chartContainerFO6A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleEO32b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsFO6Ab2, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//FS3
	//pre
		//speed lvl
		var chartFS3A = new CanvasJS.Chart("chartContainerFS3A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3As = new CanvasJS.Chart("chartContainerFS3As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Aa = new CanvasJS.Chart("chartContainerFS3Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Ab = new CanvasJS.Chart("chartContainerFS3Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS3B = new CanvasJS.Chart("chartContainerFS3B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Bs = new CanvasJS.Chart("chartContainerFS3Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Ba = new CanvasJS.Chart("chartContainerFS3Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Bb = new CanvasJS.Chart("chartContainerFS3Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS3C = new CanvasJS.Chart("chartContainerFS3C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Cs = new CanvasJS.Chart("chartContainerFS3Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Ca = new CanvasJS.Chart("chartContainerFS3Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3Cb = new CanvasJS.Chart("chartContainerFS3Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartFS3A2 = new CanvasJS.Chart("chartContainerFS3A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3A2s = new CanvasJS.Chart("chartContainerFS3A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3A2a = new CanvasJS.Chart("chartContainerFS3A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3A2b = new CanvasJS.Chart("chartContainerFS3A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS3B2 = new CanvasJS.Chart("chartContainerFS3B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3B2s = new CanvasJS.Chart("chartContainerFS3B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3B2a = new CanvasJS.Chart("chartContainerFS3B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3B2b = new CanvasJS.Chart("chartContainerFS3B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS3C2 = new CanvasJS.Chart("chartContainerFS3C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3C2s = new CanvasJS.Chart("chartContainerFS3C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade3)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3C2a = new CanvasJS.Chart("chartContainerFS3C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS3C2b = new CanvasJS.Chart("chartContainerFS3C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade3)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS3Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//FS4
	//pre
		//speed lvl
		var chartFS4A = new CanvasJS.Chart("chartContainerFS4A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4As = new CanvasJS.Chart("chartContainerFS4As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Aa = new CanvasJS.Chart("chartContainerFS4Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Ab = new CanvasJS.Chart("chartContainerFS4Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS4B = new CanvasJS.Chart("chartContainerFS4B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Bs = new CanvasJS.Chart("chartContainerFS4Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Ba = new CanvasJS.Chart("chartContainerFS4Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Bb = new CanvasJS.Chart("chartContainerFS4Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS4C = new CanvasJS.Chart("chartContainerFS4C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Cs = new CanvasJS.Chart("chartContainerFS4Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Ca = new CanvasJS.Chart("chartContainerFS4Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4Cb = new CanvasJS.Chart("chartContainerFS4Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartFS4A2 = new CanvasJS.Chart("chartContainerFS4A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4A2s = new CanvasJS.Chart("chartContainerFS4A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4A2a = new CanvasJS.Chart("chartContainerFS4A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4A2b = new CanvasJS.Chart("chartContainerFS4A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS4B2 = new CanvasJS.Chart("chartContainerFS4B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4B2s = new CanvasJS.Chart("chartContainerFS4B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4B2a = new CanvasJS.Chart("chartContainerFS4B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4B2b = new CanvasJS.Chart("chartContainerFS4B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS4C2 = new CanvasJS.Chart("chartContainerFS4C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4C2s = new CanvasJS.Chart("chartContainerFS4C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade4)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4C2a = new CanvasJS.Chart("chartContainerFS4C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS4C2b = new CanvasJS.Chart("chartContainerFS4C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade4)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS4Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//FS5
	//pre
		//speed lvl
		var chartFS5A = new CanvasJS.Chart("chartContainerFS5A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5As = new CanvasJS.Chart("chartContainerFS5As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Aa = new CanvasJS.Chart("chartContainerFS5Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Ab = new CanvasJS.Chart("chartContainerFS5Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS5B = new CanvasJS.Chart("chartContainerFS5B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Bs = new CanvasJS.Chart("chartContainerFS5Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Ba = new CanvasJS.Chart("chartContainerFS5Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Bb = new CanvasJS.Chart("chartContainerFS5Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS5C = new CanvasJS.Chart("chartContainerFS5C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Cs = new CanvasJS.Chart("chartContainerFS5Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Ca = new CanvasJS.Chart("chartContainerFS5Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5Cb = new CanvasJS.Chart("chartContainerFS5Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartFS5A2 = new CanvasJS.Chart("chartContainerFS5A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5A2s = new CanvasJS.Chart("chartContainerFS5A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5A2a = new CanvasJS.Chart("chartContainerFS5A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5A2b = new CanvasJS.Chart("chartContainerFS5A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS5B2 = new CanvasJS.Chart("chartContainerFS5B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5B2s = new CanvasJS.Chart("chartContainerFS5B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5B2a = new CanvasJS.Chart("chartContainerFS5B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5B2b = new CanvasJS.Chart("chartContainerFS5B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS5C2 = new CanvasJS.Chart("chartContainerFS5C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5C2s = new CanvasJS.Chart("chartContainerFS5C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade5)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5C2a = new CanvasJS.Chart("chartContainerFS5C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS5C2b = new CanvasJS.Chart("chartContainerFS5C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade5)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS5Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//FS6
	//pre
		//speed lvl
		var chartFS6A = new CanvasJS.Chart("chartContainerFS6A", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6As = new CanvasJS.Chart("chartContainerFS6As", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6A, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Aa = new CanvasJS.Chart("chartContainerFS6Aa", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Aa, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Ab = new CanvasJS.Chart("chartContainerFS6Ab", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ab, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS6B = new CanvasJS.Chart("chartContainerFS6B", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Bs = new CanvasJS.Chart("chartContainerFS6Bs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6B, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Ba = new CanvasJS.Chart("chartContainerFS6Ba", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ba, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Bb = new CanvasJS.Chart("chartContainerFS6Bb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsES3Bb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS6C = new CanvasJS.Chart("chartContainerFS6C", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Pre Reading Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Cs = new CanvasJS.Chart("chartContainerFS6Cs", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6C, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Ca = new CanvasJS.Chart("chartContainerFS6Ca", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ca, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6Cb = new CanvasJS.Chart("chartContainerFS6Cb", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Pre Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Cb, JSON_NUMERIC_CHECK); ?>
		  }]
		});
	//post
		//speed lvl
		var chartFS6A2 = new CanvasJS.Chart("chartContainerFS6A2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6A2s = new CanvasJS.Chart("chartContainerFS6A2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Speed Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6A2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6A2a = new CanvasJS.Chart("chartContainerFS6A2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Aa2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6A2b = new CanvasJS.Chart("chartContainerFS6A2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Speed Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ab2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Comprehension lvl
		var chartFS6B2 = new CanvasJS.Chart("chartContainerFS6B2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 285,
		  width: 320,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6B2s = new CanvasJS.Chart("chartContainerFS6B2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6B2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6B2a = new CanvasJS.Chart("chartContainerFS6B2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ba2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6B2b = new CanvasJS.Chart("chartContainerFS6B2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Bb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
		//Read lvl
		var chartFS6C2 = new CanvasJS.Chart("chartContainerFS6C2", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors2",
		  title: {
		    text: "Post Reading Level Rate (Grade3)"
		  },
		  height: 215,
		  width: 290,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{none}",
		    dataPoints: <?php echo json_encode($dataPointsFS6C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6C2s = new CanvasJS.Chart("chartContainerFS6C2s", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors",
		  title: {
		    text: "Post Comprehension Level Rate (Grade6)"
		  },
		  height: 578,
		  width: 820,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6C2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6C2a = new CanvasJS.Chart("chartContainerFS6C2a", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors4",
		  title: {
		    text: "Male Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Ca2, JSON_NUMERIC_CHECK); ?>
		  }]
		});

		var chartFS6C2b = new CanvasJS.Chart("chartContainerFS6C2b", {
		  theme: "light2",
		  exportEnabled: true,
		  animationEnabled: true,
		  colorSet: "dataColors3",
		  title: {
		    text: "Female Post Comprehension Level Rate (Grade6)"
		  },
		  height: 283,
		  width: 369,
		  data: [{
		    type: "pie",
		    indexLabel: "{y}",
		    yValueFormatString: "#,##0.00\"%\"",
		    indexLabelPlacement: "inside",
		    indexLabelFontColor: "white",
		    indexLabelFontSize: 10,
		    indexLabelFontWeight: "bolder",
		    showInLegend: true,
		    legendText: "{label}",
		    dataPoints: <?php echo json_encode($dataPointsFS6Cb2, JSON_NUMERIC_CHECK); ?>
		  }]
		});
//nutristatus
	//LeftPie
	var chartNutri1A = new CanvasJS.Chart("chartContaineNutri1A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleNS1."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri1A2 = new CanvasJS.Chart("chartContainerNutri1A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleNS1."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri1A2a = new CanvasJS.Chart("chartContainerNutri1A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleNS1a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriAa, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri1A2b = new CanvasJS.Chart("chartContainerNutri1A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	    text: <?php echo "'".$TitleNS1b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriAb, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//RightPie
	var chartNutri2A = new CanvasJS.Chart("chartContaineNutri2A", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors4",
	  title: {
	  	fontSize: 25,
	    text: <?php echo "'".$TitleNS2."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{none}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri2A2 = new CanvasJS.Chart("chartContainerNutri2A2", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors3",
	  title: {
	    text: <?php echo "'".$TitleNS2."'"; ?>
	  },
	  height: 578,
	  width: 820,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA2, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri2A2a = new CanvasJS.Chart("chartContainerNutri2A2a", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors2",
	  title: {
	    text: <?php echo "'".$TitleNS2a."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA2a, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chartNutri2A2b = new CanvasJS.Chart("chartContainerNutri2A2b", {
	  theme: "light2",
	  exportEnabled: true,
	  animationEnabled: true,
	  colorSet: "dataColors",
	  title: {
	    text: <?php echo "'".$TitleNS2b."'"; ?>
	  },
	  height: 283,
	  width: 369,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPointsNutriA2b, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//4Ps
	//bar
	var chart4P1 = new CanvasJS.Chart("chartContainer4P1", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light1",
      title:{
      	fontSize: 25,
      	fontFamily: "tahoma",
      	fontWeight: "lighter",
        text: <?php echo "'".$Title4P."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$label."'"; ?>
      },
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P3, JSON_NUMERIC_CHECK); ?>
        }]
    });

    var chart4P2 = new CanvasJS.Chart("chartContainer4P2", {
      exportEnabled: true,
      animationEnabled: true,
      theme: "light2",
      title:{
        text: <?php echo "'".$Title4P."'"; ?>
      },
      axisY: {
        title: <?php echo "'".$label."'"; ?>
      },
      height: 580,
	  width: 1310,
      data: [{
	        type: "column",
	        name: "Total",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P1, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Male",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P2, JSON_NUMERIC_CHECK); ?>
        },{
	        type: "column",
	        name: "Female",
	        yValueFormatString: "####",
	        showInLegend: true,
	        dataPoints: <?php echo json_encode($dataPoints4P3, JSON_NUMERIC_CHECK); ?>
        }]
    });
    //Pie
    var chart4P1p = new CanvasJS.Chart("chartContainer4P1p", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title4P2."'"; ?>
	  },
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints4P1p, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chart4P2p = new CanvasJS.Chart("chartContainer4P2p", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title4P2."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "pie",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "white",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints4P1p, JSON_NUMERIC_CHECK); ?>
	  }]
	});
	//doughnut
	var chart4P1d = new CanvasJS.Chart("chartContainer4P1d", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title4P3."'"; ?>
	  },
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "#36454F",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints4P1d, JSON_NUMERIC_CHECK); ?>
	  }]
	});

	var chart4P2d = new CanvasJS.Chart("chartContainer4P2d", {
	  theme: "light1",
	  exportEnabled: true,
	  animationEnabled: true,
	  title: {
	    text: <?php echo "'".$Title4P3."'"; ?>
	  },
	  height: 580,
	  width: 1310,
	  data: [{
	    type: "doughnut",
	    indexLabel: "{y}",
	    yValueFormatString: "#,##0.00\"%\"",
	    indexLabelPlacement: "inside",
	    indexLabelFontColor: "white",
	    indexLabelFontSize: 10,
	    indexLabelFontWeight: "bolder",
	    showInLegend: true,
	    legendText: "{label}",
	    dataPoints: <?php echo json_encode($dataPoints4P1d, JSON_NUMERIC_CHECK); ?>
	  }]
	});
//render
    chartG1.render();
    chartG1p.render();
    chartG1d.render();
    chartG2.render();
    chartG2p.render();
    chartG2d.render();
    chartN1.render();
    chartN2.render();
    chartD1.render();
    chartD2.render();
    chartS1.render();
    chartS2.render();
    chartF1.render();
    chartF2.render();
    chartC1.render();
    chartC2.render();
    chartRT1.render();
    chartRT2.render();
    chartGD1.render();
    chartGD2.render();
    chartPR1.render();
    chartPR2.render();
    chartRP1.render();
    chartRP2.render();

    chartEO3A.render();
    chartEO3As.render();
    chartEO3Aa.render();
    chartEO3Ab.render();
    chartEO3B.render();
    chartEO3Bs.render();
    chartEO3Ba.render();
    chartEO3Bb.render();
    chartEO4A.render();
    chartEO4As.render();
    chartEO4Aa.render();
    chartEO4Ab.render();
    chartEO4B.render();
    chartEO4Bs.render();
    chartEO4Ba.render();
    chartEO4Bb.render();
    chartEO5A.render();
    chartEO5As.render();
    chartEO5Aa.render();
    chartEO5Ab.render();
    chartEO5B.render();
    chartEO5Bs.render();
    chartEO5Ba.render();
    chartEO5Bb.render();
    chartEO6A.render();
    chartEO6As.render();
    chartEO6Aa.render();
    chartEO6Ab.render();
    chartEO6B.render();
    chartEO6Bs.render();
    chartEO6Ba.render();
    chartEO6Bb.render();

    chartES3A.render();
    chartES3As.render();
    chartES3Aa.render();
    chartES3Ab.render();
    chartES3B.render();
    chartES3Bs.render();
    chartES3Ba.render();
    chartES3Bb.render();
    chartES3C.render();
    chartES3Cs.render();
    chartES3Ca.render();
    chartES3Cb.render();
    chartES4A.render();
    chartES4As.render();
    chartES4Aa.render();
    chartES4Ab.render();
    chartES4B.render();
    chartES4Bs.render();
    chartES4Ba.render();
    chartES4Bb.render();
    chartES4C.render();
    chartES4Cs.render();
    chartES4Ca.render();
    chartES4Cb.render();
    chartES5A.render();
    chartES5As.render();
    chartES5Aa.render();
    chartES5Ab.render();
    chartES5B.render();
    chartES5Bs.render();
    chartES5Ba.render();
    chartES5Bb.render();
    chartES5C.render();
    chartES5Cs.render();
    chartES5Ca.render();
    chartES5Cb.render();
    chartES6A.render();
    chartES6As.render();
    chartES6Aa.render();
    chartES6Ab.render();
    chartES6B.render();
    chartES6Bs.render();
    chartES6Ba.render();
    chartES6Bb.render();
    chartES6C.render();
    chartES6Cs.render();
    chartES6Ca.render();
    chartES6Cb.render();

    chartES3A2.render();
    chartES3A2s.render();
    chartES3A2a.render();
    chartES3A2b.render();
    chartES3B2.render();
    chartES3B2s.render();
    chartES3B2a.render();
    chartES3B2b.render();
    chartES3C2.render();
    chartES3C2s.render();
    chartES3C2a.render();
    chartES3C2b.render();
    chartES4A2.render();
    chartES4A2s.render();
    chartES4A2a.render();
    chartES4A2b.render();
    chartES4B2.render();
    chartES4B2s.render();
    chartES4B2a.render();
    chartES4B2b.render();
    chartES4C2.render();
    chartES4C2s.render();
    chartES4C2a.render();
    chartES4C2b.render();
    chartES5A2.render();
    chartES5A2s.render();
    chartES5A2a.render();
    chartES5A2b.render();
    chartES5B2.render();
    chartES5B2s.render();
    chartES5B2a.render();
    chartES5B2b.render();
    chartES5C2.render();
    chartES5C2s.render();
    chartES5C2a.render();
    chartES5C2b.render();
    chartES6A2.render();
    chartES6A2s.render();
    chartES6A2a.render();
    chartES6A2b.render();
    chartES6B2.render();
    chartES6B2s.render();
    chartES6B2a.render();
    chartES6B2b.render();
    chartES6C2.render();
    chartES6C2s.render();
    chartES6C2a.render();
    chartES6C2b.render();

    chartFO3A.render();
    chartFO3As.render();
    chartFO3Aa.render();
    chartFO3Ab.render();
    chartFO3B.render();
    chartFO3Bs.render();
    chartFO3Ba.render();
    chartFO3Bb.render();
    chartFO4A.render();
    chartFO4As.render();
    chartFO4Aa.render();
    chartFO4Ab.render();
    chartFO4B.render();
    chartFO4Bs.render();
    chartFO4Ba.render();
    chartFO4Bb.render();
    chartFO5A.render();
    chartFO5As.render();
    chartFO5Aa.render();
    chartFO5Ab.render();
    chartFO5B.render();
    chartFO5Bs.render();
    chartFO5Ba.render();
    chartFO5Bb.render();
    chartFO6A.render();
    chartFO6As.render();
    chartFO6Aa.render();
    chartFO6Ab.render();
    chartFO6B.render();
    chartFO6Bs.render();
    chartFO6Ba.render();
    chartFO6Bb.render();

    chartFS3A.render();
    chartFS3As.render();
    chartFS3Aa.render();
    chartFS3Ab.render();
    chartFS3B.render();
    chartFS3Bs.render();
    chartFS3Ba.render();
    chartFS3Bb.render();
    chartFS3C.render();
    chartFS3Cs.render();
    chartFS3Ca.render();
    chartFS3Cb.render();
    chartFS4A.render();
    chartFS4As.render();
    chartFS4Aa.render();
    chartFS4Ab.render();
    chartFS4B.render();
    chartFS4Bs.render();
    chartFS4Ba.render();
    chartFS4Bb.render();
    chartFS4C.render();
    chartFS4Cs.render();
    chartFS4Ca.render();
    chartFS4Cb.render();
    chartFS5A.render();
    chartFS5As.render();
    chartFS5Aa.render();
    chartFS5Ab.render();
    chartFS5B.render();
    chartFS5Bs.render();
    chartFS5Ba.render();
    chartFS5Bb.render();
    chartFS5C.render();
    chartFS5Cs.render();
    chartFS5Ca.render();
    chartFS5Cb.render();
    chartFS6A.render();
    chartFS6As.render();
    chartFS6Aa.render();
    chartFS6Ab.render();
    chartFS6B.render();
    chartFS6Bs.render();
    chartFS6Ba.render();
    chartFS6Bb.render();
    chartFS6C.render();
    chartFS6Cs.render();
    chartFS6Ca.render();
    chartFS6Cb.render();

    chartFS3A2.render();
    chartFS3A2s.render();
    chartFS3A2a.render();
    chartFS3A2b.render();
    chartFS3B2.render();
    chartFS3B2s.render();
    chartFS3B2a.render();
    chartFS3B2b.render();
    chartFS3C2.render();
    chartFS3C2s.render();
    chartFS3C2a.render();
    chartFS3C2b.render();
    chartFS4A2.render();
    chartFS4A2s.render();
    chartFS4A2a.render();
    chartFS4A2b.render();
    chartFS4B2.render();
    chartFS4B2s.render();
    chartFS4B2a.render();
    chartFS4B2b.render();
    chartFS4C2.render();
    chartFS4C2s.render();
    chartFS4C2a.render();
    chartFS4C2b.render();
    chartFS5A2.render();
    chartFS5A2s.render();
    chartFS5A2a.render();
    chartFS5A2b.render();
    chartFS5B2.render();
    chartFS5B2s.render();
    chartFS5B2a.render();
    chartFS5B2b.render();
    chartFS5C2.render();
    chartFS5C2s.render();
    chartFS5C2a.render();
    chartFS5C2b.render();
    chartFS6A2.render();
    chartFS6A2s.render();
    chartFS6A2a.render();
    chartFS6A2b.render();
    chartFS6B2.render();
    chartFS6B2s.render();
    chartFS6B2a.render();
    chartFS6B2b.render();
    chartFS6C2.render();
    chartFS6C2s.render();
    chartFS6C2a.render();
    chartFS6C2b.render();

    chartNutri1A.render();
    chartNutri1A2.render();
    chartNutri1A2a.render();
    chartNutri1A2b.render();
    chartNutri2A.render();
    chartNutri2A2.render();
    chartNutri2A2a.render();
    chartNutri2A2b.render();

    chart4P1.render();
    chart4P1p.render();
    chart4P1d.render();
    chart4P2.render();
    chart4P2p.render();
    chart4P2d.render();

}
</script>

<div class="contents" style="overflow: hidden;">
	
	<div class="GroupButCont" style="height: 100%; width: 7%; top: 16%;">
		<div class="butHolder">
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page1") {echo "active";}?>" onclick="changeE(event, 'Grade3')" style="height: 24%;">
				<i class="fas fa-tachometer-alt"></i>
				<ul class="tooltiptextx" style="top: -50%;">Performance Indicators</ul>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page2") {echo "active";}?>" onclick="changeE(event, 'Grade4')" style="height: 24%;">
				<i class="fas fa-clipboard"></i>
				<span class="tooltiptextx">Phil-Iri</span>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page3") {echo "active";}?>" onclick="changeE(event, 'Grade5')" style="height: 24%;">
				<i class="fas fa-balance-scale"></i>
				<span class="tooltiptextx">Nutritional Status</span>
			</button>
			<button id="HighButton" class="tablinks <?php if ($_SESSION['display'] == "Page4") {echo "active";}?>" onclick="changeE(event, 'Grade6')" style="height: 24%;">
				<i class="far fa-address-card"></i>
				<span class="tooltiptextx">4P's</span>
			</button>
		</div>
	</div>

	<div id="Grade3" class="leftTabE" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?> >
		<div class="graphCont2">
			<form class="leftPart" action="PHP/selDate.php" method="POST">
				<div class="topLeftPart">
					<select class="selDateE" name="time1">
						<?php
						if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page1") {
							echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
							if ($grossmin != "none") {
								for ($i=$grossmin; $i <= $grossmax; $i++) { 
									echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
								}
							}
							else{
								echo "<option value=\"".$i."\"> SY: No Entry</option>";
							}
						}
						else{
							echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
							for ($i=$grossmin; $i <= $grossmax; $i++) { 
								echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
							}
						}
						?>
					</select>
					<button class="timeBtnE" type="submit" name="ESPI">Go</button>
				</div>
				<div class="botLeftPart">
					<button type="button" class="tablinks2" onclick="change2(event, 'GE')"><i class="fas fa-folder"></i> Gross Enrollment </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'NE')"><i class="fas fa-folder"></i> Net Enrollment Rate</button>
					<button type="button" class="tablinks2" onclick="change2(event, 'DR')"><i class="fas fa-folder"></i> Drop-out Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'SR')"><i class="fas fa-folder"></i> Survival Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'FR')"><i class="fas fa-folder"></i> Failure Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'CR')"><i class="fas fa-folder"></i> Completion Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'RT')"><i class="fas fa-folder"></i> Retention Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'GD')"><i class="fas fa-folder"></i> Graduation Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'PR')"><i class="fas fa-folder"></i> Promotion Rate </button>
					<button type="button" class="tablinks2" onclick="change2(event, 'RP')"><i class="fas fa-folder"></i> Repeatition Rate </button>
				</div>
			</form>
			
			<div id="GE" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="GG" class="contab">
					<div class="leftGraphPart">
						<div id="grossPieGrap" class="topPie">
							<div id="chartContainerG1p" style="height: 100%; max-width: 100%;"></div>
						</div>
						<div id="grossDouGrap" class="downPie">
							<div id="chartContainerG1d" style="height: 100%; max-width: 100%;"></div>
						</div>
					</div>
					<div class="rightGraphPart">
						<div id="grossBarGrap" class="centerBar">
							<div id="chartContainerG1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Gross Enrollment</h1>
					</center>
					<button type="button" id="exportButEG" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EGtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="NE" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'NG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'NT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="NG" class="contab">
					<div class="CenterGraphPart">
						<div id="NetBarGrap" class="centerBar2">
							<div id="chartContainerN1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="NT" class="contab">
					<center>
						<h1> <?php echo $School;?> Net Enrollment Rate</h1>
					</center>
					<button type="button" id="exportButEN" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/ENtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="DR" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'DG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'DT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="DG" class="contab">
					<div class="CenterGraphPart">
						<div id="DropBarGrap" class="centerBar2">
							<div id="chartContainerD1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="DT" class="contab">
					<center>
						<h1> <?php echo $School;?> Drop Rate</h1>
					</center>
					<button type="button" id="exportButED" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EDtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="SR" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'SG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'ST')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="SG" class="contab">
					<div class="CenterGraphPart">
						<div id="SurvBarGrap" class="centerBar2">
							<div id="chartContainerS1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="ST" class="contab">
					<center>
						<h1> <?php echo $School;?> Survival Rate</h1>
					</center>
					<button type="button" id="exportButES" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EStable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="FR" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FG" class="contab">
					<div class="CenterGraphPart">
						<div id="FailBarGrap" class="centerBar2">
							<div id="chartContainerF1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="FT" class="contab">
					<center>
						<h1> <?php echo $School;?> Failure Rate</h1>
					</center>
					<button type="button" id="exportButEF" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EFtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="CR" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'CG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'CT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="CG" class="contab">
					<div class="CenterGraphPart">
						<div id="ComBarGrap" class="centerBar2">
							<div id="chartContainerC1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="CT" class="contab">
					<center>
						<h1> <?php echo $School;?> Completion Rate</h1>
					</center>
					<button type="button" id="exportButEC" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/ECtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="RT" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'RTG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'RTT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="RTG" class="contab">
					<div class="CenterGraphPart">
						<div id="RetBarGrap" class="centerBar2">
							<div id="chartContainerRT1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="RTT" class="contab">
					<center>
						<h1> <?php echo $School;?> Retention Rate</h1>
					</center>
					<button type="button" id="exportButERT" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/ERTtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="GD" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'GDG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'GDT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="GDG" class="contab">
					<div class="CenterGraphPart">
						<div id="GradBarGrap" class="centerBar2">
							<div id="chartContainerGD1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="GDT" class="contab">
					<center>
						<h1> <?php echo $School;?> Graduation Rate</h1>
					</center>
					<button type="button" id="exportButEGD" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EGDtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="PR" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'PRG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'PRT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="PRG" class="contab">
					<div class="CenterGraphPart">
						<div id="ProNetBarGrap" class="centerBar2">
							<div id="chartContainerPR1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="PRT" class="contab">
					<center>
						<h1> <?php echo $School;?> Promotion Rate</h1>
					</center>
					<button type="button" id="exportButEPR" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/EPRtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="RP" class="rightSide">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'RPG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'RPT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="RPG" class="contab">
					<div class="CenterGraphPart">
						<div id="RepBarGrap" class="centerBar2">
							<div id="chartContainerRP1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="RPT" class="contab">
					<center>
						<h1> <?php echo $School;?> Repeatition Rate</h1>
					</center>
					<button type="button" id="exportButERP" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/ERPtable1.php";
		   				?> 
		   			</div>
				</div>
			</div>

		</div>
	</div>

	<div id="Grade4" class="leftTabE" <?php if ($_SESSION['display'] == "Page2") {echo "style=\"display:block;\" ";}?> >
		<div class="graphCont2">
			<form class="leftPart" action="PHP/selDate.php" method="POST">		
				<div class="topLeftPart">
					<select class="selDateE" name="time1">
						<?php
						if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page2") {
							echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
							if ($PIMin != "none") {
								for ($i=$PIMin; $i <= $PIMax; $i++) { 
									echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
								}
							}
							else{
								echo "<option value=\"".$i."\"> SY: No Entry</option>";
							}
						}
						else{
							echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime2."-".($chosenTime2+1)."</option>";
							for ($i=$PIMin; $i <= $PIMax; $i++) { 
								echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
							}
						}
						?>
					</select>
					<button class="timeBtnE" type="submit" name="ESPHilIRi">Go</button>
				</div>

				<div class="botLeftPart">	
					<div class="PIButCon">
						<button id="flip1" class="PIShowBut" type="button" style="display:inline;"><i class="fas fa-plus"></i></button>
						<button id="flop1" class="PIShowBut" type="button" style="display: none;"><i class="fas fa-minus"></i></button>
						<h3 style="display:inline;">-English Oral</h3>
					</div>
					<div class="PIButPanel1">
						<button type="button" class="tablinks2" onclick="change2(event, 'EO3')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 3 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'EO4')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 4 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'EO5')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 5 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'EO6')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 6 </button>
					</div>

					<div class="PIButCon">
						<button id="flip2" class="PIShowBut" type="button" style="display:inline;"><i class="fas fa-plus"></i></button>
						<button id="flop2" class="PIShowBut" type="button" style="display: none;"><i class="fas fa-minus"></i></button>
						<h3 style="display:inline;">-English Silent</h3>
					</div>
					<div class="PIButPanel2">
						<button type="button" class="tablinks2" onclick="change2(event, 'ES3')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 3 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'ES4')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 4 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'ES5')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 5 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'ES6')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 6 </button>
					</div>

					<div class="PIButCon">
						<button id="flip3" class="PIShowBut" type="button" style="display:inline;"><i class="fas fa-plus"></i></button>
						<button id="flop3" class="PIShowBut" type="button" style="display: none;"><i class="fas fa-minus"></i></button>
						<h3 style="display:inline;">-Filipino Oral</h3>
					</div>
					<div class="PIButPanel3">
						<button type="button" class="tablinks2" onclick="change2(event, 'FO3')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 3 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FO4')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 4 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FO5')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 5 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FO6')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 6 </button>
					</div>

					<div class="PIButCon">
						<button id="flip4" class="PIShowBut" type="button" style="display:inline;"><i class="fas fa-plus"></i></button>
						<button id="flop4" class="PIShowBut" type="button" style="display: none;"><i class="fas fa-minus"></i></button>
						<h3 style="display:inline;">-Filipino Silent</h3>
					</div>
					<div class="PIButPanel4">
						<button type="button" class="tablinks2" onclick="change2(event, 'FS3')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 3 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FS4')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 4 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FS5')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 5 </button>
						<button type="button" class="tablinks2" onclick="change2(event, 'FS6')" style="width: 60%; margin-left: 5%;"><i class="fas fa-folder"></i> Grade 6 </button>
					</div>
				</div>
			</form>
			
			<div id="EO3" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'EO3GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'EO3GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="EO3GG" class="contab">
					<div class="leftGraphPart2">
						<div id="EO3" class="centerGrap3">
							<div id="chartContainerEO3A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="EO32" class="centerGrap3">
							<div id="chartContainerEO3A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="EO3GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Oral Grade 3</h1>
					</center>
					<button type="button" id="exportButEEO3" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/EO3table1.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="EO4" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'EO4GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'EO4GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="EO4GG" class="contab">
					<div class="leftGraphPart2">
						<div id="EO4" class="centerGrap3">
							<div id="chartContainerEO4A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="EO42" class="centerGrap3">
							<div id="chartContainerEO4A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="EO4GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Oral Grade 4</h1>
					</center>
					<button type="button" id="exportButEEO4" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/EO3table2.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="EO5" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'EO5GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'EO5GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="EO5GG" class="contab">
					<div class="leftGraphPart2">
						<div id="EO5" class="centerGrap3">
							<div id="chartContainerEO5A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="EO52" class="centerGrap3">
							<div id="chartContainerEO5A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="EO5GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Oral Grade 5</h1>
					</center>
					<button type="button" id="exportButEEO5" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/EO3table3.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="EO6" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'EO6GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'EO6GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="EO6GG" class="contab">
					<div class="leftGraphPart2">
						<div id="EO6" class="centerGrap3">
							<div id="chartContainerEO6A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="EO62" class="centerGrap3">
							<div id="chartContainerEO6A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="EO6GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Oral Grade 6</h1>
					</center>
					<button type="button" id="exportButEEO6" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/EO3table4.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="ES3" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'ES3GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'ES3GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="ES3GG" class="contab" style="background-color: #009933;">
					<div id="ES3A" class="ltg">
						<div id="chartContainerES3A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES3B" class="lcg">
						<div id="chartContainerES3B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES3C" class="lbg">
						<div id="chartContainerES3C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES3A2" class="rtg">
						<div id="chartContainerES3A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES3B2" class="rcg">
						<div id="chartContainerES3B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES3C2" class="rbg">
						<div id="chartContainerES3C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="ES3GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Silent Grade 3</h1>
					</center>
					<button type="button" id="exportButEES3" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/ES3table1.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="ES4" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'ES4GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'ES4GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="ES4GG" class="contab" style="background-color: #009933;">
					<div id="ES4A" class="ltg">
						<div id="chartContainerES4A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES4B" class="lcg">
						<div id="chartContainerES4B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES4C" class="lbg">
						<div id="chartContainerES4C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES4A2" class="rtg">
						<div id="chartContainerES4A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES4B2" class="rcg">
						<div id="chartContainerES4B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES4C2" class="rbg">
						<div id="chartContainerES4C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="ES4GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Silent Grade 4</h1>
					</center>
					<button type="button" id="exportButEES4" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/ES3table2.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="ES5" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'ES5GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'ES5GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="ES5GG" class="contab" style="background-color: #009933;">
					<div id="ES5A" class="ltg">
						<div id="chartContainerES5A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES5B" class="lcg">
						<div id="chartContainerES5B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES5C" class="lbg">
						<div id="chartContainerES5C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES5A2" class="rtg">
						<div id="chartContainerES5A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES5B2" class="rcg">
						<div id="chartContainerES5B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES5C2" class="rbg">
						<div id="chartContainerES5C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="E53GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Silent Grade 5</h1>
					</center>
					<button type="button" id="exportButEES5" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/ES3table3.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="ES6" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'ES6GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'ES6GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="ES6GG" class="contab" style="background-color: #009933;">
					<div id="ES6A" class="ltg">
						<div id="chartContainerES6A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES6B" class="lcg">
						<div id="chartContainerES6B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES6C" class="lbg">
						<div id="chartContainerES6C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES6A2" class="rtg">
						<div id="chartContainerES6A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES6B2" class="rcg">
						<div id="chartContainerES6B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="ES6C2" class="rbg">
						<div id="chartContainerES6C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="ES6GT" class="contab">
					<center>
						<h1> <?php echo $School;?> English Silent Grade 6</h1>
					</center>
					<button type="button" id="exportButEES6" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/ES3table4.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="FO3" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FO3GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FO3GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FO3GG" class="contab">
					<div class="leftGraphPart2">
						<div id="FO3" class="centerGrap3">
							<div id="chartContainerFO3A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="FO32" class="centerGrap3">
							<div id="chartContainerFO3A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="FO3GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Oral Grade 3</h1>
					</center>
					<button type="button" id="exportButEFO3" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FO3table1.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FO4" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FO4GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FO4GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FO4GG" class="contab">
					<div id="FO4" class="leftGraphPart2">
						<div class="centerGrap3">
							<div id="chartContainerFO4A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="FO42" class="centerGrap3">
							<div id="chartContainerFO4A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="FO4GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Oral Grade 4</h1>
					</center>
					<button type="button" id="exportButEFO4" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FO3table2.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FO5" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FO5GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FO5GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FO5GG" class="contab">
					<div id="FO5" class="leftGraphPart2">
						<div class="centerGrap3">
							<div id="chartContainerFO5A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="FO52" class="centerGrap3">
							<div id="chartContainerFO5A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="FO5GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Oral Grade 5</h1>
					</center>
					<button type="button" id="exportButEFO5" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FO3table3.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FO6" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FO6GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FO6GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FO6GG" class="contab">
					<div id="FO6" class="leftGraphPart2">
						<div class="centerGrap3">
							<div id="chartContainerFO6A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="FO62" class="centerGrap3">
							<div id="chartContainerFO6A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="FO6GT" class="contab">
					<center>
						<h1> <?php echo $School;?>Filipino Oral Grade 6</h1>
					</center>
					<button type="button" id="exportButEFO6" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FO3table4.php";
		   				?> 
		   			</div>
				</div>
			</div>

			<div id="FS3" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FS3GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FS3GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FS3GG" class="contab" style="background-color: #009933;">
					<div id="FS3A" class="ltg">
						<div id="chartContainerFS3A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS3B" class="lcg">
						<div id="chartContainerFS3B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS3C" class="lbg">
						<div id="chartContainerFS3C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS3A2" class="rtg">
						<div id="chartContainerFS3A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS3B2" class="rcg">
						<div id="chartContainerFS3B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS3C2" class="rbg">
						<div id="chartContainerFS3C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="FS3GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Silent Grade 3</h1>
					</center>
					<button type="button" id="exportButEFS3" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FS3table1.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FS4" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FS4GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FS4GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FS4GG" class="contab" style="background-color: #009933;">
					<div id="FS4A" class="ltg">
						<div id="chartContainerFS4A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS4B" class="lcg">
						<div id="chartContainerFS4B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS4C" class="lbg">
						<div id="chartContainerFS4C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS4A2" class="rtg">
						<div id="chartContainerFS4A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS4B2" class="rcg">
						<div id="chartContainerFS4B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS4C2" class="rbg">
						<div id="chartContainerFS4C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="FS4GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Silent Grade 4</h1>
					</center>
					<button type="button" id="exportButEFS4" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FS3table2.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FS5" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FS5GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FS5GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FS5GG" class="contab" style="background-color: #009933;">
					<div id="FS5A" class="ltg">
						<div id="chartContainerFS5A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS5B" class="lcg">
						<div id="chartContainerFS5B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS5C" class="lbg">
						<div id="chartContainerFS5C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS5A2" class="rtg">
						<div id="chartContainerFS5A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS5B2" class="rcg">
						<div id="chartContainerFS5B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS5C2" class="rbg">
						<div id="chartContainerFS5C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="FS5GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Silent Grade 5</h1>
					</center>
					<button type="button" id="exportButEFS5" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FS3table3.php";
		   				?> 
		   			</div>
				</div>
			</div>
			<div id="FS6" class="rightSide" <?php if ($_SESSION['display'] == "Page1") {echo "style=\"display:block;\" ";}?>>
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'FS6GG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'FS6GT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="FS6GG" class="contab" style="background-color: #009933;">
					<div id="FS6A" class="ltg">
						<div id="chartContainerFS6A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS6B" class="lcg">
						<div id="chartContainerFS6B" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS6C" class="lbg">
						<div id="chartContainerFS6C" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS6A2" class="rtg">
						<div id="chartContainerFS6A2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS6B2" class="rcg">
						<div id="chartContainerFS6B2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
					<div id="FS6C2" class="rbg">
						<div id="chartContainerFS6C2" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
					</div>
				</div>
				<div id="FS6GT" class="contab">
					<center>
						<h1> <?php echo $School;?> Filipino Silent Grade 6</h1>
					</center>
					<button type="button" id="exportButEFS6" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/FS3table4.php";
		   				?> 
		   			</div>
				</div>
			</div>

		</div>
	</div>

	<div id="Grade5" class="leftTabE" <?php if ($_SESSION['display'] == "Page3") {echo "style=\"display:block;\" ";}?> >
		<<div class="graphCont2">
			<form class="leftPart" action="PHP/selDate.php" method="POST">
				<div class="topLeftPart">
					<select class="selDateE" name="time1">
						<?php
						if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page3") {
							echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
							if ($grossminNS != "none") {
								for ($i=$grossminNS; $i <= $grossmaxNS; $i++) { 
									echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
								}
							}
							else{
								echo "<option value=\"".$i."\"> SY: No Entry</option>";
							}
						}
						else{
							echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
							for ($i=$grossminNS; $i <= $grossmaxNS; $i++) { 
								echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
							}
						}
						?>
					</select>
					<button class="timeBtnE" type="submit" name="ESNutri">Go</button>
				</div>
				<div class="botLeftPart"></div>
			</form>
			
			<div class="rightSide2">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, 'NSG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, 'NST')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="NSG" class="contab">
					<div class="leftGraphPart2">
						<div id="NutriBarGraph1" class="centerGrap3">
							<div id="chartContaineNutri1A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
					<div class="rightGraphPart2">
						<div id="NutriBarGraph2" class="centerGrap3">
							<div id="chartContaineNutri2A" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
						</div>
					</div>
				</div>
				<div id="NST" class="contab">
					<center>
						<h1> <?php echo $School;?> Nutritional Status</h1>
					</center>
					<button type="button" id="exportButENS" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable" style="overflow-x: scroll;">
		   				<?php
		   					include "PHP/ENutri.php";
		   				?> 
		   			</div>
				</div>
			</div>
		</div>
	</div>

	<div id="Grade6" class="leftTabE" <?php if ($_SESSION['display'] == "Page4") {echo "style=\"display:block;\" ";}?> >
		<<div class="graphCont2">
			<form class="leftPart" action="PHP/selDate.php" method="POST">
				<div class="topLeftPart">
					<select class="selDateE" name="time1">
						<?php
						if ($_SESSION['display'] == "none" || $_SESSION['display'] !== "Page4") {
							echo "<option value=\"\" style=\"display: none;\" disabled selected>-Select Year-</option>";
							if ($grossmin4p != "none") {
								for ($i=$grossmin4p; $i <= $grossmax4p; $i++) { 
									echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
								}
							}
							else{
								echo "<option value=\"".$i."\"> SY: No Entry</option>";
							}
						}
						else{
							echo "<option value=\"\" style=\"display: none;\" disabled selected> SY: ".$chosenTime."-".($chosenTime+1)."</option>";
							for ($i=$grossmin4p; $i <= $grossmax4p; $i++) { 
								echo "<option value=\"".$i."\"> SY: ".$i."-".($i+1)."</option>";
							}
						}
						?>
					</select>
					<button class="timeBtnE" type="submit" name="ES4Ps">Go</button>
				</div>
				<div class="botLeftPart"></div>
			</form>
			
			<div class="rightSide2">
				<div class="tabtab">
					<button type="button" class="tablinks3" onclick="change3(event, '4PG')" style="margin-left: 0.2%;"><i class="fas fa-chart-bar"></i> Graph</button>
					<button type="button" class="tablinks3" onclick="change3(event, '4PT')" style="margin-left: -0.4%; border-left: 1px;"><i class="fas fa-table"></i> Table</button>
				</div>
				<div id="4PG" class="contab">
					<div class="leftGraphPart">
						<div id="PieGrap4p" class="topPie">
							<div id="chartContainer4P1p" style="height: 100%; max-width: 100%;"></div>
						</div>
						<div id="DouGrap4p" class="downPie">
							<div id="chartContainer4P1d" style="height: 100%; max-width: 100%;"></div>
						</div>
					</div>
					<div class="rightGraphPart">
						<div id="BarGrap4p" class="centerBar">
							<div id="chartContainer4P1" style="height: 100%; min-width: 100%;"></div>
						</div>
					</div>
				</div>
				<div id="4PT" class="contab">
					<center>
						<h1> <?php echo $School;?> 4P's Benificiaries</h1>
					</center>
					<button type="button" id="exportButE4P" class="ExpButton" style="width: 14%; margin-top: -3%;">Export Table <i class="fas fa-download"></i></button>
		   			<br>
		   			<div class="nutritable">
		   				<?php
		   					include "PHP/E4P.php";
		   				?> 
		   			</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="GrapModalGb" class="graphModal1">
	<span class="closeGb">&times;</span>
	<div id="chartContainerG2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalGp" class="graphModal1">
	<span class="closeGp">&times;</span>
	<div id="chartContainerG2p" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalGd" class="graphModal1">
	<span class="closeGd">&times;</span>
	<div id="chartContainerG2d" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalN" class="graphModal1">
	<span class="closeN">&times;</span>
	<div id="chartContainerN2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalD" class="graphModal1">
	<span class="closeD">&times;</span>
	<div id="chartContainerD2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalS" class="graphModal1">
	<span class="closeS">&times;</span>
	<div id="chartContainerS2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalF" class="graphModal1">
	<span class="closeF">&times;</span>
	<div id="chartContainerF2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalC" class="graphModal1">
	<span class="closeC">&times;</span>
	<div id="chartContainerC2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalRT" class="graphModal1">
	<span class="closeRT">&times;</span>
	<div id="chartContainerRT2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalGD" class="graphModal1">
	<span class="closeGD">&times;</span>
	<div id="chartContainerGD2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalPR" class="graphModal1">
	<span class="closePR">&times;</span>
	<div id="chartContainerPR2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalRP" class="graphModal1">
	<span class="closeRP">&times;</span>
	<div id="chartContainerRP2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModalEO3" class="graphModal1">
	<span class="EO3Close">&times;</span>
	<div id="chartContainerEO3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO32" class="graphModal1">
	<span class="EO3Close2">&times;</span>
	<div id="chartContainerEO3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO4" class="graphModal1">
	<span class="EO4Close">&times;</span>
	<div id="chartContainerEO4As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO4Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO4Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO42" class="graphModal1">
	<span class="EO4Close2">&times;</span>
	<div id="chartContainerEO4A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO4A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO4A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO5" class="graphModal1">
	<span class="EO5Close">&times;</span>
	<div id="chartContainerEO5As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO5Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO5Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO52" class="graphModal1">
	<span class="EO5Close2">&times;</span>
	<div id="chartContainerEO5A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO5A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO5A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO6" class="graphModal1">
	<span class="EO6Close">&times;</span>
	<div id="chartContainerEO6As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO6Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO6Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalEO62" class="graphModal1">
	<span class="EO6Close2">&times;</span>
	<div id="chartContainerEO6A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO6A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerEO6A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModalES3A" class="graphModal1">
	<span class="ES3CloseA">&times;</span>
	<div id="chartContainerES3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3B" class="graphModal1">
	<span class="ES3CloseB">&times;</span>
	<div id="chartContainerES3Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3C" class="graphModal1">
	<span class="ES3CloseC">&times;</span>
	<div id="chartContainerES3Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3A2" class="graphModal1">
	<span class="ES3CloseA2">&times;</span>
	<div id="chartContainerES3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3B2" class="graphModal1">
	<span class="ES3CloseB2">&times;</span>
	<div id="chartContainerES3B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3C2" class="graphModal1">
	<span class="ES3CloseC2">&times;</span>
	<div id="chartContainerES3C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3A" class="graphModal1">
	<span class="ES3CloseA">&times;</span>
	<div id="chartContainerES3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3B" class="graphModal1">
	<span class="ES3CloseB">&times;</span>
	<div id="chartContainerES3Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3C" class="graphModal1">
	<span class="ES3CloseC">&times;</span>
	<div id="chartContainerES3Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3A2" class="graphModal1">
	<span class="ES3CloseA2">&times;</span>
	<div id="chartContainerES3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3B2" class="graphModal1">
	<span class="ES3CloseB2">&times;</span>
	<div id="chartContainerES3B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES3C2" class="graphModal1">
	<span class="ES3CloseC2">&times;</span>
	<div id="chartContainerES3C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES3C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4A" class="graphModal1">
	<span class="ES4CloseA">&times;</span>
	<div id="chartContainerES4As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4B" class="graphModal1">
	<span class="ES4CloseB">&times;</span>
	<div id="chartContainerES4Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4C" class="graphModal1">
	<span class="ES4CloseC">&times;</span>
	<div id="chartContainerES4Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4A2" class="graphModal1">
	<span class="ES4CloseA2">&times;</span>
	<div id="chartContainerES4A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4B2" class="graphModal1">
	<span class="ES4CloseB2">&times;</span>
	<div id="chartContainerES4B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES4C2" class="graphModal1">
	<span class="ES4CloseC2">&times;</span>
	<div id="chartContainerES4C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES4C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5A" class="graphModal1">
	<span class="ES5CloseA">&times;</span>
	<div id="chartContainerES5As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5B" class="graphModal1">
	<span class="ES5CloseB">&times;</span>
	<div id="chartContainerES5Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5C" class="graphModal1">
	<span class="ES5CloseC">&times;</span>
	<div id="chartContainerES5Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5A2" class="graphModal1">
	<span class="ES5CloseA2">&times;</span>
	<div id="chartContainerES5A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5B2" class="graphModal1">
	<span class="ES5CloseB2">&times;</span>
	<div id="chartContainerES5B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES5C2" class="graphModal1">
	<span class="ES5CloseC2">&times;</span>
	<div id="chartContainerES5C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES5C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6A" class="graphModal1">
	<span class="ES6CloseA">&times;</span>
	<div id="chartContainerES6As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6B" class="graphModal1">
	<span class="ES6CloseB">&times;</span>
	<div id="chartContainerES6Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6C" class="graphModal1">
	<span class="ES6CloseC">&times;</span>
	<div id="chartContainerES6Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6A2" class="graphModal1">
	<span class="ES6CloseA2">&times;</span>
	<div id="chartContainerES6A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6B2" class="graphModal1">
	<span class="ES6CloseB2">&times;</span>
	<div id="chartContainerES6B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalES6C2" class="graphModal1">
	<span class="ES6CloseC2">&times;</span>
	<div id="chartContainerES6C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerES6C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>

<div id="GrapModalFO3" class="graphModal1">
	<span class="FO3Close">&times;</span>
	<div id="chartContainerFO3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO32" class="graphModal1">
	<span class="FO3Close2">&times;</span>
	<div id="chartContainerFO3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO4" class="graphModal1">
	<span class="FO4Close">&times;</span>
	<div id="chartContainerFO4As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO4Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO4Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO42" class="graphModal1">
	<span class="FO4Close2">&times;</span>
	<div id="chartContainerFO4A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO4A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO4A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO5" class="graphModal1">
	<span class="EO5Close">&times;</span>
	<div id="chartContainerFO5As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO5Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO5Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO52" class="graphModal1">
	<span class="FO5Close2">&times;</span>
	<div id="chartContainerFO5A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO5A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO5A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO6" class="graphModal1">
	<span class="EO6Close">&times;</span>
	<div id="chartContainerFO6As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO6Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO6Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFO62" class="graphModal1">
	<span class="FO6Close2">&times;</span>
	<div id="chartContainerFO6A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO6A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFO6A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModalFS3A" class="graphModal1">
	<span class="FS3CloseA">&times;</span>
	<div id="chartContainerFS3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3B" class="graphModal1">
	<span class="FS3CloseB">&times;</span>
	<div id="chartContainerFS3Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3C" class="graphModal1">
	<span class="FS3CloseC">&times;</span>
	<div id="chartContainerFS3Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3A2" class="graphModal1">
	<span class="FS3CloseA2">&times;</span>
	<div id="chartContainerFS3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3B2" class="graphModal1">
	<span class="FS3CloseB2">&times;</span>
	<div id="chartContainerFS3B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3C2" class="graphModal1">
	<span class="FS3CloseC2">&times;</span>
	<div id="chartContainerFS3C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3A" class="graphModal1">
	<span class="FS3CloseA">&times;</span>
	<div id="chartContainerFS3As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3B" class="graphModal1">
	<span class="FS3CloseB">&times;</span>
	<div id="chartContainerFS3Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3C" class="graphModal1">
	<span class="FS3CloseC">&times;</span>
	<div id="chartContainerFS3Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3A2" class="graphModal1">
	<span class="FS3CloseA2">&times;</span>
	<div id="chartContainerFS3A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3B2" class="graphModal1">
	<span class="FS3CloseB2">&times;</span>
	<div id="chartContainerFS3B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS3C2" class="graphModal1">
	<span class="FS3CloseC2">&times;</span>
	<div id="chartContainerFS3C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS3C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4A" class="graphModal1">
	<span class="FS4CloseA">&times;</span>
	<div id="chartContainerFS4As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4B" class="graphModal1">
	<span class="FS4CloseB">&times;</span>
	<div id="chartContainerFS4Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4C" class="graphModal1">
	<span class="FS4CloseC">&times;</span>
	<div id="chartContainerFS4Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4A2" class="graphModal1">
	<span class="FS4CloseA2">&times;</span>
	<div id="chartContainerFS4A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4B2" class="graphModal1">
	<span class="FS4CloseB2">&times;</span>
	<div id="chartContainerFS4B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS4C2" class="graphModal1">
	<span class="FS4CloseC2">&times;</span>
	<div id="chartContainerFS4C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS4C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5A" class="graphModal1">
	<span class="FS5CloseA">&times;</span>
	<div id="chartContainerFS5As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5B" class="graphModal1">
	<span class="FS5CloseB">&times;</span>
	<div id="chartContainerFS5Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5C" class="graphModal1">
	<span class="FS5CloseC">&times;</span>
	<div id="chartContainerFS5Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5A2" class="graphModal1">
	<span class="FS5CloseA2">&times;</span>
	<div id="chartContainerFS5A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5B2" class="graphModal1">
	<span class="FS5CloseB2">&times;</span>
	<div id="chartContainerFS5B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS5C2" class="graphModal1">
	<span class="FS5CloseC2">&times;</span>
	<div id="chartContainerFS5C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS5C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6A" class="graphModal1">
	<span class="FS6CloseA">&times;</span>
	<div id="chartContainerFS6As" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Aa" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Ab" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6B" class="graphModal1">
	<span class="FS6CloseB">&times;</span>
	<div id="chartContainerFS6Bs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Ba" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Bb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6C" class="graphModal1">
	<span class="FS6CloseC">&times;</span>
	<div id="chartContainerFS6Cs" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Ca" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6Cb" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6A2" class="graphModal1">
	<span class="FS6CloseA2">&times;</span>
	<div id="chartContainerFS6A2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6B2" class="graphModal1">
	<span class="FS6CloseB2">&times;</span>
	<div id="chartContainerFS6B2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6B2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6B2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalFS6C2" class="graphModal1">
	<span class="FS6CloseC2">&times;</span>
	<div id="chartContainerFS6C2s" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6C2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerFS6C2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModalNutri1" class="graphModal1">
	<span class="NutriClose1">&times;</span>
	<div id="chartContainerNutri1A2" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; right: 4%;"></div>
	<div style="position: absolute; left: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerNutri1A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; left: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerNutri1A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>
<div id="GrapModalNutri2" class="graphModal1">
	<span class="NutriClose2">&times;</span>
	<div id="chartContainerNutri2A2" style="position: absolute; height: 96%; width: 60%; z-index: 1; top: 4%; left: 4%;"></div>
	<div style="position: absolute; right: 5%; top: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerNutri2A2a" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
	<div style="position: absolute; right: 5%; bottom: 4%; width: 27%; height: 45%; background-color: red;">
		<div id="chartContainerNutri2A2b" style="position: relative; height: 100%; width: 100%; z-index: 1;"></div>
	</div>
</div>

<div id="GrapModal4Pb" class="graphModal1">
	<span class="close4Pb">&times;</span>
	<div id="chartContainer4P2" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal4Pp" class="graphModal1">
	<span class="close4Pp">&times;</span>
	<div id="chartContainer4P2p" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<div id="GrapModal4Pd" class="graphModal1">
	<span class="close4Pd">&times;</span>
	<div id="chartContainer4P2d" style="position: relative; height: 92%; width: 96%; z-index: 1; margin-top: 2%; margin-left: 2%;"></div>
</div>

<script>
/*
	var modalG1 = document.getElementById("GrapModalGb");
	var modalG2 = document.getElementById("GrapModalGp");
	var modalG3 = document.getElementById("GrapModalGd");
	var modalN = document.getElementById("GrapModalN");
	var modalD = document.getElementById("GrapModalD");
	var modalS = document.getElementById("GrapModalS");
	var modalF = document.getElementById("GrapModalF");
	var modalC = document.getElementById("GrapModalC");
	var modalRT = document.getElementById("GrapModalRT");
	var modalGD = document.getElementById("GrapModalGD");
	var modalPR = document.getElementById("GrapModalPR");
	var modalRP = document.getElementById("GrapModalRP");

	var modalNS1 = document.getElementById("GrapModalNutri1");
	var modalNS2 = document.getElementById("GrapModalNutri2");
	var modal4P1 = document.getElementById("GrapModal4Pb");
	var modal4P2 = document.getElementById("GrapModal4Pp");
	var modal4P3 = document.getElementById("GrapModal4Pd");

	var btnG1 = document.getElementById("grossBarGrap");
	var btnG2 = document.getElementById("grossPieGrap");
	var btnG3 = document.getElementById("grossDouGrap");
	var btnN = document.getElementById("NetBarGrap");
	var btnD = document.getElementById("DropBarGrap");
	var btnS = document.getElementById("SurvBarGrap");
	var btnF = document.getElementById("FailBarGrap");
	var btnC = document.getElementById("ComBarGrap");
	var btnRT = document.getElementById("RetBarGrap");
	var btnGD = document.getElementById("GradBarGrap");
	var btnPR = document.getElementById("ProBarGrap");
	var btnRP = document.getElementById("RepBarGrap");

	var btnNS1 = document.getElementById("NutriBarGraph1");
	var btnNS2 = document.getElementById("NutriBarGraph2");
	var btn4P1 = document.getElementById("BarGrap4p");
	var btn4P2 = document.getElementById("PieGrap4p");
	var btn4P3 = document.getElementById("DouGrap4p");

	var spanG1 = document.getElementsByClassName("closeGb")[0];
	var spanG2 = document.getElementsByClassName("closeGp")[0];
	var spanG3 = document.getElementsByClassName("closeGd")[0];
	var spanN = document.getElementsByClassName("closeN")[0];
	var spanD = document.getElementsByClassName("closeD")[0];
	var spanS = document.getElementsByClassName("closeS")[0];
	var spanF = document.getElementsByClassName("closeF")[0];
	var spanC = document.getElementsByClassName("closeC")[0];
	var spanRT = document.getElementsByClassName("closeRT")[0];
	var spanGD = document.getElementsByClassName("closeGD")[0];
	var spanPR = document.getElementsByClassName("closePR")[0];
	var spanRP = document.getElementsByClassName("closeRP")[0];

	var spanNS1 = document.getElementsByClassName("NutriClose1")[0];
	var spanNS2 = document.getElementsByClassName("NutriClose2")[0];
	var span4Pb = document.getElementsByClassName("close4Pb")[0];
	var span4Pp = document.getElementsByClassName("close4Pp")[0];
	var span4Pd = document.getElementsByClassName("close4Pd")[0];


	btnG1.onclick = function() {
	  modalG1.style.display = "block";
	}
	btnG2.onclick = function() {
	  modalG2.style.display = "block";
	}
	btnG3.onclick = function() {
	  modalG3.style.display = "block";
	}
	btnN.onclick = function() {
	  modalN.style.display = "block";
	}
	btnD.onclick = function() {
	  modalD.style.display = "block";
	}
	btnS.onclick = function() {
	  modalS.style.display = "block";
	}
	btnF.onclick = function() {
	  modalF.style.display = "block";
	}
	btnC.onclick = function() {
	  modalC.style.display = "block";
	}
	btnRT.onclick = function() {
	  modalRT.style.display = "block";
	}
	btnGD.onclick = function() {
	  modalGD.style.display = "block";
	}
	btnPR.onclick = function() {
	  modalPR.style.display = "block";
	}
	btnRP.onclick = function() {
	  modalRP.style.display = "block";
	}
	btnNS1.onclick = function() {
	  modalNS1.style.display = "block";
	}
	btnNS2.onclick = function() {
	  modalNS2.style.display = "block";
	}
	btn4P1.onclick = function() {
	  modal4P1.style.display = "block";
	}
	btn4P2.onclick = function() {
	  modal4P2.style.display = "block";
	}
	btn4P3.onclick = function() {
	  modal4P3.style.display = "block";
	}


	spanG1.onclick = function() {
	  modalG1.style.display = "none";
	}
	spanG2.onclick = function() {
	  modalG2.style.display = "none";
	}
	spanG3.onclick = function() {
	  modalG3.style.display = "none";
	}
	spanN.onclick = function() {
	  modalN.style.display = "none";
	}
	spanD.onclick = function() {
	  modalD.style.display = "none";
	}
	spanS.onclick = function() {
	  modalS.style.display = "none";
	}
	spanF.onclick = function() {
	  modalF.style.display = "none";
	}
	spanC.onclick = function() {
	  modalC.style.display = "none";
	}
	spanRT.onclick = function() {
	  modalRT.style.display = "none";
	}
	spanGD.onclick = function() {
	  modalGD.style.display = "none";
	}
	spanPR.onclick = function() {
	  modalPR.style.display = "none";
	}
	spanRP.onclick = function() {
	  modalSP.style.display = "none";
	}
	spanNS1.onclick = function() {
	  modalNS1.style.display = "none";
	}
	spanNS2.onclick = function() {
	  modalNS2.style.display = "none";
	}
	span4Pb.onclick = function() {
	  modal4P1.style.display = "none";
	}
	span4Pp.onclick = function() {
	  modal4P2.style.display = "none";
	}
	span4Pd.onclick = function() {
	  modal4P3.style.display = "none";
	}

	window.onclick = function(event) {
	  if (event.target == modalG1) {
	    modalG1.style.display = "none";
	  }
	  if (event.target == modalG2) {
	    modalG2.style.display = "none";
	  }
	  if (event.target == modalG3) {
	    modalG3.style.display = "none";
	  }
	  if (event.target == modalN) {
	    modalN.style.display = "none";
	  }
	  if (event.target == modalD) {
	    modalD.style.display = "none";
	  }
	  if (event.target == modalS) {
	    modalS.style.display = "none";
	  }
	  if (event.target == modalF) {
	    modalF.style.display = "none";
	  }
	  if (event.target == modalC) {
	    modalC.style.display = "none";
	  }
	  if (event.target == modalRT) {
	    modalRT.style.display = "none";
	  }
	  if (event.target == modalGD) {
	    modalGD.style.display = "none";
	  }
	  if (event.target == modalPR) {
	    modalPR.style.display = "none";
	  }
	  if (event.target == modalRP) {
	    modalRP.style.display = "none";
	  }
	  if (event.target == modalNS1) {
	    modalNS1.style.display = "none";
	  }
	  if (event.target == modalNS2) {
	    modalNS2.style.display = "none";
	  }
	  if (event.target == modal4P1) {
	    modal4P1.style.display = "none";
	  }
	  if (event.target == modal4P2) {
	    modal4P2.style.display = "none";
	  }
	  if (event.target == modal4P3) {
	    modal4P3.style.display = "none";
	  }
	}
*/
	function html_table_to_excelG(type){
	    var data = document.getElementById('myTableEG');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Gross Enrollment.' + type);
		}

	    const export_button = document.getElementById('exportButEG');

	    export_button.addEventListener('click', () =>  {
	    	html_table_to_excelG('xlsx');
	});

	function html_table_to_excelN(type){
	    var data = document.getElementById('myTableEN');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Net Enrollment Rate.' + type);
		}

	    const export_buttonN = document.getElementById('exportButEN');

	    export_buttonN.addEventListener('click', () =>  {
	    	html_table_to_excelN('xlsx');
	});

	function html_table_to_excelD(type){
	    var data = document.getElementById('myTableED');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Drop Rate.' + type);
		}

	    const export_buttonED = document.getElementById('exportButED');

	    export_buttonED.addEventListener('click', () =>  {
	    	html_table_to_excelD('xlsx');
	});

	function html_table_to_excelS(type){
	    var data = document.getElementById('myTableES');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Survival Rate.' + type);
		}

	    const export_buttonES = document.getElementById('exportButES');

	    export_buttonES.addEventListener('click', () =>  {
	    	html_table_to_excelS('xlsx');
	});

	function html_table_to_excelF(type){
	    var data = document.getElementById('myTableEF');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Failure Rate.' + type);
		}

	    const export_buttonEF = document.getElementById('exportButEF');

	    export_buttonEF.addEventListener('click', () =>  {
	    	html_table_to_excelF('xlsx');
	});

	function html_table_to_excelC(type){
	    var data = document.getElementById('myTableEC');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Completion Rate.' + type);
		}

	    const export_buttonEC = document.getElementById('exportButEC');

	    export_buttonEC.addEventListener('click', () =>  {
	    	html_table_to_excelC('xlsx');
	});

	function html_table_to_excelRT(type){
	    var data = document.getElementById('myTableERT');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Retention Rate.' + type);
		}

	    const export_buttonRT = document.getElementById('exportButERT');

	    export_buttonRT.addEventListener('click', () =>  {
	    	html_table_to_excelRT('xlsx');
	});

	function html_table_to_excelGD(type){
	    var data = document.getElementById('myTableEGD');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Graduation Rate.' + type);
		}

	    const export_buttonGD = document.getElementById('exportButEGD');

	    export_buttonGD.addEventListener('click', () =>  {
	    	html_table_to_excelGD('xlsx');
	});

	function html_table_to_excelPR(type){
	    var data = document.getElementById('myTableEPR');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Promotion Rate.' + type);
		}

	    const export_buttonPR = document.getElementById('exportButEPR');

	    export_buttonPR.addEventListener('click', () =>  {
	    	html_table_to_excelPR('xlsx');
	});

	function html_table_to_excelRP(type){
	    var data = document.getElementById('myTableERP');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Repeatition Rate.' + type);
		}

	    const export_buttonRP = document.getElementById('exportButERP');

	    export_buttonRP.addEventListener('click', () =>  {
	    	html_table_to_excelRP('xlsx');
	});

	function html_table_to_excelEO3(type){
	    var data = document.getElementById('myTableEO3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Oral Phil-Iri (Grade 3).' + type);
		}

	    const export_buttonEO3 = document.getElementById('exportButEEO3');

	    export_buttonEO3.addEventListener('click', () =>  {
	    	html_table_to_excelEO3('xlsx');
	});

	function html_table_to_excelEO4(type){
	    var data = document.getElementById('myTableEO4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Oral Phil-Iri (Grade 4).' + type);
		}

	    const export_buttonEO4 = document.getElementById('exportButEEO4');

	    export_buttonEO4.addEventListener('click', () =>  {
	    	html_table_to_excelEO4('xlsx');
	});

	function html_table_to_excelEO5(type){
	    var data = document.getElementById('myTableEO5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Oral Phil-Iri (Grade 5).' + type);
		}

	    const export_buttonEO5 = document.getElementById('exportButEEO5');

	    export_buttonEO5.addEventListener('click', () =>  {
	    	html_table_to_excelEO5('xlsx');
	});

	function html_table_to_excelEO6(type){
	    var data = document.getElementById('myTableEO6');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Oral Phil-Iri (Grade 6).' + type);
		}

	    const export_buttonEO6 = document.getElementById('exportButEEO6');

	    export_buttonEO6.addEventListener('click', () =>  {
	    	html_table_to_excelEO6('xlsx');
	});

	function html_table_to_excelFO3(type){
	    var data = document.getElementById('myTableFO3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Oral Phil-Iri (Grade 3).' + type);
		}

	    const export_buttonFO3 = document.getElementById('exportButEFO3');

	    export_buttonFO3.addEventListener('click', () =>  {
	    	html_table_to_excelFO3('xlsx');
	});

	function html_table_to_excelFO4(type){
	    var data = document.getElementById('myTableFO4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Oral Phil-Iri (Grade 4).' + type);
		}

	    const export_buttonFO4 = document.getElementById('exportButEFO4');

	    export_buttonFO4.addEventListener('click', () =>  {
	    	html_table_to_excelFO4('xlsx');
	});

	function html_table_to_excelFO5(type){
	    var data = document.getElementById('myTableFO5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Oral Phil-Iri (Grade 5).' + type);
		}

	    const export_buttonFO5 = document.getElementById('exportButEFO5');

	    export_buttonFO5.addEventListener('click', () =>  {
	    	html_table_to_excelFO5('xlsx');
	});

	function html_table_to_excelFO6(type){
	    var data = document.getElementById('myTableFO6');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Oral Phil-Iri (Grade 6).' + type);
		}

	    const export_buttonFO6 = document.getElementById('exportButEFO6');

	    export_buttonFO6.addEventListener('click', () =>  {
	    	html_table_to_excelFO6('xlsx');
	});

	function html_table_to_excelES3(type){
	    var data = document.getElementById('myTableES3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Silent Phil-Iri (Grade 3).' + type);
		}

	    const export_buttonES3 = document.getElementById('exportButEES3');

	    export_buttonES3.addEventListener('click', () =>  {
	    	html_table_to_excelES3('xlsx');
	});

	function html_table_to_excelES4(type){
	    var data = document.getElementById('myTableES4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Silent Phil-Iri (Grade 4).' + type);
		}

	    const export_buttonES4 = document.getElementById('exportButEES4');

	    export_buttonES4.addEventListener('click', () =>  {
	    	html_table_to_excelES4('xlsx');
	});

	function html_table_to_excelES5(type){
	    var data = document.getElementById('myTableES5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Silent Phil-Iri (Grade 5).' + type);
		}

	    const export_buttonES5 = document.getElementById('exportButEES5');

	    export_buttonES5.addEventListener('click', () =>  {
	    	html_table_to_excelES5('xlsx');
	});

	function html_table_to_excelES6(type){
	    var data = document.getElementById('myTableES6');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> English Silent Phil-Iri (Grade 6).' + type);
		}

	    const export_buttonES6 = document.getElementById('exportButEES6');

	    export_buttonES6.addEventListener('click', () =>  {
	    	html_table_to_excelES6('xlsx');
	});

	function html_table_to_excelFS3(type){
	    var data = document.getElementById('myTableFS3');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Silent Phil-Iri (Grade 3).' + type);
		}

	    const export_buttonFS3 = document.getElementById('exportButEFS3');

	    export_buttonFS3.addEventListener('click', () =>  {
	    	html_table_to_excelFS3('xlsx');
	});

	function html_table_to_excelFS4(type){
	    var data = document.getElementById('myTableFS4');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Silent Phil-Iri (Grade 4).' + type);
		}

	    const export_buttonFS4 = document.getElementById('exportButEFS4');

	    export_buttonFS4.addEventListener('click', () =>  {
	    	html_table_to_excelFS4('xlsx');
	});

	function html_table_to_excelFS5(type){
	    var data = document.getElementById('myTableFS5');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Silent Phil-Iri (Grade 5).' + type);
		}

	    const export_buttonFS5 = document.getElementById('exportButEFS5');

	    export_buttonFS5.addEventListener('click', () =>  {
	    	html_table_to_excelFS5('xlsx');
	});

	function html_table_to_excelFS6(type){
	    var data = document.getElementById('myTableFS6');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Filipino Silent Phil-Iri (Grade 6).' + type);
		}

	    const export_buttonFS6 = document.getElementById('exportButEFS6');

	    export_buttonFS6.addEventListener('click', () =>  {
	    	html_table_to_excelFS6('xlsx');
	});

	function html_table_to_excelNS(type){
	    var data = document.getElementById('myTableNS');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> Nutritional Status.' + type);
		}

	    const export_buttonNS = document.getElementById('exportButENS');

	    export_buttonNS.addEventListener('click', () =>  {
	    	html_table_to_excelNS('xlsx');
	});

	function html_table_to_excel4P(type){
	    var data = document.getElementById('myTable4P');

	    var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

	    XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

	    XLSX.writeFile(file, '<?php echo $School; ?> 4Ps Benificiaries.' + type);
		}

	    const export_button4P = document.getElementById('exportButE4P');

	    export_button4P.addEventListener('click', () =>  {
	    	html_table_to_excel4P('xlsx');
	});
</script>